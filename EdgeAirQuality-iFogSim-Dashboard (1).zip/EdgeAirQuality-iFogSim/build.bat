@echo off
REM Compiles iFogSim2 + the air quality project into bin\ (needs JDK 21 or newer on PATH)
cd /d "%~dp0"
if not exist bin mkdir bin
REM list all .java files as quoted forward-slash paths (works with spaces in folder names)
powershell -NoProfile -Command "Get-ChildItem -Recurse src -Filter *.java | ForEach-Object { [char]34 + ($_.FullName -replace '\\','/') + [char]34 } | Set-Content -Encoding ascii bin\sources.txt"
javac -nowarn -encoding UTF-8 -d bin -cp "jars\*;jars\commons-math3-3.5\*" @bin\sources.txt
if errorlevel 1 (echo Build FAILED) else (echo Build OK -^> bin\)
