#!/usr/bin/env bash
# Compiles iFogSim2 + the air quality project into ./bin (needs JDK 21 or newer)
set -e
cd "$(dirname "$0")"
CP=$(find jars -name '*.jar' | tr '\n' ':')
mkdir -p bin
find src -name '*.java' > bin/sources.txt
javac -nowarn -encoding UTF-8 -d bin -cp "$CP" @bin/sources.txt
echo "Build OK -> bin/"
