# Edge-Based Air Quality Monitoring System using iFogSim

A complete iFogSim2 simulation of a city-wide air quality monitoring network in which
low-cost sensor nodes measure PM2.5, PM10, CO, NO2 and O3, an edge (fog) layer filters the
data and computes the US EPA Air Quality Index (AQI) close to the sensors, and the cloud keeps
long-term history and city-level analytics. The project compares three placements of the
processing modules: **cloud-only**, **edge (fog gateway)** and iFogSim's **edge-ward** heuristic.

## What is inside

```
EdgeAirQuality-iFogSim/
├── src/org/fog/airquality/          <- the project code (everything else in src/ is iFogSim2)
│   ├── EdgeAirQualitySimulation.java   main simulation: topology, application, placement, metrics
│   ├── AQICalculator.java              EPA AQI sub-index + overall AQI + category
│   ├── EdgeDataFilter.java             edge filtering: validation, median spike filter, dead-band
│   ├── AirQualityDataGenerator.java    synthetic 24 h pollutant data with rush hours, events, faults
│   ├── AirQualityDataDemo.java         runs filter + AQI on one day of data, writes CSVs
│   └── SensorReading.java              data record
├── jars/                            iFogSim2 dependencies
├── build.sh / build.bat             compile everything into bin/
├── run.sh / run.bat                 run one simulation
├── scripts/run_experiments.sh       run all scenarios (3 repetitions each) -> results/
├── scripts/make_plots.py            draw the report figures from the CSVs
└── results/                         results produced by the authors' run (CSV, logs, figures)
```

## Requirements

* **JDK 21 or newer** (iFogSim2 uses Java 21 language features; tested with OpenJDK 21). No Maven or Gradle is needed.
* Python 3 + matplotlib only if you want to redraw the figures (`pip install matplotlib`).

## Build and run (Linux / macOS)

```bash
./demo.sh                          # one click demo: build + all three placements
./build.sh                         # compiles iFogSim2 + project into bin/
./run.sh edge 4 5 10               # mode, areas, sensor nodes per area, sensing interval (ms)
./run.sh cloud 4 5 10
./run.sh edgewards 4 5 10
./scripts/run_experiments.sh       # full experiment set (~3 min), writes results/simulation_results.csv
python3 scripts/make_plots.py      # figures -> results/figures/
```

Edge data pipeline only (no network simulation), prints filtering and AQI statistics:

```bash
java -cp "bin:$(find jars -name '*.jar' | tr '\n' ':')" org.fog.airquality.AirQualityDataDemo 4 5 results
```

## Build and run (Windows)

```bat
demo.bat          REM one click: builds, then runs the pipeline and all three placements
build.bat
run.bat edge 4 5 10
run.bat cloud 4 5 10
```

## Running in Eclipse (recommended for demos)

The folder is already an Eclipse project (`.project`, `.classpath` and settings are included, all jars are wired up).

1. Install **JDK 21** (Eclipse Temurin 21) and **Eclipse IDE for Java Developers 2024-03 or newer**.
2. *File > Import > General > Existing Projects into Workspace > Next*, choose **Select archive file** and pick
   `EdgeAirQuality-iFogSim.zip` (or **Select root directory** and pick the unzipped folder), tick the project, *Finish*.
3. Wait for the build (bottom-right progress bar) to finish.
4. Open `src > org.fog.airquality.demo` and run each class in order with *right-click > Run As > Java Application*:
   * `Step1_EdgeDataPipeline` - edge filter + AQI on one simulated day
   * `Step2_CloudOnly` - cloud-only placement
   * `Step3_Edge` - proposed edge placement
   * `Step4_EdgeWard` - iFogSim edge-ward placement
   * `Step5_EdgeWardOverload` - edge-ward at 5 ms sensing, shows the node overloading
5. The summary is the last block in the Console view (`AIR QUALITY SUMMARY`).

To try other settings, run `org.fog.airquality.EdgeAirQualitySimulation` with program arguments
(*Run > Run Configurations > Arguments*), e.g. `edge 8 5 10` = mode, areas, nodes per area, sensing interval (ms).

## Live monitoring dashboard (new)

Run `org.fog.airquality.EdgeAirQualitySimulation` **without program arguments** (in Eclipse: right-click the file >
*Run As > Java Application*). One dark dashboard window opens and immediately starts the real iFogSim simulation
(Edge/Fog placement, 20 sensors, 10 ms sensing). Everything on it updates live while the simulation runs:

* **Overview**: City AQI, temperature, humidity, active sensors, fog nodes, alerts, packet counters, system and cloud status, and a status tile for every EdgeNode, the Gateway and the Cloud.
* **Alerts**: high temperature, PM2.5, PM10, CO2, unhealthy AQI, sensor failure and fog node failure, coloured green / yellow / red, plus a live alert list and an activity feed.
* **Air Quality**: a table with every sensor (temperature, humidity, PM2.5, PM10, CO2, AQI, status, edge filter decision) and charts for temperature, humidity, AQI and PM2.5/PM10.
* **Fog Nodes / Cloud**: tuples received, tasks processed, processing time, CPU, memory and energy of every device, a processing comparison chart, and cloud requests, processing time, data transferred and storage.
* **Performance**: loop latency, network usage, energy, processing time, alert response delay, task completion rate and packet delivery ratio, with live charts.
* **Fog vs Cloud**: six full simulation runs (Edge/Fog and Cloud-only at 4, 10 and 20 sensors) start automatically in background JVMs and are plotted with a written summary.

Controls in the top bar: placement, number of sensors (4 / 10 / 20), sensing interval, speed, Start, Pause/Resume, Stop and Reset.

How it is connected to the simulation (package `org.fog.airquality.dashboard`):

* `EdgeAirQualitySimulation` got optional hooks (`SimulationHooks`). Without hooks it behaves exactly as before, so `run.sh`, the Step1..Step5 demos and the experiment scripts are unchanged. Running it with arguments still gives the console run; `-Daq.nogui=true` forces the console run without arguments.
* With hooks the same topology is built from monitored subclasses: `MonitoredSensor` attaches a reading from `AirQualityDataGenerator` to each AQ_SENSOR tuple, `MonitoredApplication` runs `EdgeDataFilter` (data_filter) and `AQICalculator` (aqi_analyzer) when iFogSim finishes those tuples, and `DataDrivenSelectivity` forwards FILTERED_DATA / PUBLIC_ALERT tuples according to those real decisions.
* `MetricsCollector` reads energy, utilisation (from iFogSim's linear power model), network usage (`NetworkUsageMonitor`), loop latency and task counts; `DashboardMonitor` is a CloudSim entity that samples every 50 simulated ms and paces the run so it can be watched.
* `DashboardController` replaces iFogSim's `System.exit()` at the end of the run so the window stays open.
* CO2 is not produced by the original generator; it is derived from the CO reading (CO2 = 415 + 110 x CO ppm + noise) and labelled as synthetic.

## Example output (20 sensor nodes, 10 ms sensing interval, mean of 3 runs)

| Placement | Loop latency (ms) | Network usage (bytes/ms) | Total energy (M units) | Cloud cost (thousands) |
|---|---|---|---|---|
| Cloud-only | 218.3 | 40,878 | 17.44 | 4,408 |
| Edge (fog gateway) | 18.7 | 19,452 | 14.85 | 481 |
| Edge-ward (on node) | 8.3 | 18,175 | 14.38 | 27.6 |

## Assumptions

* Sensor data is synthetic (no public dataset is bundled); the generator models rush-hour peaks,
  afternoon ozone, short pollution events and 3 % faulty samples.
* iFogSim time units are treated as milliseconds; energy and cost are iFogSim's own model units,
  so compare them relatively between placements rather than as absolute values.
* Device capacities and power figures are representative of ESP32 nodes, Raspberry Pi 4
  gateways and a cloud server, not measured values.
* The edge filter's measured forwarding ratio (about 66 %) and alert ratio (about 35 %) are fed
  into iFogSim as tuple selectivities, which links the data pipeline to the network simulation.

## Licence

iFogSim2 is MIT licensed by the CLOUDS Laboratory, University of Melbourne (see `LICENSE-iFogSim.txt`).
The air quality code in `src/org/fog/airquality` is provided for academic use.
