#!/usr/bin/env bash
# One-click demo (Linux/macOS)
cd "$(dirname "$0")"
[ -f bin/org/fog/airquality/EdgeAirQualitySimulation.class ] || ./build.sh
CP="bin:$(find jars -name '*.jar' | tr '\n' ':')"
java -cp "$CP" org.fog.airquality.AirQualityDataDemo 4 5 results
for m in cloud edge edgewards; do java -cp "$CP" org.fog.airquality.EdgeAirQualitySimulation $m 4 5 10 | grep -A9 "AIR QUALITY SUMMARY"; done
