package org.fog.airquality;

import java.util.List;

import org.cloudbus.cloudsim.Storage;
import org.fog.application.Application;
import org.fog.application.selectivity.SelectivityModel;
import org.fog.entities.Actuator;
import org.fog.entities.FogBroker;
import org.fog.entities.FogDevice;
import org.fog.entities.FogDeviceCharacteristics;
import org.fog.entities.Sensor;
import org.fog.placement.Controller;
import org.fog.policy.AppModuleAllocationPolicy;
import org.fog.utils.distribution.Distribution;

/**
 * Optional extension points of {@link EdgeAirQualitySimulation}.
 *
 * When no hooks are given (the normal console run, run.sh, Step1..Step5) the simulation
 * creates the plain iFogSim classes exactly as before. The live dashboard passes an
 * implementation that creates monitored subclasses of the same entities, so the topology,
 * application and placement stay identical while every event can be observed.
 */
public interface SimulationHooks {

    FogBroker createBroker(String name) throws Exception;

    Application createApplication(String appId, int userId);

    FogDevice createFogDevice(String name, FogDeviceCharacteristics characteristics,
                              AppModuleAllocationPolicy allocationPolicy, List<Storage> storageList,
                              double schedulingInterval, long uplinkBandwidth, long downlinkBandwidth,
                              double uplinkLatency, double ratePerMips, int level,
                              double busyPower, double idlePower, int ramMb) throws Exception;

    Sensor createSensor(String name, String tupleType, int userId, String appId,
                        Distribution transmitDistribution, int area, int node);

    Actuator createActuator(String name, int userId, String appId, String actuatorType, int area, int node);

    /** Selectivity used for the tuple mapping module: inputType to outputType. */
    SelectivityModel createSelectivity(String module, String inputTupleType, String outputTupleType,
                                       double calibratedRatio);

    Controller createController(String name, List<FogDevice> fogDevices, List<Sensor> sensors,
                                List<Actuator> actuators) throws Exception;

    /** Called after everything is created, just before CloudSim.startSimulation(). */
    void beforeStart(Application application, Controller controller) throws Exception;
}
