package org.fog.airquality;

import java.io.File;
import java.io.PrintWriter;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Runs the edge data pipeline (filter -> AQI -> alert) on one simulated day of
 * synthetic sensor data, without the network simulator. It is used to:
 *  - show what the edge modules actually compute (AQI values, categories, alerts),
 *  - measure how much data the edge filter removes, which then calibrates the
 *    tuple selectivity of the iFogSim application in EdgeAirQualitySimulation.
 *
 * Usage: java ... org.fog.airquality.AirQualityDataDemo [areas] [nodesPerArea] [outputDir]
 */
public class AirQualityDataDemo {

    /** AQI above this value raises an alert ("Unhealthy for Sensitive Groups" and worse). */
    public static final int ALERT_THRESHOLD = 100;
    static final AirQualityDataGenerator.Zone[] ZONES = AirQualityDataGenerator.Zone.values();

    /** Returns {forwardRatio, alertRatio} for the given deployment size. */
    public static double[] measureRatios(int areas, int nodesPerArea, long seed) {
        Stats s = run(areas, nodesPerArea, seed, null, null);
        return new double[]{ s.forwarded / (double) s.raw, s.alerts / (double) Math.max(s.forwarded, 1) };
    }

    static final class Stats {
        int raw, invalid, smoothed, suppressed, forwarded, alerts;
        Map<String, Integer> categoryCount = new LinkedHashMap<>();
    }

    static Stats run(int areas, int nodesPerArea, long seed, PrintWriter readingsOut, PrintWriter stationOut) {
        AirQualityDataGenerator gen = new AirQualityDataGenerator(seed, 0.03);
        Stats st = new Stats();
        for (String c : AQICalculator.CATEGORIES) st.categoryCount.put(c, 0);
        if (readingsOut != null)
            readingsOut.println(SensorReading.csvHeader() + ",filter_outcome,aqi,category,dominant,alert");
        if (stationOut != null)
            stationOut.println("station,zone,samples,invalid,spikes_smoothed,suppressed,forwarded,data_reduction_pct,"
                    + "mean_aqi,max_aqi,alerts");
        for (int a = 0; a < areas; a++) {
            for (int n = 0; n < nodesPerArea; n++) {
                String id = "node-" + a + "-" + n;
                AirQualityDataGenerator.Zone zone = ZONES[(a + n) % ZONES.length];
                List<SensorReading> day = gen.generateDay(id, zone, 1);
                EdgeDataFilter filter = new EdgeDataFilter();
                int lastAqi = 0, alerts = 0, maxAqi = 0;
                double sumAqi = 0;
                int aqiCount = 0;
                for (SensorReading r : day) {
                    EdgeDataFilter.Decision d = filter.process(r);
                    String outcome = d.outcome.name();
                    String aqiStr = "", cat = "", dom = "", alert = "";
                    if (d.outcome == EdgeDataFilter.Outcome.FORWARDED) {
                        AQICalculator.Result res = AQICalculator.compute(d.reading);
                        lastAqi = res.aqi;
                        st.categoryCount.merge(res.category, 1, Integer::sum);
                        boolean isAlert = res.isAlert(ALERT_THRESHOLD);
                        if (isAlert) alerts++;
                        aqiStr = String.valueOf(res.aqi);
                        cat = res.category;
                        dom = res.dominantPollutant;
                        alert = String.valueOf(isAlert);
                    }
                    if (d.outcome != EdgeDataFilter.Outcome.DROPPED_INVALID) {
                        sumAqi += lastAqi;
                        aqiCount++;
                        maxAqi = Math.max(maxAqi, lastAqi);
                    }
                    if (readingsOut != null && a == 0 && n < 2) // keep the sample file small: 2 stations
                        readingsOut.println(r.toCsv() + "," + outcome + "," + aqiStr + ",\"" + cat + "\"," + dom + "," + alert);
                }
                st.raw += day.size();
                st.invalid += filter.invalid;
                st.smoothed += filter.smoothed;
                st.suppressed += filter.suppressed;
                st.forwarded += filter.forwarded;
                st.alerts += alerts;
                if (stationOut != null)
                    stationOut.printf(Locale.US, "%s,%s,%d,%d,%d,%d,%d,%.1f,%.1f,%d,%d%n", id, zone, day.size(),
                            filter.invalid, filter.smoothed, filter.suppressed, filter.forwarded,
                            100.0 * (day.size() - filter.forwarded) / day.size(), sumAqi / Math.max(aqiCount, 1),
                            maxAqi, alerts);
            }
        }
        return st;
    }

    public static void main(String[] args) throws Exception {
        int areas = args.length > 0 ? Integer.parseInt(args[0]) : 4;
        int nodes = args.length > 1 ? Integer.parseInt(args[1]) : 5;
        File dir = new File(args.length > 2 ? args[2] : "results");
        dir.mkdirs();
        Stats s;
        try (PrintWriter rw = new PrintWriter(new File(dir, "sample_readings.csv"));
             PrintWriter sw = new PrintWriter(new File(dir, "station_summary.csv"))) {
            s = run(areas, nodes, 42L, rw, sw);
        }
        System.out.println("======= EDGE DATA PIPELINE (1 simulated day, 1 sample/min) =======");
        System.out.printf(Locale.US, "Stations                 : %d%n", areas * nodes);
        System.out.printf(Locale.US, "Raw samples              : %d%n", s.raw);
        System.out.printf(Locale.US, "Invalid (dropped)        : %d (%.1f%%)%n", s.invalid, 100.0 * s.invalid / s.raw);
        System.out.printf(Locale.US, "Spikes smoothed          : %d%n", s.smoothed);
        System.out.printf(Locale.US, "Suppressed (no change)   : %d (%.1f%%)%n", s.suppressed, 100.0 * s.suppressed / s.raw);
        System.out.printf(Locale.US, "Forwarded to AQI module  : %d (%.1f%%)%n", s.forwarded, 100.0 * s.forwarded / s.raw);
        System.out.printf(Locale.US, "Alerts (AQI > %d)       : %d (%.1f%% of analysed)%n", ALERT_THRESHOLD, s.alerts,
                100.0 * s.alerts / s.forwarded);
        System.out.println("AQI category distribution of analysed samples:");
        for (Map.Entry<String, Integer> e : s.categoryCount.entrySet())
            System.out.printf(Locale.US, "  %-32s %6d%n", e.getKey(), e.getValue());
        System.out.println("Files written to " + dir.getPath() + ": sample_readings.csv, station_summary.csv");
    }
}
