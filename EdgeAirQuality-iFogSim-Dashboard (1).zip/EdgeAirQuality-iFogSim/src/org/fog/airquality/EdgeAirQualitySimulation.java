package org.fog.airquality;

import java.awt.GraphicsEnvironment;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;

import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Pe;
import org.cloudbus.cloudsim.Storage;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.power.PowerHost;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;
import org.cloudbus.cloudsim.sdn.overbooking.BwProvisionerOverbooking;
import org.cloudbus.cloudsim.sdn.overbooking.PeProvisionerOverbooking;
import org.fog.application.AppEdge;
import org.fog.application.AppLoop;
import org.fog.application.Application;
import org.fog.application.selectivity.FractionalSelectivity;
import org.fog.application.selectivity.SelectivityModel;
import org.fog.entities.Actuator;
import org.fog.entities.FogBroker;
import org.fog.entities.FogDevice;
import org.fog.entities.FogDeviceCharacteristics;
import org.fog.entities.Sensor;
import org.fog.entities.Tuple;
import org.fog.placement.Controller;
import org.fog.placement.ModuleMapping;
import org.fog.placement.ModulePlacementEdgewards;
import org.fog.placement.ModulePlacementMapping;
import org.fog.policy.AppModuleAllocationPolicy;
import org.fog.scheduler.StreamOperatorScheduler;
import org.fog.utils.Config;
import org.fog.utils.FogLinearPowerModel;
import org.fog.utils.FogUtils;
import org.fog.utils.NetworkUsageMonitor;
import org.fog.utils.TimeKeeper;
import org.fog.utils.distribution.DeterministicDistribution;

/**
 * Edge-based Air Quality Monitoring System simulated with iFogSim2.
 *
 * Physical topology (4 levels):
 *
 *   Cloud data centre (level 0)
 *        |  WAN, 100 ms
 *   ISP / city gateway (level 1)
 *        |  metro link, 4 ms
 *   Area fog gateways, Raspberry-Pi class (level 2) - one per city area
 *        |  Wi-Fi / MQTT, 2 ms
 *   Sensor nodes, ESP32 class (level 3) - each with an AQ sensor and an AQI indicator
 *
 * Application (distributed data flow):
 *
 *   AQ_SENSOR --AQ_DATA--> data_filter --FILTERED_DATA--> aqi_analyzer --AQI_SUMMARY (periodic)--> cloud_storage
 *                               ^                              |   \--PUBLIC_ALERT (only when AQI is high)--> cloud_storage
 *                               |----------AQI_STATUS----------|
 *   AQI_INDICATOR <--AQI_DISPLAY-- data_filter              cloud_storage --THRESHOLD_UPDATE (periodic)--> aqi_analyzer
 *
 * Placement strategies compared:
 *   edge  : data_filter on sensor nodes, aqi_analyzer on area fog gateways, cloud_storage in the cloud
 *   cloud : data_filter on sensor nodes (thin client), aqi_analyzer and cloud_storage in the cloud
 *   edgewards : iFogSim's built-in Edge-ward placement heuristic (only cloud_storage pinned)
 *
 * Usage:
 *   java ... org.fog.airquality.EdgeAirQualitySimulation [mode] [areas] [nodesPerArea] [sensingInterval] [resultsCsv]
 *   e.g. edge 4 5 10 results/simulation_results.csv
 *
 * Running this class WITHOUT program arguments (for example with Run in Eclipse) opens the
 * live monitoring dashboard (org.fog.airquality.dashboard), which runs this same simulation
 * with monitored entities. Add -Daq.nogui=true as a VM argument to get the old console run.
 */
public class EdgeAirQualitySimulation {

    static final String APP_ID = "air_quality_monitor";

    static List<FogDevice> fogDevices = new ArrayList<>();
    static List<Sensor> sensors = new ArrayList<>();
    static List<Actuator> actuators = new ArrayList<>();

    // ----- experiment parameters (overridable from the command line) -----
    static String mode = "edge";
    static int numAreas = 4;
    static int nodesPerArea = 5;
    static double sensingInterval = 10;          // ms between two sensor samples
    static String resultsCsv = null;

    // ----- workload parameters derived from the edge data pipeline -----
    /** Fraction of raw samples the edge filter forwards (measured by AirQualityDataDemo). */
    static double forwardRatio = 0.62;
    /** Fraction of analysed samples that are above the alert threshold. */
    static double alertRatio = 0.18;

    /** Optional extension points used by the live dashboard; null for the normal console run. */
    static SimulationHooks hooks = null;

    public static void main(String[] args) {
        if (args.length == 0 && !Boolean.getBoolean("aq.nogui") && !GraphicsEnvironment.isHeadless()) {
            // Eclipse "Run" without arguments: open the live dashboard, which drives this simulation.
            org.fog.airquality.dashboard.DashboardApp.launch();
            return;
        }
        if (args.length > 0) mode = args[0].toLowerCase(Locale.ROOT);
        if (args.length > 1) numAreas = Integer.parseInt(args[1]);
        if (args.length > 2) nodesPerArea = Integer.parseInt(args[2]);
        if (args.length > 3) sensingInterval = Double.parseDouble(args[3]);
        if (args.length > 4) resultsCsv = args[4];
        if (!Arrays.asList("edge", "cloud", "edgewards").contains(mode)) {
            System.err.println("mode must be edge, cloud or edgewards");
            System.exit(1);
        }

        // Calibrate the workload with the real filtering / AQI logic on synthetic data.
        double[] ratios = AirQualityDataDemo.measureRatios(numAreas, nodesPerArea, 42L);
        forwardRatio = ratios[0];
        alertRatio = Math.max(ratios[1], 0.01);

        System.out.printf(Locale.US, "Starting Edge Air Quality Monitoring | mode=%s areas=%d nodes/area=%d interval=%.1fms%n",
                mode, numAreas, nodesPerArea, sensingInterval);
        System.out.printf(Locale.US, "Edge filter forward ratio=%.3f  alert ratio=%.3f%n", forwardRatio, alertRatio);

        try {
            runSimulation(null);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Simulation failed");
        }
    }

    /**
     * Sets the experiment parameters for a run started from code (dashboard / experiment runner)
     * and calibrates the workload exactly like main() does. Clears the entity lists of a previous run.
     */
    public static void configure(String runMode, int areas, int perArea, double interval) {
        mode = runMode.toLowerCase(Locale.ROOT);
        numAreas = areas;
        nodesPerArea = perArea;
        sensingInterval = interval;
        resultsCsv = null;
        fogDevices = new ArrayList<>();
        sensors = new ArrayList<>();
        actuators = new ArrayList<>();
        double[] ratios = AirQualityDataDemo.measureRatios(numAreas, nodesPerArea, 42L);
        forwardRatio = ratios[0];
        alertRatio = Math.max(ratios[1], 0.01);
    }

    public static String getMode() { return mode; }
    public static int getNumAreas() { return numAreas; }
    public static int getNodesPerArea() { return nodesPerArea; }
    public static double getSensingInterval() { return sensingInterval; }
    public static double getForwardRatio() { return forwardRatio; }
    public static double getAlertRatio() { return alertRatio; }

    /**
     * Builds the topology and application and runs the simulation.
     * With h == null this is the original console behaviour (iFogSim's Controller ends the JVM
     * and the summary is printed from a shutdown hook). With hooks the call returns when the
     * simulation ends and prints the same summary.
     */
    public static void runSimulation(SimulationHooks h) throws Exception {
        hooks = h;
        try {
            Log.disable();
            Config.MAX_SIMULATION_TIME = 10000;
            CloudSim.init(1, Calendar.getInstance(), false);

            FogBroker broker = h == null ? new FogBroker("broker") : h.createBroker("broker");
            Application application = createApplication(APP_ID, broker.getId());
            application.setUserId(broker.getId());

            createFogDevices(broker.getId(), APP_ID);

            ModuleMapping moduleMapping = ModuleMapping.createModuleMapping();
            moduleMapping.addModuleToDevice("cloud_storage", "cloud");
            if (!mode.equals("edgewards")) {
                for (FogDevice d : fogDevices) {
                    if (d.getName().startsWith("node-")) moduleMapping.addModuleToDevice("data_filter", d.getName());
                    if (mode.equals("edge") && d.getName().startsWith("fog-gw-"))
                        moduleMapping.addModuleToDevice("aqi_analyzer", d.getName());
                }
                if (mode.equals("cloud")) moduleMapping.addModuleToDevice("aqi_analyzer", "cloud");
            }

            Controller controller = h == null
                    ? new Controller("master-controller", fogDevices, sensors, actuators)
                    : h.createController("master-controller", fogDevices, sensors, actuators);
            controller.submitApplication(application, 0,
                    mode.equals("edgewards")
                            ? new ModulePlacementEdgewards(fogDevices, sensors, actuators, application, moduleMapping)
                            : new ModulePlacementMapping(fogDevices, application, moduleMapping));

            final List<AppLoop> loops = application.getLoops();
            final long wallStart = Calendar.getInstance().getTimeInMillis();
            // iFogSim's Controller calls System.exit() when the simulation ends, so the
            // machine-readable summary is written from a shutdown hook.
            if (h == null)
                Runtime.getRuntime().addShutdownHook(new Thread(() -> writeSummary(loops, wallStart)));

            TimeKeeper.getInstance().setSimulationStartTime(wallStart);
            if (h != null) h.beforeStart(application, controller);
            CloudSim.startSimulation();
            if (h == null) {
                CloudSim.stopSimulation();
            } else {
                writeSummary(loops, wallStart);
            }
        } finally {
            hooks = null;
        }
    }

    // ------------------------------------------------------------------ results

    private static void writeSummary(List<AppLoop> loops, long wallStart) {
        double loopLatency = Double.NaN;
        TimeKeeper tk = TimeKeeper.getInstance();
        if (!loops.isEmpty() && tk.getLoopIdToCurrentAverage().get(loops.get(0).getLoopId()) != null)
            loopLatency = tk.getLoopIdToCurrentAverage().get(loops.get(0).getLoopId());

        double eCloud = 0, eIsp = 0, eFog = 0, eNodes = 0, cost = 0;
        for (FogDevice d : fogDevices) {
            double e = d.getEnergyConsumption();
            if (d.getName().equals("cloud")) { eCloud += e; cost = d.getTotalCost(); }
            else if (d.getName().startsWith("isp")) eIsp += e;
            else if (d.getName().startsWith("fog-gw-")) eFog += e;
            else eNodes += e;
        }
        double network = NetworkUsageMonitor.getNetworkUsage() / Config.MAX_SIMULATION_TIME;
        Double cpuAnalyzer = tk.getTupleTypeToAverageCpuTime().get("FILTERED_DATA");
        long wall = Calendar.getInstance().getTimeInMillis() - wallStart;

        System.out.println("=========== AIR QUALITY SUMMARY ===========");
        System.out.printf(Locale.US, "Mode                       : %s%n", mode);
        System.out.printf(Locale.US, "Sensor nodes               : %d (%d areas x %d)%n", numAreas * nodesPerArea, numAreas, nodesPerArea);
        System.out.printf(Locale.US, "Sense->AQI->Display latency: %.3f ms%n", loopLatency);
        System.out.printf(Locale.US, "AQI analysis CPU delay     : %.3f ms%n", cpuAnalyzer == null ? Double.NaN : cpuAnalyzer);
        System.out.printf(Locale.US, "Network usage              : %.2f bytes/ms%n", network);
        System.out.printf(Locale.US, "Energy cloud / fog / nodes : %.1f / %.1f / %.1f J%n", eCloud, eFog, eNodes);
        System.out.printf(Locale.US, "Total energy               : %.1f J%n", eCloud + eIsp + eFog + eNodes);
        System.out.printf(Locale.US, "Cloud execution cost       : %.2f%n", cost);
        System.out.println("===========================================");

        if (resultsCsv == null) return;
        try {
            File f = new File(resultsCsv);
            if (f.getParentFile() != null) f.getParentFile().mkdirs();
            boolean header = !f.exists();
            try (PrintWriter pw = new PrintWriter(new FileWriter(f, true))) {
                if (header)
                    pw.println("mode,areas,nodes_per_area,total_nodes,sensing_interval,loop_latency_ms,analyzer_cpu_ms,"
                            + "network_usage,energy_cloud,energy_isp,energy_fog,energy_nodes,energy_total,cloud_cost,"
                            + "forward_ratio,alert_ratio,wall_ms");
                pw.printf(Locale.US, "%s,%d,%d,%d,%.1f,%.4f,%.4f,%.3f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.4f,%.4f,%d%n",
                        mode, numAreas, nodesPerArea, numAreas * nodesPerArea, sensingInterval, loopLatency,
                        cpuAnalyzer == null ? Double.NaN : cpuAnalyzer, network, eCloud, eIsp, eFog, eNodes,
                        eCloud + eIsp + eFog + eNodes, cost, forwardRatio, alertRatio, wall);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ----------------------------------------------------------------- topology

    private static void createFogDevices(int userId, String appId) {
        // name, MIPS, RAM(MB), upBw, downBw, level, cost/MIPS, busy W, idle W
        FogDevice cloud = createFogDevice("cloud", 44800, 40000, 100, 10000, 0, 0.01, 16 * 103, 16 * 83.25);
        cloud.setParentId(-1);
        fogDevices.add(cloud);

        FogDevice isp = createFogDevice("isp-gateway", 2800, 4000, 10000, 10000, 1, 0.0, 107.339, 83.4333);
        isp.setParentId(cloud.getId());
        isp.setUplinkLatency(100); // WAN latency to the cloud data centre
        fogDevices.add(isp);

        for (int a = 0; a < numAreas; a++) addArea(a, userId, appId, isp.getId());
    }

    private static void addArea(int a, int userId, String appId, int parentId) {
        // Raspberry Pi 4 class fog gateway (quad-core ~ 4000 MIPS, 4 GB)
        FogDevice gw = createFogDevice("fog-gw-" + a, 4000, 4000, 10000, 10000, 2, 0.0, 7.6, 2.7);
        gw.setParentId(parentId);
        gw.setUplinkLatency(4);
        fogDevices.add(gw);
        for (int n = 0; n < nodesPerArea; n++) {
            String id = a + "-" + n;
            // ESP32 class sensor node (dual-core 240 MHz ~ 600 MIPS, 520 kB SRAM + 4 MB PSRAM; RAM is modelled generously so the 10 MB module fits)
            FogDevice node = createFogDevice("node-" + id, 600, 512, 270, 270, 3, 0.0, 0.8, 0.2);
            node.setParentId(gw.getId());
            node.setUplinkLatency(2); // Wi-Fi + MQTT hop to the area gateway
            fogDevices.add(node);

            Sensor s = hooks == null
                    ? new Sensor("aqs-" + id, "AQ_SENSOR", userId, appId, new DeterministicDistribution(sensingInterval))
                    : hooks.createSensor("aqs-" + id, "AQ_SENSOR", userId, appId,
                    new DeterministicDistribution(sensingInterval), a, n);
            s.setGatewayDeviceId(node.getId());
            s.setLatency(1.0);
            sensors.add(s);

            Actuator act = hooks == null
                    ? new Actuator("ind-" + id, userId, appId, "AQI_INDICATOR")
                    : hooks.createActuator("ind-" + id, userId, appId, "AQI_INDICATOR", a, n);
            act.setGatewayDeviceId(node.getId());
            act.setLatency(1.0);
            actuators.add(act);
        }
    }

    private static FogDevice createFogDevice(String nodeName, long mips, int ram, long upBw, long downBw,
                                             int level, double ratePerMips, double busyPower, double idlePower) {
        List<Pe> peList = new ArrayList<>();
        peList.add(new Pe(0, new PeProvisionerOverbooking(mips)));
        int hostId = FogUtils.generateEntityId();
        PowerHost host = new PowerHost(hostId, new RamProvisionerSimple(ram), new BwProvisionerOverbooking(10000),
                1000000, peList, new StreamOperatorScheduler(peList), new FogLinearPowerModel(busyPower, idlePower));
        List<Host> hostList = new ArrayList<>();
        hostList.add(host);
        FogDeviceCharacteristics ch = new FogDeviceCharacteristics("x86", "Linux", "Xen", host, 10.0,
                3.0, 0.05, 0.001, 0.0);
        FogDevice dev = null;
        try {
            dev = hooks == null
                    ? new FogDevice(nodeName, ch, new AppModuleAllocationPolicy(hostList), new LinkedList<Storage>(),
                    10, upBw, downBw, 0, ratePerMips)
                    : hooks.createFogDevice(nodeName, ch, new AppModuleAllocationPolicy(hostList),
                    new LinkedList<Storage>(), 10, upBw, downBw, 0, ratePerMips, level, busyPower, idlePower, ram);
        } catch (Exception e) {
            e.printStackTrace();
        }
        dev.setLevel(level);
        return dev;
    }

    // -------------------------------------------------------------- application

    @SuppressWarnings("serial")
    private static Application createApplication(String appId, int userId) {
        Application app = hooks == null ? Application.createApplication(appId, userId)
                : hooks.createApplication(appId, userId);

        app.addAppModule("data_filter", 10);    // validation, median filter, dead-band
        app.addAppModule("aqi_analyzer", 10);   // EPA AQI computation, alerting, short-term trend
        app.addAppModule("cloud_storage", 10);  // long-term storage, city-wide analytics, threshold tuning

        // edges: source, destination, [periodicity], tupleCpuLength (MI), tupleNwLength (bytes), type, direction, edgeType
        app.addAppEdge("AQ_SENSOR", "data_filter", 1000, 400, "AQ_SENSOR", Tuple.UP, AppEdge.SENSOR);
        app.addAppEdge("data_filter", "aqi_analyzer", 2500, 200, "FILTERED_DATA", Tuple.UP, AppEdge.MODULE);
        app.addAppEdge("aqi_analyzer", "data_filter", 200, 64, "AQI_STATUS", Tuple.DOWN, AppEdge.MODULE);
        app.addAppEdge("data_filter", "AQI_INDICATOR", 100, 32, "AQI_DISPLAY", Tuple.DOWN, AppEdge.ACTUATOR);
        app.addAppEdge("aqi_analyzer", "cloud_storage", 1000, 1000, 2000, "AQI_SUMMARY", Tuple.UP, AppEdge.MODULE);
        app.addAppEdge("aqi_analyzer", "cloud_storage", 500, 300, "PUBLIC_ALERT", Tuple.UP, AppEdge.MODULE);
        app.addAppEdge("cloud_storage", "aqi_analyzer", 5000, 300, 500, "THRESHOLD_UPDATE", Tuple.DOWN, AppEdge.MODULE);

        app.addTupleMapping("data_filter", "AQ_SENSOR", "FILTERED_DATA", selectivity("data_filter", "AQ_SENSOR", "FILTERED_DATA", forwardRatio));
        app.addTupleMapping("aqi_analyzer", "FILTERED_DATA", "AQI_STATUS", selectivity("aqi_analyzer", "FILTERED_DATA", "AQI_STATUS", 1.0));
        app.addTupleMapping("aqi_analyzer", "FILTERED_DATA", "PUBLIC_ALERT", selectivity("aqi_analyzer", "FILTERED_DATA", "PUBLIC_ALERT", alertRatio));
        app.addTupleMapping("data_filter", "AQI_STATUS", "AQI_DISPLAY", selectivity("data_filter", "AQI_STATUS", "AQI_DISPLAY", 1.0));

        final AppLoop loop = new AppLoop(new ArrayList<String>() {{
            add("AQ_SENSOR"); add("data_filter"); add("aqi_analyzer"); add("data_filter"); add("AQI_INDICATOR");
        }});
        app.setLoops(new ArrayList<AppLoop>() {{ add(loop); }});
        return app;
    }

    /** Fractional selectivity with the calibrated ratio, or the dashboard's data-driven one. */
    private static SelectivityModel selectivity(String module, String in, String out, double ratio) {
        return hooks == null ? new FractionalSelectivity(ratio) : hooks.createSelectivity(module, in, out, ratio);
    }
}
