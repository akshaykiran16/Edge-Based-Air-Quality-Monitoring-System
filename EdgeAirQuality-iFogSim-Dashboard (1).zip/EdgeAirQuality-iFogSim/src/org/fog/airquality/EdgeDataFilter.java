package org.fog.airquality;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Deque;

/**
 * Edge pre-processing done by the "data_filter" module on each sensor node.
 *
 * 1. Range validation: physically impossible values (negative, or above the
 *    sensor's measuring range) are marked invalid.
 * 2. Stuck-sensor detection: an all-zero particulate + CO sample is invalid.
 * 3. Spike suppression: a sample more than SPIKE_RATIO times the median of the
 *    last WINDOW valid samples is replaced by that median (median filter).
 * 4. Change-based forwarding (dead-band): a sample whose PM2.5 changed by less
 *    than DEADBAND ug/m3 since the last forwarded one is not sent upstream, which
 *    is how the edge reduces the amount of data leaving the station.
 */
public final class EdgeDataFilter {

    public static final int WINDOW = 5;
    public static final double SPIKE_RATIO = 3.0;
    public static final double PM_MAX = 1000;   // typical optical PM sensor range, ug/m3
    public static final double DEADBAND = 1.5;  // ug/m3

    private final Deque<Double> history = new ArrayDeque<>();
    private Double lastForwardedPm25 = null;

    public int invalid, smoothed, suppressed, forwarded;

    public enum Outcome { DROPPED_INVALID, SUPPRESSED_NO_CHANGE, FORWARDED }

    /** Holds the filter decision and the (possibly corrected) sample. */
    public static final class Decision {
        public final Outcome outcome;
        public final SensorReading reading;
        Decision(Outcome o, SensorReading r) { outcome = o; reading = r; }
    }

    public Decision process(SensorReading r) {
        if (r.pm25 < 0 || r.pm10 < 0 || r.co < 0 || r.pm25 > PM_MAX || r.pm10 > PM_MAX
                || (r.pm25 == 0 && r.pm10 == 0 && r.co == 0)) {
            invalid++;
            return new Decision(Outcome.DROPPED_INVALID, r);
        }
        SensorReading clean = r;
        if (history.size() >= 3) {
            double med = median();
            if (r.pm25 > SPIKE_RATIO * med) {
                double ratio = r.pm10 / Math.max(r.pm25, 1e-6);
                clean = r.with(med, med * Math.min(ratio, 2.2), r.co, r.no2, r.o3);
                smoothed++;
            }
        }
        history.addLast(clean.pm25);
        if (history.size() > WINDOW) history.removeFirst();

        if (lastForwardedPm25 != null && Math.abs(clean.pm25 - lastForwardedPm25) < DEADBAND) {
            suppressed++;
            return new Decision(Outcome.SUPPRESSED_NO_CHANGE, clean);
        }
        lastForwardedPm25 = clean.pm25;
        forwarded++;
        return new Decision(Outcome.FORWARDED, clean);
    }

    private double median() {
        double[] a = history.stream().mapToDouble(Double::doubleValue).toArray();
        Arrays.sort(a);
        return a.length % 2 == 1 ? a[a.length / 2] : (a[a.length / 2 - 1] + a[a.length / 2]) / 2;
    }
}
