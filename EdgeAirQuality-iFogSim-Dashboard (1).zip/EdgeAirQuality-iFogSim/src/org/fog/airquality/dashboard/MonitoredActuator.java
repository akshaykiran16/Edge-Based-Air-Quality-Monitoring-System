package org.fog.airquality.dashboard;

import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.core.SimEvent;
import org.fog.entities.Actuator;
import org.fog.entities.Tuple;
import org.fog.utils.FogEvents;

/** iFogSim Actuator (the AQI indicator) that reports each completed sense-to-display loop. */
public class MonitoredActuator extends Actuator {

    private final MetricsCollector collector;

    public MonitoredActuator(String name, int userId, String appId, String actuatorType, MetricsCollector collector) {
        super(name, userId, appId, actuatorType);
        this.collector = collector;
    }

    @Override
    public void processEvent(SimEvent ev) {
        if (ev.getTag() == FogEvents.TUPLE_ARRIVAL && ev.getData() instanceof Tuple)
            collector.onActuatorTuple((Tuple) ev.getData(), CloudSim.clock());
        super.processEvent(ev);
    }
}
