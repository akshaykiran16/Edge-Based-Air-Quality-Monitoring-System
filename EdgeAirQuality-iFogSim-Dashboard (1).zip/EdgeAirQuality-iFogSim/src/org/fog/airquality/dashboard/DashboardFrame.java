package org.fog.airquality.dashboard;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.geom.RoundRectangle2D;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.table.AbstractTableModel;

import org.fog.airquality.dashboard.Snapshot.ActivityEvent;
import org.fog.airquality.dashboard.Snapshot.AlertRecord;
import org.fog.airquality.dashboard.Snapshot.AlertType;
import org.fog.airquality.dashboard.Snapshot.DeviceRow;
import org.fog.airquality.dashboard.Snapshot.SensorRow;
import org.fog.airquality.dashboard.Snapshot.Severity;
import org.fog.airquality.dashboard.ui.BarChart;
import org.fog.airquality.dashboard.ui.Card;
import org.fog.airquality.dashboard.ui.Icons;
import org.fog.airquality.dashboard.ui.Icons.Kind;
import org.fog.airquality.dashboard.ui.KpiCard;
import org.fog.airquality.dashboard.ui.LineChart;
import org.fog.airquality.dashboard.ui.Theme;
import org.fog.airquality.dashboard.ui.Widgets;
import org.fog.airquality.dashboard.ui.Widgets.Feed;
import org.fog.airquality.dashboard.ui.Widgets.FeedItem;
import org.fog.airquality.dashboard.ui.Widgets.NodeTile;
import org.fog.airquality.dashboard.ui.Widgets.ResponsiveGrid;
import org.fog.airquality.dashboard.ui.Widgets.StatTile;
import org.fog.airquality.dashboard.ui.Widgets.StatusPill;

/**
 * The single-window live dashboard. Everything shown here is updated from {@link Snapshot}s of the
 * running iFogSim simulation and from the Fog vs Cloud experiment runs.
 */
public final class DashboardFrame extends JFrame implements SimulationEngine.Listener {

    private final SimulationEngine engine = new SimulationEngine(this);
    private final ComparisonRunner comparison = new ComparisonRunner();

    // controls
    private final JComboBox<String> modeBox = combo("Edge / Fog (proposed)", "Cloud-only", "Edge-ward (iFogSim)");
    private final JComboBox<String> sensorBox = combo("20 sensors (4 areas x 5)", "10 sensors (2 areas x 5)", "4 sensors (2 areas x 2)");
    private final JComboBox<String> intervalBox = combo("10 ms sensing", "5 ms sensing", "20 ms sensing");
    private final JComboBox<String> speedBox = combo("Speed 1x", "Speed 0.5x", "Speed 2x", "Speed 5x", "Max speed");
    private final JButton startBtn = button("Start", Kind.PLAY, true);
    private final JButton pauseBtn = button("Pause", Kind.PAUSE, false);
    private final JButton stopBtn = button("Stop", Kind.STOP, false);
    private final JButton resetBtn = button("Reset", Kind.RESET, false);

    // top bar
    private final StatusPill systemPill = new StatusPill("System", "Offline", Theme.OFFLINE);
    private final StatusPill simPill = new StatusPill("Simulation", "Loading", Theme.BLUE);
    private final JLabel clockLabel = label("t = 0.00 s / 10 s", Theme.BODY_BOLD, Theme.TEXT);
    private final JLabel dayLabel = label("Day clock 00:00", Theme.SMALL, Theme.TEXT_2);
    private final Widgets.Progress progress = new Widgets.Progress();
    private final JLabel banner = new JLabel(" ");
    private final JLabel configLabel = label(" ", Theme.SMALL, Theme.TEXT_2);

    // overview
    private final KpiCard kAqi = new KpiCard("City AQI", Kind.WIND, Theme.CYAN, true);
    private final KpiCard kTemp = new KpiCard("Temperature", Kind.THERMO, Theme.series(1), true);
    private final KpiCard kHum = new KpiCard("Humidity", Kind.DROP, Theme.BLUE, true);
    private final KpiCard kSensors = new KpiCard("Active sensors", Kind.SENSOR, Theme.series(2), true);
    private final KpiCard kFog = new KpiCard("Fog nodes", Kind.FOG, Theme.PURPLE, true);
    private final KpiCard kAlerts = new KpiCard("Alerts", Kind.ALERT, Theme.WARNING, true);
    private final StatTile oSensors = new StatTile("Total sensors", Kind.SENSOR, Theme.CYAN);
    private final StatTile oFog = new StatTile("Total fog nodes", Kind.FOG, Theme.CYAN);
    private final StatTile oGw = new StatTile("Total gateways", Kind.GATEWAY, Theme.CYAN);
    private final StatTile oCloud = new StatTile("Cloud status", Kind.CLOUD, Theme.OFFLINE);
    private final StatTile oGen = new StatTile("Packets generated", Kind.PACKET, Theme.BLUE);
    private final StatTile oProc = new StatTile("Packets processed", Kind.CHECK, Theme.BLUE);
    private final StatTile oAlerts = new StatTile("Alerts generated", Kind.ALERT, Theme.WARNING);
    private final StatTile oSystem = new StatTile("System status", Kind.ACTIVITY, Theme.OFFLINE);
    private final JPanel nodeStrip = new JPanel(new ResponsiveGrid(150, 8, 12));
    private final List<NodeTile> nodeTiles = new ArrayList<>();

    // alerts
    private final StatTile[] alertTiles = new StatTile[AlertType.values().length];
    private final Feed alertFeed = new Feed(150, "No alerts yet. All readings are normal.", true);
    private final Feed activityFeed = new Feed(150, "Waiting for simulation events…", false);
    private Card alertCard;

    // tables
    private final SensorModel sensorModel = new SensorModel();
    private final DeviceModel deviceModel = new DeviceModel();
    private JScrollPane sensorScroll;

    // charts
    private final LineChart tempChart = new LineChart("Temperature (°C)", "Simulated time (s)", "%.1f °C");
    private final LineChart humChart = new LineChart("Relative humidity (%)", "Simulated time (s)", "%.1f %%");
    private final LineChart aqiChart = new LineChart("AQI (US EPA)", "Simulated time (s)", "%.0f");
    private final LineChart pmChart = new LineChart("Concentration (µg/m³)", "Simulated time (s)", "%.1f µg/m³");
    private final BarChart fogBars = new BarChart("Tuples", "%,.0f");
    private final LineChart energyChart = new LineChart("Energy (MJ, iFogSim units)", "Simulated time (s)", "%.3f MJ");
    private final LineChart networkChart = new LineChart("Network usage (bytes/ms)", "Simulated time (s)", "%,.0f B/ms");
    private final LineChart latencyChart = new LineChart("Loop latency (ms)", "Simulated time (s)", "%.2f ms");

    // cloud
    private final StatTile cReq = new StatTile("Cloud requests", Kind.CLOUD, Theme.PURPLE);
    private final StatTile cProc = new StatTile("Cloud processing time", Kind.CLOCK, Theme.PURPLE);
    private final StatTile cData = new StatTile("Data transferred to cloud", Kind.NETWORK, Theme.PURPLE);
    private final StatTile cStore = new StatTile("Cloud storage used", Kind.PACKET, Theme.PURPLE);
    private final StatTile cStatus = new StatTile("Cloud status", Kind.ACTIVITY, Theme.OFFLINE);
    private final StatTile cUtil = new StatTile("Cloud CPU utilisation", Kind.CPU, Theme.PURPLE);

    // performance
    private final StatTile pLat = new StatTile("Avg loop latency", Kind.CLOCK, Theme.CYAN);
    private final StatTile pNet = new StatTile("Network usage", Kind.NETWORK, Theme.CYAN);
    private final StatTile pEnergy = new StatTile("Energy consumption", Kind.ENERGY, Theme.CYAN);
    private final StatTile pProc = new StatTile("Avg processing time", Kind.CPU, Theme.CYAN);
    private final StatTile pAlert = new StatTile("Alert response delay", Kind.ALERT, Theme.CYAN);
    private final StatTile pTask = new StatTile("Task completion rate", Kind.CHECK, Theme.CYAN);
    private final StatTile pPdr = new StatTile("Packet delivery ratio", Kind.PACKET, Theme.CYAN);

    // comparison
    private final Map<String, ComparisonRunner.Result> results = new LinkedHashMap<>();
    private final BarChart cmpLatency = new BarChart("Loop latency (ms)", "%.2f ms");
    private final BarChart cmpEnergy = new BarChart("Total energy (MJ)", "%.2f MJ");
    private final BarChart cmpNetwork = new BarChart("Network usage (bytes/ms)", "%,.0f B/ms");
    private final BarChart cmpProc = new BarChart("AQI processing time (ms)", "%.2f ms");
    private final BarChart cmpTask = new BarChart("Task completion rate (%)", "%.2f %%");
    private final JLabel cmpStatus = label("Experiments not started", Theme.BODY, Theme.TEXT_2);
    private final Widgets.Progress cmpProgress = new Widgets.Progress();
    private final JButton cmpBtn = button("Run experiments", Kind.COMPARE, true);
    private final JLabel cmpSummary = new JLabel();
    private final CompareModel cmpModel = new CompareModel();

    // navigation
    private final Widgets.Column content = new Widgets.Column();
    private JScrollPane scroll;
    private final Map<String, JComponent> anchors = new LinkedHashMap<>();
    private final List<NavItem> navItems = new ArrayList<>();

    private int areas = 4;
    private SimulationEngine.RunConfig lastConfig;

    public DashboardFrame() {
        super("EdgeAQ Monitor — Edge-Based Air Quality Monitoring System using iFogSim");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override public void windowClosed(WindowEvent e) { engine.stop(); System.exit(0); }
        });
        getContentPane().setBackground(Theme.BG);
        setLayout(new BorderLayout());
        add(buildSidebar(), BorderLayout.WEST);
        JPanel main = new JPanel(new BorderLayout());
        main.setBackground(Theme.BG);
        main.add(buildTop(), BorderLayout.NORTH);
        buildContent();
        scroll = new JScrollPane(content, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.getViewport().setBackground(Theme.BG);
        scroll.getVerticalScrollBar().setUnitIncrement(28);
        scroll.getVerticalScrollBar().setPreferredSize(new Dimension(10, 0));
        scroll.getVerticalScrollBar().setUI(new DarkScrollBarUI());
        scroll.getViewport().addChangeListener(e -> updateActiveNav());
        main.add(scroll, BorderLayout.CENTER);
        add(main, BorderLayout.CENTER);
        setMinimumSize(new Dimension(1100, 700));
        setSize(1500, 940);
        setLocationRelativeTo(null);
        setExtendedState(getExtendedState() | JFrame.MAXIMIZED_BOTH);
        wireControls();
        resetView();
        onState(SimulationEngine.State.READY, "Ready");
    }

    // ================================================================== layout

    private JComponent buildSidebar() {
        JPanel side = new JPanel() {
            @Override protected void paintComponent(Graphics g0) {
                Graphics2D g = (Graphics2D) g0;
                g.setColor(Theme.SIDEBAR);
                g.fillRect(0, 0, getWidth(), getHeight());
                g.setColor(Theme.BORDER);
                g.drawLine(getWidth() - 1, 0, getWidth() - 1, getHeight());
            }
        };
        side.setLayout(new BoxLayout(side, BoxLayout.Y_AXIS));
        side.setPreferredSize(new Dimension(216, 100));
        side.setBorder(BorderFactory.createEmptyBorder(18, 14, 18, 14));
        JComponent logo = new JComponent() {
            @Override protected void paintComponent(Graphics g0) {
                Graphics2D g = (Graphics2D) g0.create();
                Theme.smooth(g);
                g.setPaint(new GradientPaint(0, 0, Theme.ACCENT_GRAD_A, 38, 38, Theme.ACCENT_GRAD_B));
                g.fill(new RoundRectangle2D.Double(0, 2, 38, 38, 12, 12));
                Icons.of(Kind.LEAF, 20, Color.WHITE).paintIcon(this, g, 9, 11);
                g.setFont(Theme.H2);
                g.setColor(Theme.TEXT);
                g.drawString("EdgeAQ", 50, 18);
                g.setFont(Theme.SMALL);
                g.setColor(Theme.MUTED);
                g.drawString("Monitor · iFogSim", 50, 35);
                g.dispose();
            }
        };
        fix(logo, 190, 44);
        side.add(logo);
        side.add(Box.createVerticalStrut(26));
        JLabel nav = label("NAVIGATION", Theme.SMALL_BOLD, Theme.MUTED);
        nav.setBorder(BorderFactory.createEmptyBorder(0, 10, 8, 0));
        nav.setAlignmentX(0f);
        side.add(nav);
        String[][] items = {
                {"Overview", "DASHBOARD"}, {"Alerts", "ALERT"}, {"Air Quality", "WIND"}, {"Fog Nodes", "FOG"},
                {"Cloud", "CLOUD"}, {"Performance", "GAUGE"}, {"Fog vs Cloud", "COMPARE"}};
        for (String[] it : items) {
            NavItem n = new NavItem(it[0], Kind.valueOf(it[1]));
            navItems.add(n);
            side.add(n);
            side.add(Box.createVerticalStrut(4));
        }
        side.add(Box.createVerticalGlue());
        JLabel foot = new JLabel("<html><span style='color:#6B7A93'>Data source</span><br><span style='color:#A3B1C8'>Live iFogSim simulation<br>Synthetic sensor readings</span></html>");
        foot.setFont(Theme.SMALL);
        foot.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 0));
        foot.setAlignmentX(0f);
        side.add(foot);
        return side;
    }

    private JComponent buildTop() {
        JPanel top = new JPanel(new BorderLayout());
        top.setBackground(Theme.TOPBAR);
        top.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Theme.BORDER));

        JPanel row1 = new JPanel(new BorderLayout(16, 0));
        row1.setOpaque(false);
        row1.setBorder(BorderFactory.createEmptyBorder(12, 22, 8, 22));
        JPanel titles = new JPanel();
        titles.setOpaque(false);
        titles.setLayout(new BoxLayout(titles, BoxLayout.Y_AXIS));
        titles.add(label("Edge-Based Air Quality Monitoring System", Theme.H1, Theme.TEXT));
        titles.add(configLabel);
        row1.add(titles, BorderLayout.CENTER);
        JPanel statusRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 4));
        statusRow.setOpaque(false);
        JPanel clock = new JPanel();
        clock.setOpaque(false);
        clock.setLayout(new BoxLayout(clock, BoxLayout.Y_AXIS));
        clockLabel.setAlignmentX(1f);
        dayLabel.setAlignmentX(1f);
        progress.setAlignmentX(1f);
        fix(progress, 170, 10);
        clock.add(clockLabel);
        clock.add(Box.createVerticalStrut(3));
        clock.add(progress);
        clock.add(Box.createVerticalStrut(3));
        clock.add(dayLabel);
        statusRow.add(clock);
        statusRow.add(Box.createHorizontalStrut(8));
        statusRow.add(systemPill);
        statusRow.add(simPill);
        row1.add(statusRow, BorderLayout.EAST);
        top.add(row1, BorderLayout.NORTH);

        JPanel row2 = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        row2.setOpaque(false);
        row2.setBorder(BorderFactory.createEmptyBorder(0, 16, 10, 16));
        row2.add(modeBox);
        row2.add(sensorBox);
        row2.add(intervalBox);
        row2.add(speedBox);
        row2.add(Box.createHorizontalStrut(10));
        row2.add(startBtn);
        row2.add(pauseBtn);
        row2.add(stopBtn);
        row2.add(resetBtn);
        top.add(row2, BorderLayout.CENTER);

        banner.setOpaque(true);
        banner.setFont(Theme.SMALL_BOLD);
        banner.setBorder(BorderFactory.createEmptyBorder(6, 22, 6, 22));
        top.add(banner, BorderLayout.SOUTH);
        return top;
    }

    private void buildContent() {
        content.setBorder(BorderFactory.createEmptyBorder(0, 22, 30, 22));

        // ---------------- A. overview
        section("Overview", "System overview", "Live KPIs of the running simulation", Kind.DASHBOARD);
        JPanel kpis = grid(170, 6);
        for (KpiCard k : Arrays.asList(kAqi, kTemp, kHum, kSensors, kFog, kAlerts)) kpis.add(k);
        add(kpis);
        gap(16);
        JPanel ov = grid(128, 8, 12);
        for (StatTile t : Arrays.asList(oSensors, oFog, oGw, oCloud, oGen, oProc, oAlerts, oSystem)) ov.add(t);
        Card ovCard = new Card("System overview", "Counts and states read from the iFogSim entities", Kind.ACTIVITY, ov);
        add(ovCard);
        gap(16);
        nodeStrip.setOpaque(false);
        add(new Card("Infrastructure status", "Edge / fog nodes, gateway and cloud. Bar = CPU utilisation", Kind.NETWORK, nodeStrip));

        // ---------------- F. alerts (kept high on the page so it is noticed)
        section("Alerts", "Alert management", "Thresholds evaluated by the aqi_analyzer and edge filter modules", Kind.ALERT);
        JPanel ag = grid(330, 3);
        JPanel tiles = grid(140, 2, 10);
        AlertType[] types = AlertType.values();
        for (int i = 0; i < types.length; i++) {
            alertTiles[i] = new StatTile(types[i].label, Kind.ALERT, Theme.GOOD);
            tiles.add(alertTiles[i]);
        }
        JLabel legend = new JLabel("<html><span style='color:#22C55E'>●</span> Normal &nbsp; <span style='color:#FAB219'>●</span> Warning &nbsp; <span style='color:#EF4444'>●</span> Critical</html>");
        legend.setFont(Theme.SMALL);
        legend.setForeground(Theme.TEXT_2);
        tiles.add(legend);
        ag.add(new Card("Alert types", "Count of raised alerts and current worst severity", Kind.ALERT, tiles));
        alertCard = new Card("Live alerts", "Newest first", Kind.ALERT, feedScroll(alertFeed));
        ag.add(alertCard);
        ag.add(new Card("Recent activity", "Latest simulation events", Kind.ACTIVITY, feedScroll(activityFeed)));
        add(ag);

        // ---------------- B. air quality
        section("Air Quality", "Live air quality monitoring", "Latest reading of every sensor as seen by the edge pipeline", Kind.WIND);
        JTable st = new JTable(sensorModel);
        st.setDefaultRenderer(Object.class, new Widgets.CellRenderer((t, v, r, c) -> sensorModel.pill(r, c)));
        sensorScroll = Widgets.darkTable(st);
        st.getColumnModel().getColumn(0).setPreferredWidth(95);
        st.getColumnModel().getColumn(1).setPreferredWidth(165);
        st.getColumnModel().getColumn(8).setPreferredWidth(200);
        st.getColumnModel().getColumn(9).setPreferredWidth(170);
        add(new Card("Sensor readings", "Temperature, humidity, particulates and CO2 after EdgeDataFilter; AQI from AQICalculator on the aqi_analyzer", Kind.SENSOR, sensorScroll));
        gap(16);
        JPanel aqCharts = grid(430, 2);
        aqCharts.add(chartCard("Temperature monitoring", "Average per area", Kind.THERMO, tempChart));
        aqCharts.add(chartCard("Humidity monitoring", "Average per area", Kind.DROP, humChart));
        aqiChart.addThreshold(100, "AQI 100 (warning)", Theme.WARNING);
        aqiChart.addThreshold(150, "AQI 150 (critical)", Theme.CRITICAL);
        aqiChart.setYMin(0.0);
        aqCharts.add(chartCard("AQI monitoring", "Average AQI per area, from analysed samples", Kind.WIND, aqiChart));
        pmChart.addSeries("PM2.5 (city avg)", Theme.series(0), true);
        pmChart.addSeries("PM10 (city avg)", Theme.series(1), false);
        pmChart.addThreshold(MetricsCollector.PM25_WARN, "PM2.5 warning 35.4", Theme.WARNING);
        pmChart.setYMin(0.0);
        aqCharts.add(chartCard("PM2.5 and PM10", "City average of the latest valid readings", Kind.WIND, pmChart));
        add(aqCharts);

        // ---------------- C. fog nodes
        section("Fog Nodes", "Fog node monitoring", "Every device of the iFogSim topology", Kind.FOG);
        JTable dt = new JTable(deviceModel);
        dt.setDefaultRenderer(Object.class, new Widgets.CellRenderer((t, v, r, c) -> deviceModel.pill(r, c)));
        int[] dw = {190, 110, 130, 150, 110, 110, 120, 90, 100, 130};
        for (int i = 0; i < dw.length; i++) dt.getColumnModel().getColumn(i).setPreferredWidth(dw[i]);
        JScrollPane ds = Widgets.darkTable(dt);
        deviceScroll = ds;
        add(new Card("Devices", "Tuples received = arrived at the device; tasks processed = module executions finished there", Kind.FOG, ds));
        gap(16);
        fogBars.setSeries(new String[]{"Tuples received", "Tasks processed"}, new Color[]{Theme.series(0), Theme.series(2)});

        // ---------------- D. cloud (shares the row with the processing chart)
        JPanel fogRow = grid(430, 2);
        fogRow.add(chartCard("Fog node processing comparison", "Edge nodes, gateway and cloud (sensor nodes in the table)", Kind.COMPARE, fogBars));
        JPanel ct = grid(160, 3, 10);
        for (StatTile t : Arrays.asList(cReq, cProc, cData, cStore, cStatus, cUtil)) ct.add(t);
        Card cloudCard = new Card("Cloud monitoring", "cloud_storage module in the data centre", Kind.CLOUD, ct);
        anchors.put("Cloud", cloudCard);
        fogRow.add(cloudCard);
        add(fogRow);

        // ---------------- E. performance
        section("Performance", "Performance metrics", "Computed from the simulation clock, iFogSim power model and network monitor", Kind.GAUGE);
        JPanel pt = grid(140, 7, 12);
        for (StatTile t : Arrays.asList(pLat, pNet, pEnergy, pProc, pAlert, pTask, pPdr)) pt.add(t);
        add(new Card(null, null, null, pt));
        gap(16);
        JPanel pc = grid(380, 3);
        energyChart.addSeries("Total energy", Theme.series(0), true);
        energyChart.setYMin(0.0);
        networkChart.addSeries("Per 50 ms window", Theme.series(0), true);
        networkChart.addSeries("Running average", Theme.series(1), false);
        networkChart.setYMin(0.0);
        latencyChart.addSeries("Per 50 ms window", Theme.series(0), true);
        latencyChart.addSeries("Running average", Theme.series(1), false);
        latencyChart.setYMin(0.0);
        pc.add(chartCard("Energy consumption", "Cumulative, all devices", Kind.ENERGY, energyChart));
        pc.add(chartCard("Network usage", "Sum of latency x tuple size, per ms", Kind.NETWORK, networkChart));
        pc.add(chartCard("Loop latency", "Sensor → data_filter → aqi_analyzer → indicator", Kind.CLOCK, latencyChart));
        add(pc);

        // ---------------- comparison
        section("Fog vs Cloud", "Fog vs Cloud comparison", "Separate full simulation runs: Edge/Fog placement vs Cloud-only, 10 ms sensing", Kind.COMPARE);
        JPanel bar = new JPanel(new BorderLayout(14, 0));
        bar.setOpaque(false);
        JPanel left = new JPanel();
        left.setOpaque(false);
        left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        cmpStatus.setAlignmentX(0f);
        cmpProgress.setAlignmentX(0f);
        fix(cmpProgress, 420, 10);
        left.add(cmpStatus);
        left.add(Box.createVerticalStrut(6));
        left.add(cmpProgress);
        bar.add(left, BorderLayout.CENTER);
        bar.add(cmpBtn, BorderLayout.EAST);
        add(new Card("Experiments", "Each run is the real simulation in its own JVM (ExperimentRunner): 4, 10 and 20 sensors × 2 placements", Kind.COMPARE, bar));
        gap(16);
        JPanel cg = grid(360, 3);
        String[] sn = {"Edge / Fog", "Cloud-only"};
        Color[] sc = {Theme.series(0), Theme.series(1)};
        for (BarChart b : Arrays.asList(cmpLatency, cmpEnergy, cmpNetwork, cmpProc, cmpTask)) {
            b.setSeries(sn, sc);
            b.setEmptyText("Run the experiments to fill this chart");
        }
        cg.add(chartCard("Average latency", "Lower is better", Kind.CLOCK, cmpLatency));
        cg.add(chartCard("Energy consumption", "Lower is better", Kind.ENERGY, cmpEnergy));
        cg.add(chartCard("Network usage", "Lower is better", Kind.NETWORK, cmpNetwork));
        cg.add(chartCard("Processing time", "aqi_analyzer execution time per sample, lower is better", Kind.CPU, cmpProc));
        cg.add(chartCard("Task completion rate", "Higher is better", Kind.CHECK, cmpTask));
        cmpSummary.setFont(Theme.BODY);
        cmpSummary.setForeground(Theme.TEXT_2);
        cmpSummary.setVerticalAlignment(JLabel.TOP);
        JTable ctab = new JTable(cmpModel);
        ctab.getColumnModel().getColumn(0).setPreferredWidth(150);
        ctab.setDefaultRenderer(Object.class, new Widgets.CellRenderer(null));
        JScrollPane cts = Widgets.darkTable(ctab);
        fix(cts, 300, 30 * 7 + 34);
        add(cg);
        gap(16);
        JPanel sumRow = grid(500, 2);
        sumRow.add(new Card("Summary", "Which architecture performs better", Kind.CHECK, cmpSummary));
        sumRow.add(new Card("All experiment results", "One row per simulation run", Kind.COMPARE, cts));
        add(sumRow);
        updateComparisonCharts();
    }

    private JScrollPane deviceScroll;

    // ================================================================== controls

    private void wireControls() {
        startBtn.addActionListener(e -> startSimulation());
        pauseBtn.addActionListener(e -> {
            if (engine.getState() == SimulationEngine.State.PAUSED) engine.resume(); else engine.pause();
        });
        stopBtn.addActionListener(e -> engine.stop());
        resetBtn.addActionListener(e -> {
            engine.stop();
            new Thread(() -> {
                engine.awaitIdle(5000);
                SwingUtilities.invokeLater(() -> { resetView(); onState(SimulationEngine.State.READY, "Reset. Choose a configuration and press Start"); });
            }).start();
        });
        speedBox.addActionListener(e -> engine.setSpeed(speedValue()));
        cmpBtn.addActionListener(e -> startComparison());
    }

    private double speedValue() {
        switch (speedBox.getSelectedIndex()) {
            case 1: return 125;
            case 2: return 500;
            case 3: return 1250;
            case 4: return 0;
            default: return 250;
        }
    }

    public void startSimulation() {
        String mode = new String[]{"edge", "cloud", "edgewards"}[modeBox.getSelectedIndex()];
        int[][] sz = {{4, 5}, {2, 5}, {2, 2}};
        int[] s = sz[sensorBox.getSelectedIndex()];
        double iv = new double[]{10, 5, 20}[intervalBox.getSelectedIndex()];
        engine.setSpeed(speedValue());
        engine.start(new SimulationEngine.RunConfig(mode, s[0], s[1], iv));
    }

    public void startComparison() {
        if (comparison.isRunning()) return;
        results.clear();
        updateComparisonCharts();
        cmpBtn.setEnabled(false);
        comparison.start(new ComparisonRunner.Listener() {
            @Override public void onProgress(int done, int total, String message) {
                cmpProgress.set(done / (double) total, Theme.CYAN);
                cmpStatus.setText(message + "  (" + done + " / " + total + ")");
            }
            @Override public void onResult(ComparisonRunner.Result r) {
                results.put(r.mode + r.sensors, r);
                updateComparisonCharts();
            }
            @Override public void onFinished(List<ComparisonRunner.Result> all, String error) {
                cmpBtn.setEnabled(true);
                cmpBtn.setText("Run again");
                cmpStatus.setText(error == null ? "All " + all.size() + " experiments finished" : "Finished with an error: " + error);
                cmpStatus.setForeground(error == null ? Theme.TEXT_2 : Theme.CRITICAL);
                updateComparisonCharts();
            }
        });
    }

    // ================================================================== engine callbacks

    @Override
    public void onStarted(SimulationEngine.RunConfig cfg) {
        lastConfig = cfg;
        areas = cfg.areas;
        resetView();
        configLabel.setText("Live iFogSim run · " + modeName(cfg.mode) + " placement · " + cfg.sensors() + " sensors ("
                + cfg.areas + " areas × " + cfg.nodesPerArea + ") · " + (int) cfg.interval + " ms sensing interval · 10 s simulated (one replayed day)");
        for (LineChart c : Arrays.asList(tempChart, humChart, aqiChart)) {
            c.clearSeries();
            for (int a = 0; a < cfg.areas; a++) c.addSeries("Area " + (a + 1), Theme.series(a), false);
        }
        aqiChart.addSeries("City average", Theme.series(5), false);
    }

    @Override
    public void onState(SimulationEngine.State st, String message) {
        boolean busy = st == SimulationEngine.State.INITIALIZING || st == SimulationEngine.State.RUNNING || st == SimulationEngine.State.PAUSED;
        startBtn.setEnabled(!busy);
        pauseBtn.setEnabled(st == SimulationEngine.State.RUNNING || st == SimulationEngine.State.PAUSED);
        pauseBtn.setText(st == SimulationEngine.State.PAUSED ? "Resume" : "Pause");
        pauseBtn.setIcon(Icons.of(st == SimulationEngine.State.PAUSED ? Kind.PLAY : Kind.PAUSE, 12, Theme.TEXT));
        stopBtn.setEnabled(busy);
        resetBtn.setEnabled(st != SimulationEngine.State.INITIALIZING);
        modeBox.setEnabled(!busy);
        sensorBox.setEnabled(!busy);
        intervalBox.setEnabled(!busy);
        startBtn.setText(st == SimulationEngine.State.COMPLETED || st == SimulationEngine.State.STOPPED || st == SimulationEngine.State.ERROR ? "Run again" : "Start");
        Color c;
        String t;
        switch (st) {
            case INITIALIZING: c = Theme.BLUE; t = "Loading"; break;
            case RUNNING: c = Theme.CYAN; t = "Running"; break;
            case PAUSED: c = Theme.WARNING; t = "Paused"; break;
            case COMPLETED: c = Theme.GOOD; t = "Completed"; break;
            case STOPPED: c = Theme.OFFLINE; t = "Stopped"; break;
            case ERROR: c = Theme.CRITICAL; t = "Error"; break;
            default: c = Theme.OFFLINE; t = "Ready";
        }
        simPill.set(t, c, st == SimulationEngine.State.RUNNING || st == SimulationEngine.State.INITIALIZING);
        if (!busy) systemPill.set("Offline", Theme.OFFLINE, false);
        else if (st == SimulationEngine.State.PAUSED) systemPill.set("Paused", Theme.WARNING, false);
        Color bg = st == SimulationEngine.State.ERROR ? new Color(0x3A1418) : st == SimulationEngine.State.COMPLETED ? new Color(0x0E2A1C)
                : st == SimulationEngine.State.PAUSED ? new Color(0x33280C) : new Color(0x0D1A33);
        banner.setBackground(bg);
        banner.setForeground(Theme.mix(c, Color.WHITE, 0.25));
        String prefix;
        switch (st) {
            case INITIALIZING: prefix = "Initialising simulation: "; break;
            case RUNNING: prefix = "Simulation running. All panels update live from iFogSim events. "; break;
            case COMPLETED: prefix = "Simulation completed. Final results are shown. "; break;
            case ERROR: prefix = "Simulation error: "; break;
            case STOPPED: prefix = "Simulation stopped. "; break;
            default: prefix = "";
        }
        banner.setText(prefix + (st == SimulationEngine.State.RUNNING ? "Use Pause, Stop or the speed selector at any time." : message));
        banner.setIcon(Icons.of(st == SimulationEngine.State.ERROR ? Kind.ALERT : Kind.ACTIVITY, 14, banner.getForeground()));
        if (st == SimulationEngine.State.COMPLETED || st == SimulationEngine.State.STOPPED) {
            for (NodeTile n : nodeTiles) n.repaint();
        }
    }

    @Override
    public void onSnapshot(Snapshot s) {
        double t = s.simTime / 1000.0;
        clockLabel.setText(String.format(Locale.US, "t = %.2f s / %.0f s", t, s.maxSimTime / 1000));
        dayLabel.setText(String.format(Locale.US, "Day clock %02d:%02d · %,d events", s.dayMinute / 60, s.dayMinute % 60, s.tuplesGenerated));
        progress.set(s.simTime / s.maxSimTime, s.finalSnapshot ? Theme.GOOD : Theme.CYAN);
        boolean live = !s.finalSnapshot && engine.getState() == SimulationEngine.State.RUNNING;
        if (engine.getState() == SimulationEngine.State.RUNNING || engine.getState() == SimulationEngine.State.INITIALIZING)
            systemPill.set(s.systemStatus, "Degraded".equals(s.systemStatus) ? Theme.WARNING : Theme.GOOD, true);

        // KPIs
        int cityAqi = Double.isNaN(s.city.aqi) ? -1 : (int) Math.round(s.city.aqi);
        kAqi.set(cityAqi < 0 ? "—" : String.valueOf(cityAqi), "US EPA", s.analysedSamples + " samples analysed by aqi_analyzer");
        kAqi.setAccent(Theme.aqi(cityAqi));
        if (cityAqi >= 0) kAqi.setChip(shortCategory(org.fog.airquality.AQICalculator.categoryOf(cityAqi)), Theme.aqi(cityAqi));
        kAqi.addSpark(s.city.aqi);
        kTemp.set(Widgets.num(s.city.temperature, "%.1f"), "°C", "City average of the latest valid readings");
        kTemp.addSpark(s.city.temperature);
        kHum.set(Widgets.num(s.city.humidity, "%.1f"), "%", "Relative humidity, city average");
        kHum.addSpark(s.city.humidity);
        int reporting = 0, faulty = 0;
        for (SensorRow r : s.sensors) { if (r.hasReading) reporting++; if (r.severity == Severity.CRITICAL) faulty++; }
        kSensors.set(reporting + " / " + s.totalSensors, "", String.format(Locale.US, "%,d packets sent · PDR %s", s.packetsGenerated, Widgets.num(s.packetDeliveryRatio, "%.2f%%")));
        int fogOnline = 0;
        for (DeviceRow d : s.devices) if (d.role.startsWith("Edge") && d.health != Severity.CRITICAL) fogOnline++;
        kFog.set(fogOnline + " / " + s.totalFogNodes, "online", s.totalGateways + " gateway · 1 cloud data centre");
        kFog.setChip(fogOnline == s.totalFogNodes ? "Healthy" : "Degraded", fogOnline == s.totalFogNodes ? Theme.GOOD : Theme.WARNING);
        kAlerts.set(String.valueOf(s.activeAlerts), "active", String.format(Locale.US, "%,d alerts raised in total", s.alertsTotal));
        Severity worst = Severity.NORMAL;
        for (Severity v : s.alertSeverityByType) if (v.ordinal() > worst.ordinal()) worst = v;
        kAlerts.setAccent(Theme.severity(worst));
        kAlerts.setChip(worst == Severity.NORMAL ? "Normal" : worst == Severity.WARNING ? "Warning" : "Critical", Theme.severity(worst));

        // overview tiles
        oSensors.set(String.valueOf(s.totalSensors), "nodes", s.areas + " areas × " + s.nodesPerArea + " ESP32 nodes");
        oFog.set(String.valueOf(s.totalFogNodes), "edge nodes", "Raspberry Pi class gateways");
        oGw.set(String.valueOf(s.totalGateways), "", "ISP / city gateway");
        oCloud.set(s.cloudStatus, "", String.format(Locale.US, "%,d requests", s.cloudRequests));
        oCloud.setAccent(statusColor(s.cloudStatus));
        oGen.set(String.format(Locale.US, "%,d", s.packetsGenerated), "", String.format(Locale.US, "%,d tuples incl. derived", s.tuplesGenerated));
        oProc.set(String.format(Locale.US, "%,d", s.packetsProcessed), "", String.format(Locale.US, "%,d fwd · %,d suppressed · %,d invalid", s.forwarded, s.suppressed, s.invalidSamples));
        oAlerts.set(String.format(Locale.US, "%,d", s.alertsTotal), "", s.activeAlerts + " currently active");
        oSystem.set(s.systemStatus, "", s.finalSnapshot ? "Run finished" : "Simulation running");
        oSystem.setAccent(statusColor(s.systemStatus));

        updateNodeTiles(s, live);

        // alerts
        for (int i = 0; i < alertTiles.length; i++) {
            Severity v = s.alertSeverityByType[i];
            alertTiles[i].setAccent(Theme.severity(v));
            alertTiles[i].set(String.format(Locale.US, "%,d", s.alertCountByType[i]), "raised", (v == Severity.NORMAL ? "Normal" : v == Severity.WARNING ? "Warning" : "Critical") + " · " + threshold(AlertType.values()[i]));
        }
        for (AlertRecord a : s.newAlerts)
            alertFeed.add(new FeedItem(time(a.simTime), (a.severity == Severity.CRITICAL ? "CRITICAL · " : "WARNING · ") + a.type.label + " · " + a.source,
                    a.message, Theme.severity(a.severity), Kind.ALERT));
        if (!s.newAlerts.isEmpty()) alertFeed.refresh();
        for (ActivityEvent e : s.newEvents) activityFeed.add(new FeedItem(time(e.simTime), eventTitle(e), e.text, eventColor(e), eventIcon(e)));
        if (!s.newEvents.isEmpty()) activityFeed.refresh();
        alertCard.setGlow(worst == Severity.CRITICAL && !s.finalSnapshot ? Theme.CRITICAL : null);

        // tables
        sensorModel.set(s.sensors);
        deviceModel.set(s.devices);
        fix(sensorScroll, 300, Math.min(s.sensors.size(), 20) * 30 + 36);
        fix(deviceScroll, 300, s.devices.size() * 30 + 36);

        // charts
        double[] temp = new double[areas], hum = new double[areas], aqi = new double[areas + 1];
        for (int a = 0; a < areas && a < s.areaValues.size(); a++) {
            temp[a] = s.areaValues.get(a).temperature;
            hum[a] = s.areaValues.get(a).humidity;
            aqi[a] = s.areaValues.get(a).aqi;
        }
        aqi[areas] = s.city.aqi;
        tempChart.add(t, temp);
        humChart.add(t, hum);
        aqiChart.add(t, aqi);
        pmChart.add(t, s.city.pm25, s.city.pm10);
        energyChart.add(t, s.energyTotal / 1e6);
        networkChart.add(t, s.networkRate, s.networkUsage);
        latencyChart.add(t, s.windowLoopLatency, s.avgLoopLatency);
        List<String> cats = new ArrayList<>();
        List<double[]> vals = new ArrayList<>();
        for (DeviceRow d : s.devices) {
            if (d.role.startsWith("Sensor")) continue;
            cats.add(d.label);
            vals.add(new double[]{d.arrivals, d.tasksProcessed});
        }
        double[][] fv = new double[2][cats.size()];
        for (int i = 0; i < cats.size(); i++) { fv[0][i] = vals.get(i)[0]; fv[1][i] = vals.get(i)[1]; }
        fogBars.setData(cats, fv);

        // cloud
        cReq.set(String.format(Locale.US, "%,d", s.cloudRequests), "tuples", String.format(Locale.US, "%,d tasks executed", s.cloudTasks));
        cProc.set(Widgets.num(s.cloudProcessingMs, "%.2f"), "ms", "Average execution time per task");
        cData.set(Widgets.bytes(s.cloudBytesIn), "", "Tuple payloads that reached the cloud");
        cStore.set(Widgets.bytes(s.cloudStorageBytes), "", "Received by cloud_storage (AQI summaries, alerts)");
        cStatus.set(s.cloudStatus, "", modeName(s.mode) + " placement");
        cStatus.setAccent(statusColor(s.cloudStatus));
        cUtil.set(String.format(Locale.US, "%.1f", s.cloudUtil * 100), "%", "From the iFogSim power model");

        // performance
        pLat.set(Widgets.num(s.avgLoopLatency, "%.2f"), "ms", String.format(Locale.US, "%,d loops completed", s.loopsCompleted));
        pNet.set(String.format(Locale.US, "%,.0f", s.networkUsage), "B/ms", "latency × size / time");
        pEnergy.set(String.format(Locale.US, "%.2f", s.energyTotal / 1e6), "MJ", String.format(Locale.US, "cloud %.2f · edge %.3f · nodes %.3f", s.energyCloud / 1e6, s.energyEdge / 1e6, s.energyNodes / 1e6));
        pProc.set(Widgets.num(s.avgProcessingMs, "%.2f"), "ms", "AQI analysis " + Widgets.num(s.analysisMs, "%.2f ms"));
        pAlert.set(Widgets.num(s.alertResponseDelay, "%.2f"), "ms", "Sample → alert detected");
        pTask.set(Widgets.num(s.taskCompletionRate, "%.2f"), "%", "Tasks finished / started");
        pPdr.set(Widgets.num(s.packetDeliveryRatio, "%.2f"), "%", "Sensor packets reaching data_filter");
    }

    // ================================================================== helpers

    private void updateNodeTiles(Snapshot s, boolean live) {
        List<DeviceRow> show = new ArrayList<>();
        for (DeviceRow d : s.devices) if (!d.role.startsWith("Sensor")) show.add(d);
        if (nodeTiles.size() != show.size()) {
            nodeStrip.removeAll();
            nodeTiles.clear();
            for (DeviceRow d : show) {
                NodeTile n = new NodeTile(d.role.startsWith("Cloud") ? Kind.CLOUD : d.role.startsWith("Gateway") ? Kind.GATEWAY : Kind.FOG);
                nodeTiles.add(n);
                nodeStrip.add(n);
            }
            nodeStrip.revalidate();
        }
        for (int i = 0; i < show.size(); i++) {
            DeviceRow d = show.get(i);
            String st = s.finalSnapshot ? "Offline (run finished)" : d.status;
            Color c = s.finalSnapshot ? Theme.OFFLINE : d.health == Severity.CRITICAL ? Theme.CRITICAL : d.health == Severity.WARNING ? Theme.WARNING : Theme.GOOD;
            String detail = d.tasksReceived > 0 ? String.format(Locale.US, "%,d tasks · CPU %.0f%%", d.tasksProcessed, d.cpuUtil * 100)
                    : String.format(Locale.US, "%,d tuples routed", d.arrivals);
            nodeTiles.get(i).set(d.label, st, c, d.cpuUtil, detail, live);
        }
    }

    private void resetView() {
        for (LineChart c : Arrays.asList(tempChart, humChart, aqiChart, pmChart, energyChart, networkChart, latencyChart)) c.clear();
        for (KpiCard k : Arrays.asList(kAqi, kTemp, kHum, kSensors, kFog, kAlerts)) { k.clearSpark(); k.set("—", "", "Waiting for simulation data"); k.setChip(null, null); }
        alertFeed.clear();
        activityFeed.clear();
        sensorModel.set(new ArrayList<SensorRow>());
        deviceModel.set(new ArrayList<DeviceRow>());
        fogBars.setData(new ArrayList<String>(), new double[2][0]);
        nodeStrip.removeAll();
        nodeTiles.clear();
        nodeStrip.revalidate();
        nodeStrip.repaint();
        for (StatTile t : Arrays.asList(oSensors, oFog, oGw, oCloud, oGen, oProc, oAlerts, oSystem, cReq, cProc, cData, cStore, cStatus, cUtil,
                pLat, pNet, pEnergy, pProc, pAlert, pTask, pPdr)) t.set("—", "", "");
        for (StatTile t : alertTiles) { t.set("0", "raised", "Normal"); t.setAccent(Theme.GOOD); }
        clockLabel.setText("t = 0.00 s / 10 s");
        dayLabel.setText("Day clock 00:00");
        progress.set(0, Theme.CYAN);
        if (alertCard != null) alertCard.setGlow(null);
        if (lastConfig == null) configLabel.setText("Live iFogSim simulation · choose a configuration and press Start");
    }

    private void updateComparisonCharts() {
        List<String> cats = new ArrayList<>();
        for (int[] sc : ComparisonRunner.SCENARIOS) cats.add(sc[0] + " sensors");
        int n = ComparisonRunner.SCENARIOS.length;
        double[][] lat = new double[2][n], en = new double[2][n], net = new double[2][n], pr = new double[2][n], tk = new double[2][n];
        for (int m = 0; m < 2; m++) for (int i = 0; i < n; i++) {
            ComparisonRunner.Result r = results.get(ComparisonRunner.MODES[m] + ComparisonRunner.SCENARIOS[i][0]);
            lat[m][i] = r == null ? Double.NaN : r.latency;
            en[m][i] = r == null ? Double.NaN : r.energy / 1e6;
            net[m][i] = r == null ? Double.NaN : r.network;
            pr[m][i] = r == null ? Double.NaN : r.processing;
            tk[m][i] = r == null ? Double.NaN : r.completion;
        }
        cmpLatency.setData(cats, lat);
        cmpEnergy.setData(cats, en);
        cmpNetwork.setData(cats, net);
        cmpProc.setData(cats, pr);
        cmpTask.setData(cats, tk);
        cmpModel.fireTableDataChanged();
        // verdict at the largest scenario that has both results
        ComparisonRunner.Result e = null, c = null;
        for (int i = n - 1; i >= 0 && (e == null || c == null); i--) {
            e = results.get("edge" + ComparisonRunner.SCENARIOS[i][0]);
            c = results.get("cloud" + ComparisonRunner.SCENARIOS[i][0]);
        }
        if (e == null || c == null) {
            cmpSummary.setText("<html><div style='width:390px'>The summary appears when an Edge/Fog and a Cloud-only run of the same size have finished.</div></html>");
            return;
        }
        int edgeWins = 0, cloudWins = 0;
        StringBuilder sb = new StringBuilder("<html><div style='width:390px'>At <b style='color:#E6EDF7'>" + e.sensors + " sensors</b>:<br>");
        int r;
        r = line(sb, "Latency", e.latency, c.latency, true, "ms"); if (r > 0) edgeWins++; else if (r < 0) cloudWins++;
        r = line(sb, "Energy", e.energy / 1e6, c.energy / 1e6, true, "MJ"); if (r > 0) edgeWins++; else if (r < 0) cloudWins++;
        r = line(sb, "Network usage", e.network, c.network, true, "B/ms"); if (r > 0) edgeWins++; else if (r < 0) cloudWins++;
        r = line(sb, "Processing time", e.processing, c.processing, true, "ms"); if (r > 0) edgeWins++; else if (r < 0) cloudWins++;
        r = line(sb, "Task completion", e.completion, c.completion, false, "%"); if (r > 0) edgeWins++; else if (r < 0) cloudWins++;
        String winner = edgeWins >= cloudWins ? "Edge / Fog" : "Cloud-only";
        sb.append("<br><b style='color:#22D3EE'>").append(winner).append(" performs better overall</b>: better in ")
                .append(Math.max(edgeWins, cloudWins)).append(" of 5 metrics, worse in ").append(Math.min(edgeWins, cloudWins))
                .append(", equal in ").append(5 - edgeWins - cloudWins).append(".");
        if (e.processing > c.processing)
            sb.append(" The cloud runs each AQI task faster because its CPU is far larger, but the 100 ms WAN hop makes its end-to-end latency much higher.");
        sb.append("</div></html>");
        cmpSummary.setText(sb.toString());
    }

    /** Appends one comparison line; returns 1 if Edge/Fog is better, -1 if Cloud-only is better, 0 if equal (within 0.5 %). */
    private static int line(StringBuilder sb, String name, double edge, double cloud, boolean lowerBetter, String unit) {
        double diff = cloud == 0 ? 0 : Math.abs(edge - cloud) / Math.abs(cloud) * 100;
        String vals = String.format(Locale.US, "%.2f vs %.2f %s", edge, cloud, unit);
        sb.append("\u2022 ").append(name).append(": ");
        if (diff < 0.5) {
            sb.append("<b style='color:#A3B1C8'>about equal</b> (").append(vals).append(")<br>");
            return 0;
        }
        boolean edgeBetter = lowerBetter ? edge < cloud : edge > cloud;
        sb.append("<b style='color:").append(edgeBetter ? "#3B8FF0" : "#D9632B").append("'>")
                .append(edgeBetter ? "Edge/Fog" : "Cloud-only").append("</b> better (").append(vals)
                .append(String.format(Locale.US, ", Edge/Fog is %.1f%% %s", diff, edge < cloud ? "lower" : "higher")).append(")<br>");
        return edgeBetter ? 1 : -1;
    }

    private static String threshold(AlertType t) {
        switch (t) {
            case HIGH_TEMPERATURE: return ">" + (int) MetricsCollector.TEMP_WARN + " / >" + (int) MetricsCollector.TEMP_CRIT + " °C";
            case HIGH_PM25: return ">35.4 / >55.4 µg/m³";
            case HIGH_PM10: return ">154 / >254 µg/m³";
            case HIGH_CO2: return ">" + (int) MetricsCollector.CO2_WARN + " / >" + (int) MetricsCollector.CO2_CRIT + " ppm";
            case UNHEALTHY_AQI: return "AQI >" + MetricsCollector.AQI_WARN + " / >" + MetricsCollector.AQI_CRIT;
            case SENSOR_FAILURE: return "invalid samples";
            default: return "overload / stall";
        }
    }

    static String shortCategory(String c) {
        return c.equals("Unhealthy for Sensitive Groups") ? "Poor (USG)" : c;
    }

    private static String modeName(String m) {
        return "edge".equals(m) ? "Edge / Fog" : "cloud".equals(m) ? "Cloud-only" : "Edge-ward";
    }

    private static Color statusColor(String s) {
        if (s == null) return Theme.OFFLINE;
        if (s.startsWith("Online")) return Theme.GOOD;
        if (s.startsWith("Busy") || s.startsWith("Degraded") || s.startsWith("Overloaded")) return Theme.WARNING;
        if (s.startsWith("Not") || s.startsWith("Fault")) return Theme.CRITICAL;
        return Theme.OFFLINE;
    }

    private static String time(double simMs) {
        return String.format(Locale.US, "t=%.2fs", simMs / 1000);
    }

    private static String eventTitle(ActivityEvent e) {
        switch (e.kind) {
            case ALERT: return "Alert raised";
            case CLEARED: return "Alert cleared";
            case CLOUD: return "Cloud";
            case FOG: return "Fog layer";
            case SENSOR: return "Sensors";
            default: return "Simulation";
        }
    }

    private static Color eventColor(ActivityEvent e) {
        switch (e.kind) {
            case ALERT: return e.text.startsWith("CRITICAL") ? Theme.CRITICAL : Theme.WARNING;
            case CLEARED: return Theme.GOOD;
            case CLOUD: return Theme.PURPLE;
            case FOG: return Theme.CYAN;
            default: return Theme.BLUE;
        }
    }

    private static Kind eventIcon(ActivityEvent e) {
        switch (e.kind) {
            case ALERT: return Kind.ALERT;
            case CLEARED: return Kind.CHECK;
            case CLOUD: return Kind.CLOUD;
            case FOG: return Kind.FOG;
            case SENSOR: return Kind.SENSOR;
            default: return Kind.ACTIVITY;
        }
    }

    private void section(String anchor, String title, String subtitle, Kind icon) {
        JLabel l = Widgets.sectionTitle(title, subtitle, icon);
        if (!anchors.containsKey(anchor)) anchors.put(anchor, l);
        content.add(l);
    }

    private void add(JComponent c) {
        c.setAlignmentX(0f);
        content.add(c);
    }

    private void gap(int h) {
        content.add(Box.createVerticalStrut(h));
    }

    private static JPanel grid(int minW, int maxCols) {
        return grid(minW, maxCols, Theme.GAP);
    }

    private static JPanel grid(int minW, int maxCols, int gap) {
        JPanel p = new JPanel(new ResponsiveGrid(minW, maxCols, gap)) {
            @Override public Dimension getMaximumSize() { return new Dimension(Integer.MAX_VALUE, getPreferredSize().height); }
        };
        p.setOpaque(false);
        p.setAlignmentX(0f);
        return p;
    }

    private static Card chartCard(String title, String subtitle, Kind icon, JComponent chart) {
        Card c = new Card(title, subtitle, icon, chart);
        c.setPreferredSize(new Dimension(400, 320));
        return c;
    }

    private static JScrollPane feedScroll(Feed f) {
        JScrollPane sp = new JScrollPane(f, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        sp.setBorder(BorderFactory.createEmptyBorder());
        sp.setOpaque(false);
        sp.getViewport().setOpaque(false);
        sp.getViewport().setBackground(Theme.CARD);
        sp.getVerticalScrollBar().setUI(new DarkScrollBarUI());
        sp.getVerticalScrollBar().setPreferredSize(new Dimension(8, 0));
        sp.getVerticalScrollBar().setUnitIncrement(20);
        sp.setPreferredSize(new Dimension(300, 330));
        return sp;
    }

    private static void fix(JComponent c, int w, int h) {
        Dimension d = new Dimension(w, h);
        if (!d.equals(c.getPreferredSize())) {
            c.setPreferredSize(d);
            c.setMaximumSize(new Dimension(Integer.MAX_VALUE, h));
            c.revalidate();
        }
    }

    private static JLabel label(String text, java.awt.Font f, Color c) {
        JLabel l = new JLabel(text);
        l.setFont(f);
        l.setForeground(c);
        return l;
    }

    private static JComboBox<String> combo(String... items) {
        JComboBox<String> b = new JComboBox<>(items);
        b.setUI(new javax.swing.plaf.basic.BasicComboBoxUI() {
            @Override protected JButton createArrowButton() {
                JButton a = new JButton(new javax.swing.Icon() {
                    @Override public int getIconWidth() { return 10; }
                    @Override public int getIconHeight() { return 6; }
                    @Override public void paintIcon(Component c, Graphics g0, int x, int y) {
                        Graphics2D g = (Graphics2D) g0.create();
                        Theme.smooth(g);
                        g.setColor(Theme.TEXT_2);
                        g.setStroke(new java.awt.BasicStroke(1.6f, java.awt.BasicStroke.CAP_ROUND, java.awt.BasicStroke.JOIN_ROUND));
                        g.drawPolyline(new int[]{x, x + 5, x + 10}, new int[]{y, y + 5, y}, 3);
                        g.dispose();
                    }
                });
                a.setContentAreaFilled(false);
                a.setBorder(BorderFactory.createEmptyBorder(0, 6, 0, 10));
                a.setFocusPainted(false);
                return a;
            }
            @Override public void paintCurrentValueBackground(Graphics g, java.awt.Rectangle r, boolean f) {
                g.setColor(Theme.CARD_TOP);
                g.fillRect(r.x, r.y, r.width, r.height);
            }
        });
        b.setRenderer(new javax.swing.DefaultListCellRenderer() {
            @Override public Component getListCellRendererComponent(javax.swing.JList<?> l, Object v, int i, boolean sel, boolean f) {
                JLabel c = (JLabel) super.getListCellRendererComponent(l, v, i, sel, false);
                c.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
                c.setBackground(sel && i >= 0 ? Theme.SELECTION : Theme.CARD_TOP);
                c.setForeground(Theme.TEXT);
                c.setFont(Theme.SMALL_BOLD);
                return c;
            }
        });
        b.setFont(Theme.SMALL_BOLD);
        b.setBackground(Theme.CARD_TOP);
        b.setForeground(Theme.TEXT);
        b.setBorder(BorderFactory.createLineBorder(Theme.BORDER_HOVER, 1, true));
        b.setFocusable(false);
        return b;
    }

    private static JButton button(String text, Kind icon, boolean primary) {
        JButton b = new JButton(text, Icons.of(icon, 12, Theme.TEXT)) {
            private boolean hover;
            {
                addMouseListener(new MouseAdapter() {
                    @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
                    @Override public void mouseExited(MouseEvent e) { hover = false; repaint(); }
                });
            }
            @Override protected void paintComponent(Graphics g0) {
                Graphics2D g = (Graphics2D) g0.create();
                Theme.smooth(g);
                RoundRectangle2D r = new RoundRectangle2D.Double(0, 0, getWidth() - 1, getHeight() - 1, 12, 12);
                if (!isEnabled()) g.setColor(Theme.CARD);
                else if (primary) g.setPaint(new GradientPaint(0, 0, hover ? Theme.BLUE : Theme.ACCENT_GRAD_A, getWidth(), getHeight(), Theme.ACCENT_GRAD_B));
                else g.setColor(hover ? Theme.CARD_HOVER : Theme.CARD_TOP);
                g.fill(r);
                g.setColor(isEnabled() ? (primary ? Theme.alpha(Theme.CYAN, 140) : Theme.BORDER_HOVER) : Theme.BORDER);
                g.draw(r);
                g.dispose();
                super.paintComponent(g0);
            }
        };
        b.setFont(Theme.SMALL_BOLD);
        b.setForeground(Theme.TEXT);
        b.setContentAreaFilled(false);
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setOpaque(false);
        b.setBorder(BorderFactory.createEmptyBorder(7, 14, 7, 14));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    // ================================================================== navigation

    private void updateActiveNav() {
        int y = scroll.getViewport().getViewPosition().y + 80;
        String active = "Overview";
        for (Map.Entry<String, JComponent> e : anchors.entrySet()) {
            int ay = SwingUtilities.convertPoint(e.getValue().getParent(), e.getValue().getLocation(), content).y;
            if (ay <= y) active = e.getKey();
        }
        for (NavItem n : navItems) n.setActive(n.name.equals(active));
    }

    private final class NavItem extends JComponent {
        final String name;
        final Kind icon;
        boolean active, hover;

        NavItem(String name, Kind icon) {
            this.name = name;
            this.icon = icon;
            setAlignmentX(0f);
            fix(this, 190, 40);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
                @Override public void mouseExited(MouseEvent e) { hover = false; repaint(); }
                @Override public void mouseClicked(MouseEvent e) { scrollTo(NavItem.this.name); }
            });
        }

        void setActive(boolean a) { if (a != active) { active = a; repaint(); } }

        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            Theme.smooth(g);
            if (active || hover) {
                g.setColor(active ? Theme.alpha(Theme.BLUE, 45) : Theme.alpha(Theme.BLUE, 20));
                g.fill(new RoundRectangle2D.Double(0, 2, getWidth(), getHeight() - 4, 12, 12));
            }
            if (active) {
                g.setPaint(new GradientPaint(0, 0, Theme.CYAN, 0, getHeight(), Theme.BLUE));
                g.fill(new RoundRectangle2D.Double(0, 10, 3, getHeight() - 20, 3, 3));
            }
            Icons.of(icon, 17, active ? Theme.CYAN : Theme.TEXT_2).paintIcon(this, g, 14, (getHeight() - 17) / 2);
            g.setFont(active ? Theme.BODY_BOLD : Theme.BODY);
            g.setColor(active ? Theme.TEXT : Theme.TEXT_2);
            g.drawString(name, 42, getHeight() / 2 + 5);
            g.dispose();
        }
    }

    private void scrollTo(String name) {
        JComponent a = anchors.get(name);
        if (a == null) return;
        int y = SwingUtilities.convertPoint(a.getParent(), a.getLocation(), content).y - 6;
        final int target = Math.max(0, Math.min(y, content.getHeight() - scroll.getViewport().getHeight()));
        final int start = scroll.getViewport().getViewPosition().y;
        final long t0 = System.currentTimeMillis();
        final Timer tm = new Timer(15, null);
        tm.addActionListener(e -> {
            double p = Math.min(1, (System.currentTimeMillis() - t0) / 260.0);
            double ease = 1 - Math.pow(1 - p, 3);
            scroll.getViewport().setViewPosition(new java.awt.Point(0, (int) (start + (target - start) * ease)));
            if (p >= 1) tm.stop();
        });
        tm.start();
    }

    // ================================================================== table models

    private static final class SensorModel extends AbstractTableModel {
        private final String[] cols = {"Sensor ID", "Area / zone", "Temp (°C)", "Humidity (%)", "PM2.5", "PM10", "CO2 (ppm)", "AQI", "Air quality status", "Edge filter"};
        private List<SensorRow> rows = new ArrayList<>();

        void set(List<SensorRow> r) { rows = r; fireTableDataChanged(); }

        @Override public int getRowCount() { return rows.size(); }
        @Override public int getColumnCount() { return cols.length; }
        @Override public String getColumnName(int c) { return cols[c]; }

        @Override public Object getValueAt(int r, int c) {
            SensorRow s = rows.get(r);
            if (!s.hasReading && c >= 2 && c <= 6) return "—";
            switch (c) {
                case 0: return s.id;
                case 1: return s.area + " · " + s.zone;
                case 2: return String.format(Locale.US, "%.1f", s.temperature);
                case 3: return String.format(Locale.US, "%.1f", s.humidity);
                case 4: return String.format(Locale.US, "%.1f", s.pm25);
                case 5: return String.format(Locale.US, "%.1f", s.pm10);
                case 6: return String.format(Locale.US, "%.0f", s.co2);
                case 7: return s.aqi < 0 ? "—" : String.valueOf(s.aqi);
                case 8: return s.aqi < 0 ? "Not analysed yet" : shortCategory(s.category) + " (" + s.dominant + ")";
                default: return s.filterOutcome;
            }
        }

        Color pill(int r, int c) {
            if (r >= rows.size()) return null;
            SensorRow s = rows.get(r);
            if (c == 8) return s.aqi < 0 ? Theme.OFFLINE : Theme.aqi(s.aqi);
            if (c == 9) return s.filterOutcome.startsWith("Invalid") ? Theme.CRITICAL : s.filterOutcome.startsWith("Forwarded") ? Theme.BLUE : Theme.OFFLINE;
            return null;
        }
    }

    private static final class DeviceModel extends AbstractTableModel {
        private final String[] cols = {"Device", "Role", "Status", "Modules", "Tuples received", "Tasks processed", "Avg processing (ms)", "CPU util.", "Memory util.", "Energy (iFogSim units)"};
        private List<DeviceRow> rows = new ArrayList<>();

        void set(List<DeviceRow> r) { rows = r; fireTableDataChanged(); }

        @Override public int getRowCount() { return rows.size(); }
        @Override public int getColumnCount() { return cols.length; }
        @Override public String getColumnName(int c) { return cols[c]; }

        @Override public Object getValueAt(int r, int c) {
            DeviceRow d = rows.get(r);
            switch (c) {
                case 0: return d.count > 1 ? d.label + " (×" + d.count + ")" : d.label + (d.name.equals(d.label) ? "" : "  · " + d.name);
                case 1: return d.role;
                case 2: return d.status;
                case 3: return d.modules;
                case 4: return String.format(Locale.US, "%,d", d.arrivals);
                case 5: return String.format(Locale.US, "%,d", d.tasksProcessed);
                case 6: return Widgets.num(d.avgProcessingMs, "%.2f");
                case 7: return String.format(Locale.US, "%.1f %%", d.cpuUtil * 100) + (d.count > 1 ? " avg" : "");
                case 8: return String.format(Locale.US, "%.2f %%", d.memUtil * 100);
                default: return String.format(Locale.US, "%,.0f", d.energy);
            }
        }

        Color pill(int r, int c) {
            if (c != 2 || r >= rows.size()) return null;
            return statusColor(rows.get(r).status);
        }
    }

    private final class CompareModel extends AbstractTableModel {
        private final String[] cols = {"Run", "Latency (ms)", "Energy (MJ)", "Network (B/ms)", "Proc. (ms)", "Completion (%)"};

        @Override public int getRowCount() { return results.size(); }
        @Override public int getColumnCount() { return cols.length; }
        @Override public String getColumnName(int c) { return cols[c]; }

        @Override public Object getValueAt(int r, int c) {
            ComparisonRunner.Result x = new ArrayList<>(results.values()).get(r);
            switch (c) {
                case 0: return modeName(x.mode) + " · " + x.sensors;
                case 1: return String.format(Locale.US, "%.2f", x.latency);
                case 2: return String.format(Locale.US, "%.2f", x.energy / 1e6);
                case 3: return String.format(Locale.US, "%,.0f", x.network);
                case 4: return String.format(Locale.US, "%.2f", x.processing);
                default: return String.format(Locale.US, "%.2f", x.completion);
            }
        }
    }

    /** Thin dark scrollbar. */
    static final class DarkScrollBarUI extends javax.swing.plaf.basic.BasicScrollBarUI {
        @Override protected void configureScrollBarColors() {
            thumbColor = Theme.BORDER_HOVER;
            trackColor = Theme.BG;
        }
        @Override protected JButton createDecreaseButton(int o) { return zero(); }
        @Override protected JButton createIncreaseButton(int o) { return zero(); }
        private static JButton zero() {
            JButton b = new JButton();
            b.setPreferredSize(new Dimension(0, 0));
            return b;
        }
        @Override protected void paintThumb(Graphics g0, JComponent c, java.awt.Rectangle r) {
            Graphics2D g = (Graphics2D) g0.create();
            Theme.smooth(g);
            g.setColor(thumbColor);
            g.fill(new RoundRectangle2D.Double(r.x + 2, r.y + 2, r.width - 4, r.height - 4, 6, 6));
            g.dispose();
        }
        @Override protected void paintTrack(Graphics g, JComponent c, java.awt.Rectangle r) {
            g.setColor(c.getParent() != null && c.getParent().getParent() instanceof Widgets.Column ? Theme.BG : Theme.CARD);
            g.fillRect(r.x, r.y, r.width, r.height);
        }
    }

    @SuppressWarnings("unused")
    private static Component spacer() { return Box.createHorizontalGlue(); }
}
