package org.fog.airquality.dashboard;

import java.util.Locale;

import org.fog.airquality.EdgeAirQualitySimulation;

/**
 * Headless run of the monitored simulation, used by the dashboard's Fog vs Cloud comparison.
 * Each experiment runs in its own JVM (iFogSim keeps global static state) and prints one
 * machine-readable line starting with AQ_RESULT.
 *
 * Usage: ExperimentRunner mode areas nodesPerArea sensingIntervalMs
 */
public final class ExperimentRunner {

    public static void main(String[] args) throws Exception {
        String mode = args.length > 0 ? args[0] : "edge";
        int areas = args.length > 1 ? Integer.parseInt(args[1]) : 4;
        int per = args.length > 2 ? Integer.parseInt(args[2]) : 5;
        double interval = args.length > 3 ? Double.parseDouble(args[3]) : 10;
        int code = 0;
        try {
            SimulationEngine.resetIFogSimState();
            EdgeAirQualitySimulation.configure(mode, areas, per, interval);
            MetricsCollector collector = new MetricsCollector(mode, areas, per, interval, 10000);
            DashboardHooks hooks = new DashboardHooks(collector, null);
            EdgeAirQualitySimulation.runSimulation(hooks);
            double end = hooks.getController() != null && hooks.getController().getEndTime() > 0
                    ? hooks.getController().getEndTime() : collector.lastSampleTime();
            Snapshot s = collector.sample(end, true);
            System.out.println(String.format(Locale.US,
                    "AQ_RESULT mode=%s sensors=%d latency=%.4f energy=%.2f network=%.4f processing=%.4f "
                            + "completion=%.4f alertDelay=%.4f pdr=%.4f cloudRequests=%d alerts=%d",
                    mode, areas * per, s.avgLoopLatency, s.energyTotal, s.networkUsage, s.analysisMs,
                    s.taskCompletionRate, s.alertResponseDelay, s.packetDeliveryRatio, s.cloudRequests, s.alertsTotal));
        } catch (Throwable t) {
            t.printStackTrace();
            System.out.println("AQ_ERROR " + t);
            code = 1;
        }
        System.out.flush();
        System.exit(code);
    }
}
