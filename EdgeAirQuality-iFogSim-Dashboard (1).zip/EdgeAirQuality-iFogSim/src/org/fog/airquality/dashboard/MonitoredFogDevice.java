package org.fog.airquality.dashboard;

import java.util.List;

import org.cloudbus.cloudsim.Storage;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.core.SimEvent;
import org.fog.entities.FogDevice;
import org.fog.entities.FogDeviceCharacteristics;
import org.fog.entities.Tuple;
import org.fog.policy.AppModuleAllocationPolicy;

/**
 * iFogSim FogDevice that reports tuple arrivals and task starts to the dashboard.
 * The behaviour of the device is unchanged: every override calls the original method.
 */
public class MonitoredFogDevice extends FogDevice {

    private final MetricsCollector collector;

    public MonitoredFogDevice(String name, FogDeviceCharacteristics characteristics,
                              AppModuleAllocationPolicy vmAllocationPolicy, List<Storage> storageList,
                              double schedulingInterval, double uplinkBandwidth, double downlinkBandwidth,
                              double uplinkLatency, double ratePerMips, MetricsCollector collector) throws Exception {
        super(name, characteristics, vmAllocationPolicy, storageList, schedulingInterval, uplinkBandwidth,
                downlinkBandwidth, uplinkLatency, ratePerMips);
        this.collector = collector;
    }

    @Override
    protected void processTupleArrival(SimEvent ev) {
        collector.onTupleArrival(this, (Tuple) ev.getData(), CloudSim.clock());
        super.processTupleArrival(ev);
    }

    @Override
    protected void executeTuple(SimEvent ev, String moduleName) {
        collector.onTaskStart(this, (Tuple) ev.getData(), moduleName, CloudSim.clock());
        super.executeTuple(ev, moduleName);
    }
}
