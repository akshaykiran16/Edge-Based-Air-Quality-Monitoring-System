package org.fog.airquality.dashboard;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.fog.airquality.AirQualityDataGenerator;
import org.fog.airquality.SensorReading;

/**
 * Supplies the physical readings carried by the simulated AQ_SENSOR tuples.
 *
 * There are no physical sensors, so every station gets one synthetic day of readings from the
 * project's own {@link AirQualityDataGenerator} (same seed, station order and zones as
 * AirQualityDataDemo, which calibrates the simulation). The simulated 10 s run is mapped onto
 * that day: the k-th tuple of a sensor carries the reading of minute k * 1440 / totalTuples,
 * so one run replays a full day including the morning and evening rush hours.
 *
 * CO2 is not produced by the original generator. It is derived here from the CO reading
 * (both come from combustion / traffic) plus small noise: CO2 = 415 + 110 * CO + N(0, 10) ppm.
 */
final class LiveSensorFeed {

    static final AirQualityDataGenerator.Zone[] ZONES = AirQualityDataGenerator.Zone.values();

    private final List<List<SensorReading>> days = new ArrayList<>();
    private final List<AirQualityDataGenerator.Zone> zones = new ArrayList<>();
    private final Random co2Noise = new Random(7L);

    LiveSensorFeed(int areas, int nodesPerArea) {
        AirQualityDataGenerator gen = new AirQualityDataGenerator(42L, 0.03);
        for (int a = 0; a < areas; a++) {
            for (int n = 0; n < nodesPerArea; n++) {
                AirQualityDataGenerator.Zone zone = ZONES[(a + n) % ZONES.length];
                zones.add(zone);
                days.add(gen.generateDay("node-" + a + "-" + n, zone, 1));
            }
        }
    }

    AirQualityDataGenerator.Zone zoneOf(int index) {
        return zones.get(index);
    }

    /** Reading carried by the k-th tuple of sensor {@code index}. */
    SensorReading reading(int index, long k, long tuplesPerRun) {
        List<SensorReading> day = days.get(index);
        int i = (int) Math.min(day.size() - 1, k * day.size() / Math.max(1, tuplesPerRun));
        return day.get(i);
    }

    double co2For(SensorReading r) {
        return 415 + 110 * Math.max(r.co, 0) + co2Noise.nextGaussian() * 10;
    }
}
