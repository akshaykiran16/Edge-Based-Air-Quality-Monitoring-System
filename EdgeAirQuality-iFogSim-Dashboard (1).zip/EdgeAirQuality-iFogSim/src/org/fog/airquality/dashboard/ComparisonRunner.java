package org.fog.airquality.dashboard;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.swing.SwingUtilities;

/**
 * Runs the Fog/Edge vs Cloud-only experiments for 4, 10 and 20 sensors. Every experiment is a
 * real simulation run in a separate JVM ({@link ExperimentRunner}); nothing is precomputed.
 */
public final class ComparisonRunner {

    /** Sensor counts and how they map onto the existing topology (areas x nodes per area). */
    public static final int[][] SCENARIOS = { {4, 2, 2}, {10, 2, 5}, {20, 4, 5} };
    public static final String[] MODES = { "edge", "cloud" };

    public static final class Result {
        public String mode;
        public int sensors;
        public double latency, energy, network, processing, completion, alertDelay, pdr;
        public long cloudRequests, alerts;
    }

    public interface Listener {
        void onProgress(int done, int total, String message);
        void onResult(Result r);
        void onFinished(List<Result> results, String error);
    }

    private volatile Thread thread;

    public boolean isRunning() {
        Thread t = thread;
        return t != null && t.isAlive();
    }

    public synchronized void start(final Listener listener) {
        if (isRunning()) return;
        thread = new Thread(new Runnable() {
            @Override public void run() { runAll(listener); }
        }, "fog-vs-cloud-experiments");
        thread.setDaemon(true);
        thread.start();
    }

    private void runAll(final Listener l) {
        final List<Result> results = new ArrayList<>();
        String error = null;
        final int total = SCENARIOS.length * MODES.length;
        int done = 0;
        for (int[] sc : SCENARIOS) {
            for (String mode : MODES) {
                final int d = done;
                final String msg = "Running " + (mode.equals("edge") ? "Edge/Fog" : "Cloud-only") + " with " + sc[0] + " sensors";
                ui(new Runnable() { @Override public void run() { l.onProgress(d, total, msg); } });
                try {
                    final Result r = runOne(mode, sc[1], sc[2]);
                    results.add(r);
                    ui(new Runnable() { @Override public void run() { l.onResult(r); } });
                } catch (Exception e) {
                    error = e.getMessage();
                }
                done++;
            }
        }
        final String err = error;
        final int d = done;
        ui(new Runnable() { @Override public void run() { l.onProgress(d, total, "Done"); l.onFinished(results, err); } });
    }

    private static Result runOne(String mode, int areas, int per) throws Exception {
        String java = System.getProperty("java.home") + File.separator + "bin" + File.separator + "java";
        List<String> cmd = new ArrayList<>();
        cmd.add(java);
        cmd.add("-cp");
        cmd.add(System.getProperty("java.class.path"));
        cmd.add("-Daq.nogui=true");
        cmd.add(ExperimentRunner.class.getName());
        cmd.add(mode);
        cmd.add(String.valueOf(areas));
        cmd.add(String.valueOf(per));
        cmd.add("10");
        ProcessBuilder pb = new ProcessBuilder(cmd);
        pb.redirectErrorStream(true);
        Process p = pb.start();
        String resultLine = null, errorLine = null;
        try (BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.startsWith("AQ_RESULT ")) resultLine = line;
                else if (line.startsWith("AQ_ERROR ")) errorLine = line;
            }
        }
        if (!p.waitFor(180, TimeUnit.SECONDS)) {
            p.destroyForcibly();
            throw new Exception("experiment " + mode + " " + (areas * per) + " timed out");
        }
        if (resultLine == null)
            throw new Exception("experiment " + mode + " " + (areas * per) + " failed" + (errorLine != null ? ": " + errorLine : ""));
        return parse(resultLine);
    }

    static Result parse(String line) {
        Map<String, String> kv = new HashMap<>();
        for (String tok : line.substring("AQ_RESULT ".length()).trim().split("\\s+")) {
            int i = tok.indexOf('=');
            if (i > 0) kv.put(tok.substring(0, i), tok.substring(i + 1));
        }
        Result r = new Result();
        r.mode = kv.get("mode");
        r.sensors = Integer.parseInt(kv.get("sensors"));
        r.latency = num(kv.get("latency"));
        r.energy = num(kv.get("energy"));
        r.network = num(kv.get("network"));
        r.processing = num(kv.get("processing"));
        r.completion = num(kv.get("completion"));
        r.alertDelay = num(kv.get("alertDelay"));
        r.pdr = num(kv.get("pdr"));
        r.cloudRequests = Long.parseLong(kv.get("cloudRequests"));
        r.alerts = Long.parseLong(kv.get("alerts"));
        return r;
    }

    private static double num(String s) {
        try { return Double.parseDouble(s); } catch (Exception e) { return Double.NaN; }
    }

    private static void ui(Runnable r) {
        SwingUtilities.invokeLater(r);
    }
}
