package org.fog.airquality.dashboard;

import java.awt.Color;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.plaf.ColorUIResource;

import org.fog.airquality.dashboard.ui.Theme;

/**
 * Opens the live dashboard, starts the default simulation (Edge/Fog placement, 20 sensors,
 * 10 ms sensing) and the Fog vs Cloud experiments. Called from EdgeAirQualitySimulation.main().
 */
public final class DashboardApp {

    private DashboardApp() { }

    public static void launch() {
        System.out.println("Opening the EdgeAQ live dashboard (run with -Daq.nogui=true for the console-only simulation)");
        SwingUtilities.invokeLater(new Runnable() {
            @Override public void run() {
                try {
                    UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
                } catch (Exception ignored) { }
                ColorUIResource bg = new ColorUIResource(Theme.CARD_TOP);
                ColorUIResource fg = new ColorUIResource(Theme.TEXT);
                UIManager.put("ComboBox.background", bg);
                UIManager.put("ComboBox.foreground", fg);
                UIManager.put("ComboBox.selectionBackground", new ColorUIResource(Theme.SELECTION));
                UIManager.put("ComboBox.selectionForeground", fg);
                UIManager.put("ComboBox.buttonBackground", bg);
                UIManager.put("ComboBox.disabledForeground", new ColorUIResource(Theme.MUTED));
                UIManager.put("ComboBox.disabledBackground", new ColorUIResource(Theme.CARD));
                UIManager.put("Button.disabledText", new ColorUIResource(Theme.MUTED));
                UIManager.put("ToolTip.background", new ColorUIResource(new Color(0x0B1224)));
                UIManager.put("ToolTip.foreground", fg);
                UIManager.put("ScrollPane.background", new ColorUIResource(Theme.BG));
                UIManager.put("Viewport.background", new ColorUIResource(Theme.BG));
                UIManager.put("Panel.background", new ColorUIResource(Theme.BG));
                UIManager.put("Table.background", new ColorUIResource(Theme.CARD));
                UIManager.put("Label.foreground", fg);
                final DashboardFrame f = new DashboardFrame();
                f.setVisible(true);
                f.startSimulation();
                f.startComparison();
            }
        });
    }
}
