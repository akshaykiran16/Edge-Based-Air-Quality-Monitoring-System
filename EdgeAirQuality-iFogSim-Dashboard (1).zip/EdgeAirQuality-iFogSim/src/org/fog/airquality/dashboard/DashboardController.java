package org.fog.airquality.dashboard;

import java.util.List;

import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.core.SimEvent;
import org.fog.entities.Actuator;
import org.fog.entities.FogDevice;
import org.fog.entities.Sensor;
import org.fog.placement.Controller;
import org.fog.utils.FogEvents;

/**
 * iFogSim's Controller ends the whole JVM with System.exit() when the simulation time is over,
 * which would also close the dashboard window. This controller ends only the simulation run.
 */
public class DashboardController extends Controller {

    private volatile double endTime = -1;

    public DashboardController(String name, List<FogDevice> fogDevices, List<Sensor> sensors, List<Actuator> actuators) {
        super(name, fogDevices, sensors, actuators);
    }

    @Override
    public void processEvent(SimEvent ev) {
        if (ev.getTag() == FogEvents.STOP_SIMULATION) {
            endTime = CloudSim.clock();
            CloudSim.abruptallyTerminate();
            return;
        }
        super.processEvent(ev);
    }

    /** Simulated time at which the run reached its end, or -1 if it was stopped earlier. */
    public double getEndTime() {
        return endTime;
    }
}
