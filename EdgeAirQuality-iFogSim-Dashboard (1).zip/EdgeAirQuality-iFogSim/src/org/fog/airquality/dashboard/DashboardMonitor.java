package org.fog.airquality.dashboard;

import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.core.CloudSimTags;
import org.cloudbus.cloudsim.core.SimEntity;
import org.cloudbus.cloudsim.core.SimEvent;

/**
 * A CloudSim entity that wakes up every {@link MetricsCollector#SAMPLE_INTERVAL} simulated ms,
 * takes a snapshot of the metrics and hands it to the dashboard. Because it runs inside the
 * simulation loop it can also pace the simulation to a watchable speed, pause it (by waiting)
 * and stop it.
 */
final class DashboardMonitor extends SimEntity {

    /** Receives snapshots; may block to pace or pause the simulation. */
    interface Pacer {
        void onSample(Snapshot snapshot);
        boolean stopRequested();
    }

    private enum Tag implements CloudSimTags { SAMPLE }

    private final MetricsCollector collector;
    private final Pacer pacer;

    DashboardMonitor(String name, MetricsCollector collector, Pacer pacer) {
        super(name);
        this.collector = collector;
        this.pacer = pacer;
    }

    @Override
    public void startEntity() {
        schedule(getId(), MetricsCollector.SAMPLE_INTERVAL, Tag.SAMPLE);
    }

    @Override
    public void processEvent(SimEvent ev) {
        if (ev.getTag() != Tag.SAMPLE) return;
        double now = CloudSim.clock();
        Snapshot s = collector.sample(now, false);
        if (pacer != null) {
            pacer.onSample(s);
            if (pacer.stopRequested()) {
                CloudSim.abruptallyTerminate();
                return;
            }
        }
        if (now + MetricsCollector.SAMPLE_INTERVAL < collector.maxSimTime)
            schedule(getId(), MetricsCollector.SAMPLE_INTERVAL, Tag.SAMPLE);
    }

    @Override
    public void shutdownEntity() {
    }
}
