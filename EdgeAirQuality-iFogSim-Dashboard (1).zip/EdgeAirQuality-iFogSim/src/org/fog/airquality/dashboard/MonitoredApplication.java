package org.fog.airquality.dashboard;

import java.util.List;

import org.cloudbus.cloudsim.core.CloudSim;
import org.fog.application.Application;
import org.fog.entities.Tuple;

/**
 * iFogSim Application that runs the project's edge logic when a module finishes a tuple.
 *
 * iFogSim calls getResultantTuples() exactly once each time a module finishes executing a tuple.
 * Before the original method decides which output tuples to create, the collector runs
 * EdgeDataFilter (data_filter) or AQICalculator (aqi_analyzer) on the reading carried by that tuple,
 * so the {@link DataDrivenSelectivity} can forward or drop tuples according to the real result.
 */
public class MonitoredApplication extends Application {

    private final MetricsCollector collector;

    public MonitoredApplication(String appId, int userId, MetricsCollector collector) {
        super(appId, userId);
        this.collector = collector;
    }

    @Override
    public List<Tuple> getResultantTuples(String moduleName, Tuple inputTuple, int sourceDeviceId, int sourceModuleId) {
        collector.onTaskComplete(sourceDeviceId, moduleName, inputTuple, CloudSim.clock());
        List<Tuple> out = null;
        try {
            out = super.getResultantTuples(moduleName, inputTuple, sourceDeviceId, sourceModuleId);
            return out;
        } finally {
            collector.afterResultTuples(out == null ? 0 : out.size());
        }
    }
}
