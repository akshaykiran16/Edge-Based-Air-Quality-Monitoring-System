package org.fog.airquality.dashboard.ui;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Ellipse2D;
import java.awt.geom.GeneralPath;
import java.awt.geom.Line2D;
import java.awt.geom.RoundRectangle2D;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.swing.JComponent;

/**
 * Live time-series chart: thin 2px lines, optional gradient area under a series, dashed
 * threshold lines, legend, axis labels and a hover crosshair with a tooltip.
 */
public class LineChart extends JComponent {

    public static final class Series {
        final String name;
        final Color color;
        final boolean area;
        final List<Double> values = new ArrayList<>();
        Series(String name, Color color, boolean area) { this.name = name; this.color = color; this.area = area; }
    }

    private static final class Threshold {
        final double value; final String label; final Color color;
        Threshold(double v, String l, Color c) { value = v; label = l; color = c; }
    }

    private final List<Double> xs = new ArrayList<>();
    private final List<Series> series = new ArrayList<>();
    private final List<Threshold> thresholds = new ArrayList<>();
    private final String yLabel, xLabel, valueFormat;
    private double xMax = 10;
    private Double yMinFixed = null;
    private int hoverIndex = -1;
    private int plotX0, plotX1, plotY0, plotY1;
    private String emptyText = "Waiting for simulation data…";

    public LineChart(String yLabel, String xLabel, String valueFormat) {
        this.yLabel = yLabel;
        this.xLabel = xLabel;
        this.valueFormat = valueFormat;
        setOpaque(false);
        MouseAdapter ma = new MouseAdapter() {
            @Override public void mouseMoved(MouseEvent e) { updateHover(e.getX()); }
            @Override public void mouseExited(MouseEvent e) { hoverIndex = -1; repaint(); }
        };
        addMouseListener(ma);
        addMouseMotionListener(ma);
    }

    public int addSeries(String name, Color color, boolean area) {
        series.add(new Series(name, color, area));
        return series.size() - 1;
    }

    public void addThreshold(double v, String label, Color c) {
        thresholds.add(new Threshold(v, label, c));
    }

    public void setYMin(Double v) { yMinFixed = v; }
    public void setXMax(double v) { xMax = v; }
    public void setEmptyText(String t) { emptyText = t; repaint(); }

    /** Appends one point for every series (NaN = no value yet). */
    public void add(double x, double... values) {
        xs.add(x);
        for (int i = 0; i < series.size(); i++)
            series.get(i).values.add(i < values.length ? values[i] : Double.NaN);
        repaint();
    }

    public void clear() {
        xs.clear();
        for (Series s : series) s.values.clear();
        hoverIndex = -1;
        repaint();
    }

    public void clearSeries() {
        series.clear();
        xs.clear();
        repaint();
    }

    @Override
    public Dimension getPreferredSize() {
        return new Dimension(380, 230);
    }

    private void updateHover(int mx) {
        if (xs.isEmpty() || mx < plotX0 - 4 || mx > plotX1 + 4) { hoverIndex = -1; repaint(); return; }
        double x = (mx - plotX0) / (double) Math.max(1, plotX1 - plotX0) * xMax;
        int best = 0;
        double bd = Double.MAX_VALUE;
        for (int i = 0; i < xs.size(); i++) {
            double d = Math.abs(xs.get(i) - x);
            if (d < bd) { bd = d; best = i; }
        }
        hoverIndex = best;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g0) {
        Graphics2D g = (Graphics2D) g0.create();
        Theme.smooth(g);
        int w = getWidth(), h = getHeight();
        g.setFont(Theme.SMALL);
        FontMetrics fm = g.getFontMetrics();

        // legend row
        int lx = 0, ly = 10;
        for (Series s : series) {
            int tw = fm.stringWidth(s.name);
            if (lx + tw + 26 > w) { lx = 0; ly += 16; }
            g.setColor(s.color);
            g.fill(new RoundRectangle2D.Double(lx, ly - 7, 12, 4, 4, 4));
            g.setColor(Theme.TEXT_2);
            g.drawString(s.name, lx + 17, ly);
            lx += tw + 32;
        }
        for (Threshold t : thresholds) {
            int tw = fm.stringWidth(t.label);
            if (lx + tw + 26 > w) { lx = 0; ly += 16; }
            g.setColor(t.color);
            g.setStroke(new BasicStroke(1.5f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 1f, new float[]{4f, 3f}, 0f));
            g.draw(new Line2D.Double(lx, ly - 5, lx + 12, ly - 5));
            g.setColor(Theme.MUTED);
            g.drawString(t.label, lx + 17, ly);
            lx += tw + 32;
        }

        // y range
        double min = Double.MAX_VALUE, max = -Double.MAX_VALUE;
        for (Series s : series) for (Double v : s.values) if (v != null && !Double.isNaN(v)) { min = Math.min(min, v); max = Math.max(max, v); }
        boolean empty = min == Double.MAX_VALUE;
        if (empty) { min = 0; max = 1; }
        for (Threshold t : thresholds) if (!empty && t.value < max * 1.6) max = Math.max(max, t.value);
        if (yMinFixed != null) min = Math.min(yMinFixed, min);
        if (max - min < 1e-9) { max += 1; min -= yMinFixed != null ? 0 : 1; }
        double[] ticks = niceTicks(min, max, 5);
        min = ticks[0];
        max = ticks[ticks.length - 1];

        int yLabelW = 0;
        for (double t : ticks) yLabelW = Math.max(yLabelW, fm.stringWidth(fmtTick(t, max - min)));
        plotX0 = yLabelW + 22;
        plotX1 = w - 10;
        plotY0 = ly + 14;
        plotY1 = h - 34;
        if (plotY1 - plotY0 < 30) { g.dispose(); return; }

        // grid + y ticks
        for (double t : ticks) {
            int y = yOf(t, min, max);
            g.setColor(Theme.GRID);
            g.setStroke(new BasicStroke(1f));
            g.drawLine(plotX0, y, plotX1, y);
            g.setColor(Theme.MUTED);
            String s = fmtTick(t, max - min);
            g.drawString(s, plotX0 - 8 - fm.stringWidth(s), y + 4);
        }
        // x ticks (seconds)
        int nx = (int) Math.round(xMax);
        int step = nx <= 10 ? 1 : nx <= 20 ? 2 : 5;
        for (int i = 0; i <= nx; i += step) {
            int x = xOf(i);
            String s = String.valueOf(i);
            g.setColor(Theme.MUTED);
            g.drawString(s, x - fm.stringWidth(s) / 2, plotY1 + 16);
        }
        g.setColor(Theme.MUTED);
        g.drawString(xLabel, plotX1 - fm.stringWidth(xLabel), h - 3);
        // y label rotated
        Graphics2D gr = (Graphics2D) g.create();
        gr.rotate(-Math.PI / 2);
        gr.drawString(yLabel, -(plotY0 + plotY1) / 2 - fm.stringWidth(yLabel) / 2, 10);
        gr.dispose();

        if (empty) {
            g.setColor(Theme.MUTED);
            g.setFont(Theme.BODY);
            String t = emptyText;
            g.drawString(t, (plotX0 + plotX1) / 2 - g.getFontMetrics().stringWidth(t) / 2, (plotY0 + plotY1) / 2);
            g.dispose();
            return;
        }

        // thresholds
        for (Threshold t : thresholds) {
            if (t.value < min || t.value > max) continue;
            int y = yOf(t.value, min, max);
            g.setColor(Theme.alpha(t.color, 200));
            g.setStroke(new BasicStroke(1.2f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 1f, new float[]{5f, 4f}, 0f));
            g.drawLine(plotX0, y, plotX1, y);
        }

        // series
        g.setClip(plotX0 - 2, plotY0 - 4, plotX1 - plotX0 + 4, plotY1 - plotY0 + 6);
        for (Series s : series) {
            GeneralPath p = new GeneralPath();
            boolean started = false;
            double firstX = 0, lastX = 0;
            for (int i = 0; i < xs.size() && i < s.values.size(); i++) {
                Double v = s.values.get(i);
                if (v == null || Double.isNaN(v)) continue;
                double x = xOf(xs.get(i)), y = yOf(v, min, max);
                if (!started) { p.moveTo(x, y); firstX = x; started = true; } else p.lineTo(x, y);
                lastX = x;
            }
            if (!started) continue;
            if (s.area) {
                GeneralPath a = new GeneralPath(p);
                a.lineTo(lastX, plotY1);
                a.lineTo(firstX, plotY1);
                a.closePath();
                g.setPaint(new GradientPaint(0, plotY0, Theme.alpha(s.color, 85), 0, plotY1, Theme.alpha(s.color, 0)));
                g.fill(a);
            }
            g.setColor(s.color);
            g.setStroke(new BasicStroke(2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g.draw(p);
        }
        g.setClip(null);

        // live head marker on the newest point of each series
        if (hoverIndex < 0 && !xs.isEmpty()) {
            int i = xs.size() - 1;
            for (Series s : series) {
                Double v = i < s.values.size() ? s.values.get(i) : null;
                if (v == null || Double.isNaN(v)) continue;
                double x = xOf(xs.get(i)), y = yOf(v, min, max);
                g.setColor(Theme.CARD);
                g.fill(new Ellipse2D.Double(x - 5, y - 5, 10, 10));
                g.setColor(s.color);
                g.fill(new Ellipse2D.Double(x - 3.5, y - 3.5, 7, 7));
            }
        }

        // hover
        if (hoverIndex >= 0 && hoverIndex < xs.size()) drawHover(g, fm, min, max);
        g.dispose();
    }

    private void drawHover(Graphics2D g, FontMetrics fm, double min, double max) {
        int x = xOf(xs.get(hoverIndex));
        g.setColor(Theme.alpha(Theme.TEXT_2, 90));
        g.setStroke(new BasicStroke(1f));
        g.drawLine(x, plotY0, x, plotY1);
        List<String> lines = new ArrayList<>();
        List<Color> colors = new ArrayList<>();
        for (Series s : series) {
            Double v = hoverIndex < s.values.size() ? s.values.get(hoverIndex) : null;
            if (v == null || Double.isNaN(v)) continue;
            int y = yOf(v, min, max);
            g.setColor(Theme.CARD);
            g.fill(new Ellipse2D.Double(x - 5, y - 5, 10, 10));
            g.setColor(s.color);
            g.fill(new Ellipse2D.Double(x - 4, y - 4, 8, 8));
            lines.add(s.name + "  " + String.format(Locale.US, valueFormat, v));
            colors.add(s.color);
        }
        String head = String.format(Locale.US, "t = %.2f s", xs.get(hoverIndex));
        int tw = fm.stringWidth(head);
        for (String l : lines) tw = Math.max(tw, fm.stringWidth(l) + 16);
        int bw = tw + 20, bh = 24 + lines.size() * 16;
        int bx = x + 12 + bw > plotX1 ? x - 12 - bw : x + 12;
        int by = plotY0 + 4;
        g.setColor(new Color(0x0B1224));
        g.fill(new RoundRectangle2D.Double(bx, by, bw, bh, 10, 10));
        g.setColor(Theme.BORDER_HOVER);
        g.draw(new RoundRectangle2D.Double(bx, by, bw, bh, 10, 10));
        g.setFont(Theme.SMALL_BOLD);
        g.setColor(Theme.TEXT);
        g.drawString(head, bx + 10, by + 16);
        g.setFont(Theme.SMALL);
        for (int i = 0; i < lines.size(); i++) {
            int yy = by + 32 + i * 16;
            g.setColor(colors.get(i));
            g.fill(new Ellipse2D.Double(bx + 10, yy - 8, 8, 8));
            g.setColor(Theme.TEXT_2);
            g.drawString(lines.get(i), bx + 24, yy);
        }
    }

    private int xOf(double x) {
        return (int) Math.round(plotX0 + (plotX1 - plotX0) * Math.min(1, x / Math.max(1e-9, xMax)));
    }

    private int yOf(double v, double min, double max) {
        return (int) Math.round(plotY1 - (plotY1 - plotY0) * (v - min) / (max - min));
    }

    static double[] niceTicks(double min, double max, int n) {
        double range = niceNum(max - min, false);
        double step = niceNum(range / (n - 1), true);
        double lo = Math.floor(min / step) * step, hi = Math.ceil(max / step) * step;
        int cnt = (int) Math.round((hi - lo) / step) + 1;
        double[] t = new double[Math.max(2, cnt)];
        for (int i = 0; i < t.length; i++) t[i] = lo + i * step;
        return t;
    }

    private static double niceNum(double x, boolean round) {
        if (x <= 0) return 1;
        double e = Math.floor(Math.log10(x)), f = x / Math.pow(10, e), nf;
        if (round) nf = f < 1.5 ? 1 : f < 3 ? 2 : f < 7 ? 5 : 10;
        else nf = f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10;
        return nf * Math.pow(10, e);
    }

    static String fmtTick(double v, double range) {
        double a = Math.abs(v);
        if (a >= 1e6) return String.format(Locale.US, "%.1fM", v / 1e6);
        if (a >= 1e4) return String.format(Locale.US, "%.0fk", v / 1e3);
        if (range < 5) return String.format(Locale.US, "%.1f", v);
        return String.format(Locale.US, "%.0f", v);
    }
}
