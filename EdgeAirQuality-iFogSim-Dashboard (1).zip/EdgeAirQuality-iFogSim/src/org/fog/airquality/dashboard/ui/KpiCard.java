package org.fog.airquality.dashboard.ui;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Ellipse2D;
import java.awt.geom.GeneralPath;
import java.awt.geom.RoundRectangle2D;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JComponent;

/** Large gradient KPI card: icon, label, value, caption, optional status chip and sparkline. */
public class KpiCard extends JComponent {

    private final String label;
    private final Icons.Kind icon;
    private Color accent;
    private String value = "—", unit = "", caption = "", chip;
    private Color chipColor;
    private final List<Double> spark = new ArrayList<>();
    private boolean hover;
    private final boolean large;

    public KpiCard(String label, Icons.Kind icon, Color accent, boolean large) {
        this.label = label;
        this.icon = icon;
        this.accent = accent;
        this.large = large;
        setOpaque(false);
        addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
            @Override public void mouseExited(MouseEvent e) { hover = false; repaint(); }
        });
    }

    public void set(String value, String unit, String caption) {
        this.value = value;
        this.unit = unit == null ? "" : unit;
        this.caption = caption == null ? "" : caption;
        repaint();
    }

    public void setChip(String text, Color color) {
        chip = text;
        chipColor = color;
        repaint();
    }

    public void setAccent(Color c) {
        accent = c;
        repaint();
    }

    public void addSpark(double v) {
        if (Double.isNaN(v)) return;
        spark.add(v);
        if (spark.size() > 80) spark.remove(0);
        repaint();
    }

    public void clearSpark() {
        spark.clear();
        repaint();
    }

    @Override
    public Dimension getPreferredSize() {
        return new Dimension(210, large ? 132 : 92);
    }

    @Override
    protected void paintComponent(Graphics g0) {
        Graphics2D g = (Graphics2D) g0.create();
        Theme.smooth(g);
        int w = getWidth(), h = getHeight(), r = Theme.RADIUS;
        int lift = hover ? 1 : 0;
        for (int i = 4; i >= 1; i--) {
            g.setColor(new Color(0, 0, 0, 20));
            g.fill(new RoundRectangle2D.Double(-i + 1, -i + 3 - lift, w + 2 * i - 2, h + 2 * i - 3, r + i, r + i));
        }
        RoundRectangle2D shape = new RoundRectangle2D.Double(0, -lift, w - 1, h - 1, r, r);
        g.setPaint(new GradientPaint(0, 0, Theme.mix(Theme.CARD_TOP, accent, hover ? 0.20 : 0.13), w, h, Theme.CARD));
        g.fill(shape);
        // accent glow corner
        g.setClip(shape);
        g.setPaint(new java.awt.RadialGradientPaint(w - 20f, 0f, h * 1.1f, new float[]{0f, 1f},
                new Color[]{Theme.alpha(accent, hover ? 70 : 48), Theme.alpha(accent, 0)}));
        g.fillRect(0, 0, w, h);
        // sparkline
        if (spark.size() > 1) drawSpark(g, w, h);
        g.setClip(null);
        g.setColor(hover ? Theme.alpha(accent, 150) : Theme.BORDER);
        g.draw(shape);

        int pad = 16;
        int is = large ? 36 : 30;
        // icon badge
        g.setPaint(new GradientPaint(pad, pad, Theme.alpha(accent, 90), pad + is, pad + is, Theme.alpha(accent, 30)));
        g.fill(new RoundRectangle2D.Double(pad, pad - lift, is, is, 12, 12));
        Icons.of(icon, large ? 20 : 17, Theme.TEXT).paintIcon(this, g, pad + (is - (large ? 20 : 17)) / 2, pad - lift + (is - (large ? 20 : 17)) / 2);

        g.setFont(Theme.SMALL_BOLD);
        g.setColor(Theme.TEXT_2);
        g.drawString(label.toUpperCase(), pad + is + 12, pad + 14 - lift);
        if (!large) {
            g.setFont(Theme.STAT);
            g.setColor(Theme.TEXT);
            int vx = pad + is + 12;
            g.drawString(value, vx, pad + 38 - lift);
            int vw = g.getFontMetrics().stringWidth(value);
            g.setFont(Theme.SMALL);
            g.setColor(Theme.TEXT_2);
            g.drawString(unit, vx + vw + 5, pad + 38 - lift);
            g.setColor(Theme.MUTED);
            g.drawString(fit(g.getFontMetrics(), caption, w - vx - 10), vx, h - 14 - lift);
        } else {
            g.setFont(Theme.KPI);
            g.setColor(Theme.TEXT);
            int vy = pad + is + 34;
            g.drawString(value, pad, vy - lift);
            int vw = g.getFontMetrics().stringWidth(value);
            g.setFont(Theme.BODY);
            g.setColor(Theme.TEXT_2);
            g.drawString(unit, pad + vw + 6, vy - lift);
            g.setFont(Theme.SMALL);
            g.setColor(Theme.MUTED);
            g.drawString(fit(g.getFontMetrics(), caption, w - 2 * pad), pad, h - 13 - lift);
        }
        if (chip != null) {
            g.setFont(Theme.SMALL_BOLD);
            FontMetrics fm = g.getFontMetrics();
            String t = fit(fm, chip, w / 2);
            int cw = fm.stringWidth(t) + 22, ch = 20;
            int cx = w - pad - cw, cy = large ? pad + 22 : pad - 2;
            if (!large) cy = pad - 4;
            g.setColor(Theme.alpha(chipColor, 40));
            g.fill(new RoundRectangle2D.Double(cx, cy - lift, cw, ch, ch, ch));
            g.setColor(chipColor);
            g.fill(new Ellipse2D.Double(cx + 7, cy + 7 - lift, 6, 6));
            g.drawString(t, cx + 16, cy + 14 - lift);
        }
        g.dispose();
    }

    private void drawSpark(Graphics2D g, int w, int h) {
        double min = Double.MAX_VALUE, max = -Double.MAX_VALUE;
        for (double v : spark) { min = Math.min(min, v); max = Math.max(max, v); }
        if (max - min < 1e-9) { max += 1; min -= 1; }
        int x0 = w / 2, x1 = w - 12, y0 = h - 30, y1 = large ? 70 : h - 58;
        if (!large) { x0 = w - 90; y0 = h - 12; y1 = h - 40; }
        GeneralPath p = new GeneralPath();
        for (int i = 0; i < spark.size(); i++) {
            double x = x0 + (x1 - x0) * i / (double) (spark.size() - 1);
            double y = y0 - (y0 - y1) * (spark.get(i) - min) / (max - min);
            if (i == 0) p.moveTo(x, y); else p.lineTo(x, y);
        }
        GeneralPath area = new GeneralPath(p);
        area.lineTo(x1, y0);
        area.lineTo(x0, y0);
        area.closePath();
        g.setPaint(new GradientPaint(0, y1, Theme.alpha(accent, 60), 0, y0, Theme.alpha(accent, 0)));
        g.fill(area);
        g.setColor(Theme.alpha(accent, 220));
        g.setStroke(new BasicStroke(2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.draw(p);
    }

    static String fit(FontMetrics fm, String s, int max) {
        if (s == null) return "";
        if (fm.stringWidth(s) <= max) return s;
        while (s.length() > 1 && fm.stringWidth(s + "…") > max) s = s.substring(0, s.length() - 1);
        return s + "…";
    }
}
