package org.fog.airquality.dashboard.ui;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Ellipse2D;
import java.awt.geom.GeneralPath;
import java.awt.geom.RoundRectangle2D;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.swing.JComponent;

/** Grouped vertical bar chart with legend, y axis label and per-bar hover tooltip. */
public class BarChart extends JComponent {

    private final String yLabel, valueFormat;
    private final List<String> categories = new ArrayList<>();
    private final List<String> seriesNames = new ArrayList<>();
    private final List<Color> seriesColors = new ArrayList<>();
    private double[][] values = new double[0][0];   // [series][category]
    private final List<Rectangle> hit = new ArrayList<>();
    private final List<int[]> hitIndex = new ArrayList<>();
    private int hover = -1;
    private String emptyText = "Waiting for simulation data…";

    public BarChart(String yLabel, String valueFormat) {
        this.yLabel = yLabel;
        this.valueFormat = valueFormat;
        setOpaque(false);
        MouseAdapter ma = new MouseAdapter() {
            @Override public void mouseMoved(MouseEvent e) {
                int h = -1;
                for (int i = 0; i < hit.size(); i++) if (hit.get(i).contains(e.getPoint())) h = i;
                if (h != hover) { hover = h; repaint(); }
            }
            @Override public void mouseExited(MouseEvent e) { hover = -1; repaint(); }
        };
        addMouseListener(ma);
        addMouseMotionListener(ma);
    }

    public void setSeries(String[] names, Color[] colors) {
        seriesNames.clear();
        seriesColors.clear();
        for (int i = 0; i < names.length; i++) { seriesNames.add(names[i]); seriesColors.add(colors[i]); }
    }

    public void setData(List<String> cats, double[][] vals) {
        categories.clear();
        categories.addAll(cats);
        values = vals;
        repaint();
    }

    public void setEmptyText(String t) { emptyText = t; repaint(); }

    @Override
    public Dimension getPreferredSize() {
        return new Dimension(360, 230);
    }

    @Override
    protected void paintComponent(Graphics g0) {
        Graphics2D g = (Graphics2D) g0.create();
        Theme.smooth(g);
        int w = getWidth(), h = getHeight();
        g.setFont(Theme.SMALL);
        FontMetrics fm = g.getFontMetrics();
        hit.clear();
        hitIndex.clear();

        int lx = 0;
        for (int i = 0; i < seriesNames.size(); i++) {
            g.setColor(seriesColors.get(i));
            g.fill(new RoundRectangle2D.Double(lx, 3, 10, 10, 3, 3));
            g.setColor(Theme.TEXT_2);
            g.drawString(seriesNames.get(i), lx + 15, 12);
            lx += fm.stringWidth(seriesNames.get(i)) + 32;
        }

        double max = 0;
        boolean any = false;
        for (double[] s : values) for (double v : s) if (!Double.isNaN(v)) { max = Math.max(max, v); any = true; }
        if (max <= 0) max = 1;
        double[] ticks = LineChart.niceTicks(0, max, 5);
        max = ticks[ticks.length - 1];
        int yw = 0;
        for (double t : ticks) yw = Math.max(yw, fm.stringWidth(LineChart.fmtTick(t, max)));
        int x0 = yw + 22, x1 = w - 6, y0 = 26, y1 = h - 26;
        for (double t : ticks) {
            int y = (int) Math.round(y1 - (y1 - y0) * t / max);
            g.setColor(Theme.GRID);
            g.drawLine(x0, y, x1, y);
            g.setColor(Theme.MUTED);
            String s = LineChart.fmtTick(t, max);
            g.drawString(s, x0 - 8 - fm.stringWidth(s), y + 4);
        }
        Graphics2D gr = (Graphics2D) g.create();
        gr.rotate(-Math.PI / 2);
        gr.setColor(Theme.MUTED);
        gr.drawString(yLabel, -(y0 + y1) / 2 - fm.stringWidth(yLabel) / 2, 10);
        gr.dispose();
        if (!any || categories.isEmpty()) {
            g.setFont(Theme.BODY);
            g.setColor(Theme.MUTED);
            g.drawString(emptyText, (x0 + x1) / 2 - g.getFontMetrics().stringWidth(emptyText) / 2, (y0 + y1) / 2);
            g.dispose();
            return;
        }
        int nc = categories.size(), ns = values.length;
        double groupW = (x1 - x0) / (double) nc;
        double barW = Math.min(34, (groupW * 0.72 - (ns - 1) * 2) / ns);
        for (int c = 0; c < nc; c++) {
            double gx = x0 + groupW * c + (groupW - (barW * ns + (ns - 1) * 2)) / 2;
            String cat = KpiCard.fit(fm, categories.get(c), (int) groupW - 4);
            g.setColor(Theme.TEXT_2);
            g.drawString(cat, (int) (x0 + groupW * c + groupW / 2 - fm.stringWidth(cat) / 2), y1 + 16);
            for (int s = 0; s < ns; s++) {
                double v = c < values[s].length ? values[s][c] : Double.NaN;
                if (Double.isNaN(v)) continue;
                double bh = Math.max(v > 0 ? 2 : 0, (y1 - y0) * v / max);
                double bx = gx + s * (barW + 2);
                int idx = hit.size();
                Color col = seriesColors.get(s);
                if (hover >= 0 && hover != idx) col = Theme.alpha(col, 120);
                g.setColor(col);
                g.fill(topRounded(bx, y1 - bh, barW, bh, Math.min(4, barW / 2)));
                hit.add(new Rectangle((int) bx - 2, y0, (int) barW + 4, y1 - y0));
                hitIndex.add(new int[]{s, c});
            }
        }
        g.setColor(Theme.BORDER_HOVER);
        g.setStroke(new BasicStroke(1f));
        g.drawLine(x0, y1, x1, y1);
        if (hover >= 0 && hover < hitIndex.size()) {
            int s = hitIndex.get(hover)[0], c = hitIndex.get(hover)[1];
            Rectangle r = hit.get(hover);
            String head = categories.get(c);
            String line = seriesNames.get(s) + "  " + String.format(Locale.US, valueFormat, values[s][c]);
            int bw = Math.max(fm.stringWidth(head), fm.stringWidth(line) + 16) + 20, bh = 42;
            int bx = r.x + r.width + 6;
            if (bx + bw > w) bx = r.x - bw - 6;
            int by = y0 + 4;
            g.setColor(new Color(0x0B1224));
            g.fill(new RoundRectangle2D.Double(bx, by, bw, bh, 10, 10));
            g.setColor(Theme.BORDER_HOVER);
            g.draw(new RoundRectangle2D.Double(bx, by, bw, bh, 10, 10));
            g.setFont(Theme.SMALL_BOLD);
            g.setColor(Theme.TEXT);
            g.drawString(head, bx + 10, by + 16);
            g.setFont(Theme.SMALL);
            g.setColor(seriesColors.get(s));
            g.fill(new Ellipse2D.Double(bx + 10, by + 25, 8, 8));
            g.setColor(Theme.TEXT_2);
            g.drawString(line, bx + 24, by + 33);
        }
        g.dispose();
    }

    private static GeneralPath topRounded(double x, double y, double w, double h, double r) {
        GeneralPath p = new GeneralPath();
        r = Math.min(r, h);
        p.moveTo(x, y + h);
        p.lineTo(x, y + r);
        p.quadTo(x, y, x + r, y);
        p.lineTo(x + w - r, y);
        p.quadTo(x + w, y, x + w, y + r);
        p.lineTo(x + w, y + h);
        p.closePath();
        return p;
    }
}
