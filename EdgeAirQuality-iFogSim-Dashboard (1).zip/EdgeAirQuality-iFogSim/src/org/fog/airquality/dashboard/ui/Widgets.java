package org.fog.airquality.dashboard.ui;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.LayoutManager;
import java.awt.Rectangle;
import java.awt.geom.Ellipse2D;
import java.awt.geom.RoundRectangle2D;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.Scrollable;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;

/** Small reusable widgets of the dashboard. */
public final class Widgets {

    private Widgets() { }

    /** Shared animation clock for the pulsing "live" dots (one timer for the whole UI). */
    public static final List<JComponent> PULSING = new ArrayList<>();
    public static double pulsePhase;
    static {
        Timer t = new Timer(60, e -> {
            pulsePhase = (pulsePhase + 0.06) % 1.0;
            for (JComponent c : PULSING) if (c.isShowing()) c.repaint();
        });
        t.start();
    }

    /** Rounded status pill with a coloured dot that pulses while live. */
    public static class StatusPill extends JComponent {
        private String text;
        private Color color;
        private boolean live;
        private final String prefix;

        public StatusPill(String prefix, String text, Color color) {
            this.prefix = prefix;
            this.text = text;
            this.color = color;
            setFont(Theme.SMALL_BOLD);
            PULSING.add(this);
        }

        public void set(String text, Color color, boolean live) {
            this.text = text;
            this.color = color;
            this.live = live;
            revalidate();
            repaint();
        }

        @Override public Dimension getPreferredSize() {
            FontMetrics fm = getFontMetrics(getFont());
            String p = prefix == null ? "" : prefix + "  ";
            return new Dimension(fm.stringWidth(p + text) + 34, 28);
        }

        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            Theme.smooth(g);
            int w = getWidth(), h = 26, y = (getHeight() - h) / 2;
            g.setColor(Theme.alpha(color, 30));
            g.fill(new RoundRectangle2D.Double(0, y, w - 1, h, h, h));
            g.setColor(Theme.alpha(color, 110));
            g.draw(new RoundRectangle2D.Double(0, y, w - 1, h, h, h));
            double cx = 14, cy = y + h / 2.0;
            if (live) {
                double r = 4 + 6 * pulsePhase;
                g.setColor(Theme.alpha(color, (int) (120 * (1 - pulsePhase))));
                g.fill(new Ellipse2D.Double(cx - r, cy - r, 2 * r, 2 * r));
            }
            g.setColor(color);
            g.fill(new Ellipse2D.Double(cx - 4, cy - 4, 8, 8));
            g.setFont(getFont());
            FontMetrics fm = g.getFontMetrics();
            int tx = 26;
            if (prefix != null) {
                g.setColor(Theme.TEXT_2);
                g.drawString(prefix, tx, y + 17);
                tx += fm.stringWidth(prefix + "  ");
            }
            g.setColor(Theme.TEXT);
            g.drawString(text, tx, y + 17);
            g.dispose();
        }
    }

    /** Node status tile (EdgeNode1, Gateway, Cloud ...) with pulsing dot, status and CPU bar. */
    public static class NodeTile extends JComponent {
        private final Icons.Kind icon;
        private String name = "", status = "Offline", detail = "";
        private Color color = Theme.OFFLINE;
        private double util;
        private boolean live;

        public NodeTile(Icons.Kind icon) {
            this.icon = icon;
            PULSING.add(this);
        }

        public void set(String name, String status, Color color, double util, String detail, boolean live) {
            this.name = name; this.status = status; this.color = color; this.util = util; this.detail = detail; this.live = live;
            repaint();
        }

        @Override public Dimension getPreferredSize() { return new Dimension(170, 84); }

        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            Theme.smooth(g);
            int w = getWidth(), h = getHeight();
            RoundRectangle2D s = new RoundRectangle2D.Double(0, 0, w - 1, h - 1, 14, 14);
            g.setColor(Theme.mix(Theme.CARD, color, 0.07));
            g.fill(s);
            g.setColor(Theme.alpha(color, 90));
            g.draw(s);
            Icons.of(icon, 18, Theme.TEXT_2).paintIcon(this, g, 12, 12);
            g.setFont(Theme.H3);
            g.setColor(Theme.TEXT);
            g.drawString(KpiCard.fit(g.getFontMetrics(), name, w - 60), 38, 26);
            double cx = w - 18, cy = 20;
            if (live) {
                double r = 4 + 7 * pulsePhase;
                g.setColor(Theme.alpha(color, (int) (130 * (1 - pulsePhase))));
                g.fill(new Ellipse2D.Double(cx - r, cy - r, 2 * r, 2 * r));
            }
            g.setColor(color);
            g.fill(new Ellipse2D.Double(cx - 5, cy - 5, 10, 10));
            g.setFont(Theme.SMALL_BOLD);
            g.setColor(color);
            g.drawString(status, 12, 48);
            g.setFont(Theme.SMALL);
            g.setColor(Theme.MUTED);
            g.drawString(KpiCard.fit(g.getFontMetrics(), detail, w - 24), 12, 64);
            // utilisation bar
            g.setColor(Theme.GRID);
            g.fill(new RoundRectangle2D.Double(12, h - 12, w - 24, 4, 4, 4));
            g.setColor(Theme.CYAN);
            g.fill(new RoundRectangle2D.Double(12, h - 12, (w - 24) * Math.max(0, Math.min(1, util)), 4, 4, 4));
            g.dispose();
        }
    }

    /** Compact metric tile: label, big value, unit, caption, coloured left accent. */
    public static class StatTile extends JComponent {
        private final String label;
        private final Icons.Kind icon;
        private String value = "—", unit = "", caption = "";
        private Color accent;

        public StatTile(String label, Icons.Kind icon, Color accent) {
            this.label = label; this.icon = icon; this.accent = accent;
        }

        public void set(String value, String unit, String caption) {
            this.value = value; this.unit = unit; this.caption = caption;
            repaint();
        }

        public void setAccent(Color c) { accent = c; repaint(); }

        @Override public Dimension getPreferredSize() { return new Dimension(170, 86); }

        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            Theme.smooth(g);
            int w = getWidth(), h = getHeight();
            RoundRectangle2D s = new RoundRectangle2D.Double(0, 0, w - 1, h - 1, 14, 14);
            g.setColor(Theme.ROW_ALT);
            g.fill(s);
            g.setColor(Theme.BORDER);
            g.draw(s);
            g.setColor(accent);
            g.fill(new RoundRectangle2D.Double(0, 14, 3, h - 28, 3, 3));
            Icons.of(icon, 14, accent).paintIcon(this, g, 14, 12);
            g.setFont(Theme.SMALL_BOLD);
            g.setColor(Theme.TEXT_2);
            g.drawString(KpiCard.fit(g.getFontMetrics(), label, w - 44), 34, 24);
            g.setFont(Theme.STAT);
            g.setColor(Theme.TEXT);
            g.drawString(value, 14, 52);
            int vw = g.getFontMetrics().stringWidth(value);
            g.setFont(Theme.SMALL);
            g.setColor(Theme.TEXT_2);
            g.drawString(unit, 14 + vw + 5, 52);
            g.setColor(Theme.MUTED);
            g.drawString(KpiCard.fit(g.getFontMetrics(), caption, w - 24), 14, 72);
            g.dispose();
        }
    }

    /** One line of a feed (alert or activity). */
    public static final class FeedItem {
        public final String time, title, text;
        public final Color color;
        public final Icons.Kind icon;
        public FeedItem(String time, String title, String text, Color color, Icons.Kind icon) {
            this.time = time; this.title = title; this.text = text; this.color = color; this.icon = icon;
        }
    }

    /** Painted list of feed items, newest first. */
    public static class Feed extends JComponent {
        private final List<FeedItem> items = new ArrayList<>();
        private final int max;
        private final String empty;
        private final boolean framed;

        public Feed(int max, String empty, boolean framed) {
            this.max = max; this.empty = empty; this.framed = framed;
        }

        public void add(FeedItem it) {
            items.add(0, it);
            while (items.size() > max) items.remove(items.size() - 1);
        }

        public void refresh() { revalidate(); repaint(); }

        public void clear() { items.clear(); refresh(); }

        private int rowH() { return framed ? 50 : 40; }

        @Override public Dimension getPreferredSize() {
            return new Dimension(300, Math.max(60, items.size() * rowH()));
        }

        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            Theme.smooth(g);
            int w = getWidth();
            if (items.isEmpty()) {
                g.setFont(Theme.BODY);
                g.setColor(Theme.MUTED);
                g.drawString(empty, 6, 28);
            }
            Rectangle clip = g.getClipBounds();
            for (int i = 0; i < items.size(); i++) {
                int y = i * rowH();
                if (clip != null && (y > clip.y + clip.height || y + rowH() < clip.y)) continue;
                FeedItem it = items.get(i);
                if (framed) {
                    RoundRectangle2D r = new RoundRectangle2D.Double(0, y + 2, w - 4, rowH() - 6, 10, 10);
                    g.setColor(Theme.mix(Theme.ROW_ALT, it.color, 0.08));
                    g.fill(r);
                    g.setColor(it.color);
                    g.fill(new RoundRectangle2D.Double(0, y + 2, 4, rowH() - 6, 4, 4));
                } else {
                    g.setColor(Theme.alpha(it.color, 40));
                    g.fill(new Ellipse2D.Double(2, y + 6, 26, 26));
                }
                Icons.of(it.icon, 14, it.color).paintIcon(this, g, framed ? 12 : 8, y + (framed ? 9 : 12));
                int tx = framed ? 34 : 38;
                g.setFont(Theme.SMALL_BOLD);
                FontMetrics fm = g.getFontMetrics();
                g.setColor(Theme.MUTED);
                int tw = fm.stringWidth(it.time);
                g.drawString(it.time, w - tw - 12, y + 19);
                g.setColor(framed ? it.color : Theme.TEXT);
                g.drawString(KpiCard.fit(fm, it.title, w - tx - tw - 24), tx, y + 19);
                g.setFont(Theme.SMALL);
                g.setColor(Theme.TEXT_2);
                g.drawString(KpiCard.fit(g.getFontMetrics(), it.text, w - tx - 12), tx, y + (framed ? 37 : 34));
            }
            g.dispose();
        }
    }

    /**
     * Layout that places children in as many equal columns as fit (each at least minWidth wide,
     * at most maxCols), so the dashboard reflows between laptop and large desktop screens.
     * A child can span several columns through {@link #span(Component, int)}.
     */
    public static class ResponsiveGrid implements LayoutManager {
        private final int minWidth, maxCols, gap;
        private final java.util.Map<Component, Integer> spans = new java.util.HashMap<>();
        private final java.util.Map<Component, Integer> fixedHeights = new java.util.HashMap<>();

        public ResponsiveGrid(int minWidth, int maxCols, int gap) {
            this.minWidth = minWidth; this.maxCols = maxCols; this.gap = gap;
        }

        public void span(Component c, int cols) { spans.put(c, cols); }
        public void height(Component c, int h) { fixedHeights.put(c, h); }

        private int cols(int width) {
            return Math.max(1, Math.min(maxCols, (width + gap) / (minWidth + gap)));
        }

        @Override public void addLayoutComponent(String name, Component comp) { }
        @Override public void removeLayoutComponent(Component comp) { spans.remove(comp); }

        private int[] layout(Container p, boolean apply) {
            Insets in = p.getInsets();
            int width = Math.max(minWidth, p.getWidth() - in.left - in.right);
            int cols = cols(width);
            double cw = (width - gap * (cols - 1)) / (double) cols;
            int x = 0, y = in.top, rowH = 0;
            List<Component> row = new ArrayList<>();
            for (Component c : p.getComponents()) {
                if (!c.isVisible()) continue;
                int span = Math.min(cols, spans.containsKey(c) ? spans.get(c) : 1);
                if (x + span > cols) {
                    y += rowH + gap; x = 0; rowH = 0; row.clear();
                }
                Integer fh = fixedHeights.get(c);
                int ph = fh != null ? fh : c.getPreferredSize().height;
                rowH = Math.max(rowH, ph);
                if (apply) {
                    int px = in.left + (int) Math.round(x * (cw + gap));
                    int pw = (int) Math.round(span * cw + (span - 1) * gap);
                    c.setBounds(px, y, pw, ph);
                    row.add(c);
                    for (Component rc : row) { Rectangle b = rc.getBounds(); rc.setBounds(b.x, b.y, b.width, rowH); }
                }
                x += span;
            }
            return new int[]{width, y + rowH + in.bottom};
        }

        @Override public Dimension preferredLayoutSize(Container p) {
            int[] r = layout(p, false);
            return new Dimension(r[0], r[1]);
        }

        @Override public Dimension minimumLayoutSize(Container p) { return new Dimension(minWidth, 50); }

        @Override public void layoutContainer(Container p) { layout(p, true); }
    }

    /** Scrollable content column that always matches the viewport width. */
    public static class Column extends JPanel implements Scrollable {
        public Column() {
            setLayout(new javax.swing.BoxLayout(this, javax.swing.BoxLayout.Y_AXIS));
            setBackground(Theme.BG);
        }
        @Override public Dimension getPreferredScrollableViewportSize() { return getPreferredSize(); }
        @Override public int getScrollableUnitIncrement(Rectangle r, int o, int d) { return 24; }
        @Override public int getScrollableBlockIncrement(Rectangle r, int o, int d) { return r.height - 60; }
        @Override public boolean getScrollableTracksViewportWidth() { return true; }
        @Override public boolean getScrollableTracksViewportHeight() { return false; }
    }

    public static JLabel sectionTitle(String title, String subtitle, Icons.Kind icon) {
        JLabel l = new JLabel("<html><span style='font-size:15px;color:#E6EDF7'><b>" + title
                + "</b></span>&nbsp;&nbsp;<span style='color:#6B7A93'>" + subtitle + "</span></html>");
        l.setIcon(Icons.of(icon, 20, Theme.CYAN));
        l.setIconTextGap(10);
        l.setFont(Theme.H2);
        l.setBorder(BorderFactory.createEmptyBorder(26, 2, 12, 0));
        l.setAlignmentX(0f);
        return l;
    }

    /** Applies the dark table style. */
    public static JScrollPane darkTable(final JTable t) {
        t.setBackground(Theme.CARD);
        t.setForeground(Theme.TEXT);
        t.setFont(Theme.BODY);
        t.setRowHeight(30);
        t.setShowGrid(false);
        t.setIntercellSpacing(new Dimension(0, 0));
        t.setSelectionBackground(Theme.SELECTION);
        t.setSelectionForeground(Theme.TEXT);
        t.setFillsViewportHeight(true);
        JTableHeader h = t.getTableHeader();
        h.setReorderingAllowed(false);
        h.setDefaultRenderer(new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable tb, Object v, boolean s, boolean f, int r, int c) {
                JLabel l = (JLabel) super.getTableCellRendererComponent(tb, v, s, f, r, c);
                l.setBackground(Theme.CARD_TOP);
                l.setForeground(Theme.TEXT_2);
                l.setFont(Theme.SMALL_BOLD);
                l.setHorizontalAlignment(c == 0 ? SwingConstants.LEFT : SwingConstants.CENTER);
                l.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Theme.BORDER),
                        BorderFactory.createEmptyBorder(8, 10, 8, 10)));
                return l;
            }
        });
        JScrollPane sp = new JScrollPane(t);
        sp.setBorder(BorderFactory.createLineBorder(Theme.BORDER));
        sp.getViewport().setBackground(Theme.CARD);
        sp.setBackground(Theme.CARD);
        sp.setWheelScrollingEnabled(false); // let the page scroll; the tables are sized to their rows
        return sp;
    }

    /** Cell renderer: zebra rows, centred numbers, and a coloured pill for status columns. */
    public static class CellRenderer extends DefaultTableCellRenderer {
        public interface Colorizer { Color colorFor(JTable t, Object value, int row, int col); }
        private final Colorizer pill;
        private Color pillColor;
        private boolean asPill;

        public CellRenderer(Colorizer pill) { this.pill = pill; }

        @Override public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean f, int r, int c) {
            JLabel l = (JLabel) super.getTableCellRendererComponent(t, v, sel, false, r, c);
            l.setBackground(sel ? Theme.SELECTION : r % 2 == 0 ? Theme.CARD : Theme.ROW_ALT);
            l.setForeground(c == 0 ? Theme.TEXT : Theme.TEXT_2);
            l.setFont(c == 0 ? Theme.BODY_BOLD : Theme.BODY);
            l.setHorizontalAlignment(c == 0 ? SwingConstants.LEFT : SwingConstants.CENTER);
            l.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10));
            pillColor = pill == null ? null : pill.colorFor(t, v, r, t.convertColumnIndexToModel(c));
            asPill = pillColor != null;
            if (asPill) l.setForeground(Theme.TEXT);
            return l;
        }

        @Override protected void paintComponent(Graphics g0) {
            if (!asPill) { super.paintComponent(g0); return; }
            Graphics2D g = (Graphics2D) g0.create();
            Theme.smooth(g);
            g.setColor(getBackground());
            g.fillRect(0, 0, getWidth(), getHeight());
            g.setFont(Theme.SMALL_BOLD);
            FontMetrics fm = g.getFontMetrics();
            String t = KpiCard.fit(fm, getText(), getWidth() - 34);
            int tw = fm.stringWidth(t) + 24, th = 20;
            int x = (getWidth() - tw) / 2, y = (getHeight() - th) / 2;
            g.setColor(Theme.alpha(pillColor, 38));
            g.fill(new RoundRectangle2D.Double(x, y, tw, th, th, th));
            g.setColor(pillColor);
            g.fill(new Ellipse2D.Double(x + 8, y + 7, 6, 6));
            g.setColor(Theme.TEXT);
            g.drawString(t, x + 18, y + 14);
            g.dispose();
        }
    }

    public static String num(double v, String fmt) {
        return Double.isNaN(v) ? "—" : String.format(Locale.US, fmt, v);
    }

    public static String bytes(double b) {
        if (b >= 1e9) return String.format(Locale.US, "%.2f GB", b / 1e9);
        if (b >= 1e6) return String.format(Locale.US, "%.2f MB", b / 1e6);
        if (b >= 1e3) return String.format(Locale.US, "%.1f kB", b / 1e3);
        return String.format(Locale.US, "%.0f B", b);
    }

    /** A thin progress bar. */
    public static class Progress extends JComponent {
        private double value;
        private Color color = Theme.CYAN;
        public void set(double v, Color c) { value = v; color = c; repaint(); }
        @Override public Dimension getPreferredSize() { return new Dimension(160, 8); }
        @Override protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            Theme.smooth(g);
            int h = 6, y = (getHeight() - h) / 2;
            g.setColor(Theme.GRID);
            g.fill(new RoundRectangle2D.Double(0, y, getWidth(), h, h, h));
            g.setPaint(new java.awt.GradientPaint(0, 0, Theme.ACCENT_GRAD_A, getWidth(), 0, color));
            g.fill(new RoundRectangle2D.Double(0, y, getWidth() * Math.max(0, Math.min(1, value)), h, h, h));
            g.setStroke(new BasicStroke(1f));
            g.dispose();
        }
    }
}
