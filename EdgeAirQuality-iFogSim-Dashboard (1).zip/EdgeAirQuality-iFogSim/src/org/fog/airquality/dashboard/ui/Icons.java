package org.fog.airquality.dashboard.ui;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Arc2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.GeneralPath;
import java.awt.geom.Line2D;
import java.awt.geom.RoundRectangle2D;

import javax.swing.Icon;

/** Small vector line icons drawn with Java2D (no image files needed). Designed on a 24 x 24 grid. */
public final class Icons {

    public enum Kind {
        DASHBOARD, SENSOR, FOG, GATEWAY, CLOUD, ALERT, NETWORK, ENERGY, CLOCK, COMPARE, ACTIVITY,
        THERMO, DROP, WIND, CPU, PACKET, CHECK, PLAY, PAUSE, STOP, RESET, LEAF, GAUGE
    }

    private Icons() { }

    public static Icon of(Kind kind, int size, Color color) {
        return new VectorIcon(kind, size, color);
    }

    static final class VectorIcon implements Icon {
        final Kind kind;
        final int size;
        final Color color;

        VectorIcon(Kind kind, int size, Color color) { this.kind = kind; this.size = size; this.color = color; }

        @Override public int getIconWidth() { return size; }
        @Override public int getIconHeight() { return size; }

        @Override
        public void paintIcon(Component c, Graphics g0, int x, int y) {
            Graphics2D g = (Graphics2D) g0.create();
            Theme.smooth(g);
            g.translate(x, y);
            g.scale(size / 24.0, size / 24.0);
            g.setColor(color);
            g.setStroke(new BasicStroke(1.9f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            draw(g, kind);
            g.dispose();
        }
    }

    static void draw(Graphics2D g, Kind k) {
        switch (k) {
            case DASHBOARD:
                g.draw(new RoundRectangle2D.Double(3, 3, 8, 10, 2, 2));
                g.draw(new RoundRectangle2D.Double(13, 3, 8, 6, 2, 2));
                g.draw(new RoundRectangle2D.Double(13, 11, 8, 10, 2, 2));
                g.draw(new RoundRectangle2D.Double(3, 15, 8, 6, 2, 2));
                break;
            case SENSOR:
                g.fill(new Ellipse2D.Double(10, 10, 4, 4));
                g.draw(new Arc2D.Double(6, 6, 12, 12, -45, 90, Arc2D.OPEN));
                g.draw(new Arc2D.Double(6, 6, 12, 12, 135, 90, Arc2D.OPEN));
                g.draw(new Arc2D.Double(2, 2, 20, 20, -45, 90, Arc2D.OPEN));
                g.draw(new Arc2D.Double(2, 2, 20, 20, 135, 90, Arc2D.OPEN));
                break;
            case FOG:
                g.draw(new RoundRectangle2D.Double(3, 4, 18, 6, 2, 2));
                g.draw(new RoundRectangle2D.Double(3, 14, 18, 6, 2, 2));
                g.fill(new Ellipse2D.Double(6, 6, 2, 2));
                g.fill(new Ellipse2D.Double(6, 16, 2, 2));
                g.draw(new Line2D.Double(11, 7, 18, 7));
                g.draw(new Line2D.Double(11, 17, 18, 17));
                break;
            case GATEWAY:
                g.draw(new RoundRectangle2D.Double(3, 13, 18, 7, 2, 2));
                g.draw(new Line2D.Double(8, 13, 8, 9));
                g.draw(new Line2D.Double(16, 13, 16, 9));
                g.draw(new Arc2D.Double(4, 3, 8, 8, 30, 120, Arc2D.OPEN));
                g.draw(new Arc2D.Double(12, 3, 8, 8, 30, 120, Arc2D.OPEN));
                g.fill(new Ellipse2D.Double(6.5, 15.5, 2, 2));
                g.fill(new Ellipse2D.Double(10.5, 15.5, 2, 2));
                break;
            case CLOUD: {
                GeneralPath p = new GeneralPath();
                p.moveTo(7, 19);
                p.curveTo(3.5, 19, 2, 16.5, 2.5, 14.5);
                p.curveTo(3, 12, 5.5, 11, 7, 11.3);
                p.curveTo(7.5, 7.5, 10.5, 5, 14, 5.5);
                p.curveTo(17.5, 6, 19.5, 9, 19, 12);
                p.curveTo(21.5, 12.5, 22.5, 14.5, 22, 16.5);
                p.curveTo(21.5, 18.5, 20, 19, 18, 19);
                p.closePath();
                g.draw(p);
                break;
            }
            case ALERT: {
                GeneralPath p = new GeneralPath();
                p.moveTo(12, 3); p.lineTo(22, 20); p.lineTo(2, 20); p.closePath();
                g.draw(p);
                g.draw(new Line2D.Double(12, 9, 12, 14));
                g.fill(new Ellipse2D.Double(11, 16, 2, 2));
                break;
            }
            case NETWORK:
                g.draw(new Ellipse2D.Double(9, 2, 6, 6));
                g.draw(new Ellipse2D.Double(2, 16, 6, 6));
                g.draw(new Ellipse2D.Double(16, 16, 6, 6));
                g.draw(new Line2D.Double(10.5, 7.5, 6.5, 16.5));
                g.draw(new Line2D.Double(13.5, 7.5, 17.5, 16.5));
                g.draw(new Line2D.Double(8, 19, 16, 19));
                break;
            case ENERGY: {
                GeneralPath p = new GeneralPath();
                p.moveTo(13, 2); p.lineTo(4, 14); p.lineTo(11, 14); p.lineTo(10, 22); p.lineTo(20, 9); p.lineTo(13, 9); p.closePath();
                g.draw(p);
                break;
            }
            case CLOCK:
                g.draw(new Ellipse2D.Double(3, 3, 18, 18));
                g.draw(new Line2D.Double(12, 7, 12, 12));
                g.draw(new Line2D.Double(12, 12, 15.5, 14));
                break;
            case COMPARE:
                g.draw(new Line2D.Double(4, 20, 20, 20));
                g.draw(new RoundRectangle2D.Double(5, 10, 4, 10, 1.5, 1.5));
                g.draw(new RoundRectangle2D.Double(10, 5, 4, 15, 1.5, 1.5));
                g.draw(new RoundRectangle2D.Double(15, 13, 4, 7, 1.5, 1.5));
                break;
            case ACTIVITY: {
                GeneralPath p = new GeneralPath();
                p.moveTo(2, 12); p.lineTo(6, 12); p.lineTo(9, 4); p.lineTo(15, 20); p.lineTo(18, 12); p.lineTo(22, 12);
                g.draw(p);
                break;
            }
            case THERMO:
                g.draw(new RoundRectangle2D.Double(9.5, 2.5, 5, 12, 5, 5));
                g.draw(new Ellipse2D.Double(7.5, 13, 9, 9));
                g.fill(new Ellipse2D.Double(10, 15.5, 4, 4));
                g.draw(new Line2D.Double(12, 8, 12, 15));
                break;
            case DROP: {
                GeneralPath p = new GeneralPath();
                p.moveTo(12, 2.5);
                p.curveTo(12, 2.5, 5, 10.5, 5, 15);
                p.curveTo(5, 19, 8, 21.5, 12, 21.5);
                p.curveTo(16, 21.5, 19, 19, 19, 15);
                p.curveTo(19, 10.5, 12, 2.5, 12, 2.5);
                g.draw(p);
                break;
            }
            case WIND: {
                GeneralPath p = new GeneralPath();
                p.moveTo(2, 9); p.lineTo(14, 9); p.curveTo(18, 9, 18, 3.5, 14.5, 4);
                g.draw(p);
                GeneralPath q = new GeneralPath();
                q.moveTo(2, 14); q.lineTo(18, 14); q.curveTo(22.5, 14, 22.5, 20.5, 18, 20);
                g.draw(q);
                g.draw(new Line2D.Double(2, 18.5, 10, 18.5));
                break;
            }
            case CPU:
                g.draw(new RoundRectangle2D.Double(6, 6, 12, 12, 2, 2));
                g.draw(new RoundRectangle2D.Double(9.5, 9.5, 5, 5, 1, 1));
                for (int i = 0; i < 3; i++) {
                    double o = 9 + i * 3;
                    g.draw(new Line2D.Double(o, 2.5, o, 6));
                    g.draw(new Line2D.Double(o, 18, o, 21.5));
                    g.draw(new Line2D.Double(2.5, o, 6, o));
                    g.draw(new Line2D.Double(18, o, 21.5, o));
                }
                break;
            case PACKET: {
                GeneralPath p = new GeneralPath();
                p.moveTo(12, 2.5); p.lineTo(20.5, 7); p.lineTo(20.5, 17); p.lineTo(12, 21.5); p.lineTo(3.5, 17); p.lineTo(3.5, 7); p.closePath();
                g.draw(p);
                g.draw(new Line2D.Double(3.5, 7, 12, 11.5));
                g.draw(new Line2D.Double(20.5, 7, 12, 11.5));
                g.draw(new Line2D.Double(12, 11.5, 12, 21.5));
                break;
            }
            case CHECK: {
                g.draw(new Ellipse2D.Double(3, 3, 18, 18));
                GeneralPath p = new GeneralPath();
                p.moveTo(8, 12.5); p.lineTo(11, 15.5); p.lineTo(16.5, 9);
                g.draw(p);
                break;
            }
            case PLAY: {
                GeneralPath p = new GeneralPath();
                p.moveTo(7, 4); p.lineTo(20, 12); p.lineTo(7, 20); p.closePath();
                g.fill(p);
                break;
            }
            case PAUSE:
                g.fill(new RoundRectangle2D.Double(6, 4, 4, 16, 1.5, 1.5));
                g.fill(new RoundRectangle2D.Double(14, 4, 4, 16, 1.5, 1.5));
                break;
            case STOP:
                g.fill(new RoundRectangle2D.Double(5, 5, 14, 14, 3, 3));
                break;
            case RESET: {
                g.draw(new Arc2D.Double(4, 4, 16, 16, 100, 290, Arc2D.OPEN));
                GeneralPath p = new GeneralPath();
                p.moveTo(4, 3.5); p.lineTo(4.5, 9); p.lineTo(10, 8);
                g.draw(p);
                break;
            }
            case LEAF: {
                GeneralPath p = new GeneralPath();
                p.moveTo(4, 20);
                p.curveTo(4, 9, 10, 4, 20, 4);
                p.curveTo(20, 14, 15, 20, 4, 20);
                g.draw(p);
                g.draw(new Line2D.Double(4, 20, 14, 10));
                break;
            }
            case GAUGE:
                g.draw(new Arc2D.Double(2.5, 4.5, 19, 19, 0, 180, Arc2D.OPEN));
                g.draw(new Line2D.Double(12, 14, 16.5, 8.5));
                g.fill(new Ellipse2D.Double(10.5, 12.5, 3, 3));
                break;
            default:
                g.draw(new Ellipse2D.Double(4, 4, 16, 16));
        }
    }
}
