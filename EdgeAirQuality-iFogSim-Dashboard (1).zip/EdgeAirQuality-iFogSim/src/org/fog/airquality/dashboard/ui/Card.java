package org.fog.airquality.dashboard.ui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

/** Rounded panel with a soft shadow, an optional icon + title header and a body. */
public class Card extends JPanel {

    private boolean hover;
    private Color glow;
    protected final JPanel header;
    protected final JLabel titleLabel;
    protected final JLabel subtitleLabel;
    protected final JPanel right;

    public Card(String title, String subtitle, Icons.Kind icon, JComponent body) {
        super(new BorderLayout(0, 10));
        setOpaque(false);
        setBorder(BorderFactory.createEmptyBorder(16, 18, 16, 18));
        header = new JPanel(new BorderLayout(10, 0));
        header.setOpaque(false);
        JPanel titles = new JPanel();
        titles.setOpaque(false);
        titles.setLayout(new BoxLayout(titles, BoxLayout.Y_AXIS));
        titleLabel = new JLabel(title);
        titleLabel.setFont(Theme.H3);
        titleLabel.setForeground(Theme.TEXT);
        if (icon != null) {
            titleLabel.setIcon(Icons.of(icon, 16, Theme.CYAN));
            titleLabel.setIconTextGap(8);
        }
        titles.add(titleLabel);
        subtitleLabel = new JLabel(subtitle == null ? "" : subtitle);
        subtitleLabel.setFont(Theme.SMALL);
        subtitleLabel.setForeground(Theme.MUTED);
        subtitleLabel.setBorder(BorderFactory.createEmptyBorder(3, icon != null ? 24 : 0, 0, 0));
        if (subtitle != null) titles.add(subtitleLabel);
        header.add(titles, BorderLayout.CENTER);
        right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        right.setOpaque(false);
        header.add(right, BorderLayout.EAST);
        if (title != null) add(header, BorderLayout.NORTH);
        if (body != null) add(body, BorderLayout.CENTER);
        MouseAdapter ma = new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { setHover(true); }
            @Override public void mouseExited(MouseEvent e) {
                if (!SwingUtilities.isDescendingFrom(e.getComponent(), Card.this) || !contains(SwingUtilities.convertPoint(e.getComponent(), e.getPoint(), Card.this)))
                    setHover(false);
            }
        };
        addMouseListener(ma);
    }

    public void setSubtitle(String s) {
        subtitleLabel.setText(s);
    }

    public void addHeaderComponent(JComponent c) {
        right.add(c);
    }

    /** Coloured outline used to draw attention (for example active critical alerts). */
    public void setGlow(Color c) {
        if (c == null ? glow != null : !c.equals(glow)) { glow = c; repaint(); }
    }

    private void setHover(boolean h) {
        if (hover != h) { hover = h; repaint(); }
    }

    @Override
    public Dimension getMinimumSize() {
        Dimension d = super.getMinimumSize();
        return new Dimension(Math.min(d.width, 200), d.height);
    }

    @Override
    protected void paintComponent(Graphics g0) {
        Graphics2D g = (Graphics2D) g0.create();
        Theme.smooth(g);
        int w = getWidth(), h = getHeight(), r = Theme.RADIUS;
        // shadow
        for (int i = 4; i >= 1; i--) {
            g.setColor(new Color(0, 0, 0, 18));
            g.fill(new RoundRectangle2D.Double(-i + 1, -i + 3, w + 2 * i - 2, h + 2 * i - 3, r + i, r + i));
        }
        RoundRectangle2D shape = new RoundRectangle2D.Double(0, 0, w - 1, h - 1, r, r);
        g.setPaint(new GradientPaint(0, 0, hover ? Theme.CARD_HOVER : Theme.CARD_TOP, 0, h, Theme.CARD));
        g.fill(shape);
        g.setColor(glow != null ? Theme.alpha(glow, 170) : hover ? Theme.BORDER_HOVER : Theme.BORDER);
        g.draw(shape);
        g.dispose();
    }
}
