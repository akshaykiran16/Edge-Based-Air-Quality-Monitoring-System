package org.fog.airquality.dashboard.ui;

import java.awt.Color;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.awt.RenderingHints;
import java.awt.Graphics2D;
import java.util.Arrays;
import java.util.List;

import org.fog.airquality.dashboard.Snapshot.Severity;

/** Design tokens of the dashboard: colours, fonts and spacing used by every component. */
public final class Theme {

    private Theme() { }

    // surfaces
    public static final Color BG = new Color(0x070B16);
    public static final Color SIDEBAR = new Color(0x0A1020);
    public static final Color TOPBAR = new Color(0x0B1224);
    public static final Color CARD = new Color(0x111A2C);
    public static final Color CARD_TOP = new Color(0x15213A);
    public static final Color CARD_HOVER = new Color(0x182641);
    public static final Color BORDER = new Color(0x1F2D48);
    public static final Color BORDER_HOVER = new Color(0x2D4A75);
    public static final Color GRID = new Color(0x1B2740);
    public static final Color ROW_ALT = new Color(0x0F1728);
    public static final Color SELECTION = new Color(0x1A3358);

    // text
    public static final Color TEXT = new Color(0xE6EDF7);
    public static final Color TEXT_2 = new Color(0xA3B1C8);
    public static final Color MUTED = new Color(0x6B7A93);

    // brand accents
    public static final Color BLUE = new Color(0x3B8FF0);
    public static final Color CYAN = new Color(0x22D3EE);
    public static final Color PURPLE = new Color(0x8B5CF6);
    public static final Color ACCENT_GRAD_A = new Color(0x2563EB);
    public static final Color ACCENT_GRAD_B = new Color(0x06B6D4);

    // status (reserved: never used as a series colour)
    public static final Color GOOD = new Color(0x22C55E);
    public static final Color WARNING = new Color(0xFAB219);
    public static final Color CRITICAL = new Color(0xEF4444);
    public static final Color OFFLINE = new Color(0x64748B);

    /** Categorical series colours in fixed order (validated for CVD separation on the card surface). */
    public static final List<Color> SERIES = Arrays.asList(
            new Color(0x3B8FF0), new Color(0xD9632B), new Color(0x19A07A),
            new Color(0xC08400), new Color(0xD9609A), new Color(0x8F84EC));

    public static Color series(int i) {
        return SERIES.get(i % SERIES.size());
    }

    public static Color severity(Severity s) {
        if (s == null) return GOOD;
        switch (s) {
            case CRITICAL: return CRITICAL;
            case WARNING: return WARNING;
            default: return GOOD;
        }
    }

    /** EPA AQI category colours (the official scale, toned for the dark surface). */
    public static Color aqi(double aqi) {
        if (Double.isNaN(aqi) || aqi < 0) return MUTED;
        if (aqi <= 50) return new Color(0x22C55E);
        if (aqi <= 100) return new Color(0xEAB308);
        if (aqi <= 150) return new Color(0xF97316);
        if (aqi <= 200) return new Color(0xEF4444);
        if (aqi <= 300) return new Color(0xA855F7);
        return new Color(0xBE123C);
    }

    public static Color alpha(Color c, int a) {
        return new Color(c.getRed(), c.getGreen(), c.getBlue(), Math.max(0, Math.min(255, a)));
    }

    public static Color mix(Color a, Color b, double t) {
        return new Color((int) (a.getRed() + (b.getRed() - a.getRed()) * t),
                (int) (a.getGreen() + (b.getGreen() - a.getGreen()) * t),
                (int) (a.getBlue() + (b.getBlue() - a.getBlue()) * t));
    }

    // fonts
    private static final String FAMILY = pickFamily();

    private static String pickFamily() {
        String[] wanted = {"Segoe UI", "Inter", "SF Pro Text", "Helvetica Neue", "Roboto", "Noto Sans", "DejaVu Sans"};
        try {
            List<String> have = Arrays.asList(GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames());
            for (String w : wanted) if (have.contains(w)) return w;
        } catch (Throwable ignored) { }
        return Font.SANS_SERIF;
    }

    public static Font font(int style, float size) {
        return new Font(FAMILY, style, Math.round(size));
    }

    public static final Font H1 = font(Font.BOLD, 19);
    public static final Font H2 = font(Font.BOLD, 15);
    public static final Font H3 = font(Font.BOLD, 13);
    public static final Font BODY = font(Font.PLAIN, 13);
    public static final Font BODY_BOLD = font(Font.BOLD, 13);
    public static final Font SMALL = font(Font.PLAIN, 11);
    public static final Font SMALL_BOLD = font(Font.BOLD, 11);
    public static final Font KPI = font(Font.BOLD, 28);
    public static final Font STAT = font(Font.BOLD, 20);
    public static final Font MONO = new Font(Font.MONOSPACED, Font.PLAIN, 12);

    public static final int GAP = 16;
    public static final int RADIUS = 16;

    public static void smooth(Graphics2D g) {
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
    }
}
