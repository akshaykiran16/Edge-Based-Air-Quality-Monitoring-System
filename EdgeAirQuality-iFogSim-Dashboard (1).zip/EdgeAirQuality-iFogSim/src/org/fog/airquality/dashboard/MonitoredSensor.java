package org.fog.airquality.dashboard;

import org.cloudbus.cloudsim.core.CloudSim;
import org.fog.entities.Sensor;
import org.fog.utils.distribution.Distribution;

/**
 * iFogSim Sensor that attaches a physical air quality reading to every AQ_SENSOR tuple it emits.
 * The tuple itself (size, timing, destination) is created by the original Sensor code.
 */
public class MonitoredSensor extends Sensor {

    private final MetricsCollector collector;
    private int lastTupleId = -1;

    public MonitoredSensor(String name, String tupleType, int userId, String appId,
                           Distribution transmitDistribution, MetricsCollector collector) {
        super(name, tupleType, userId, appId, transmitDistribution);
        this.collector = collector;
    }

    @Override
    protected int updateTimings(String src, String dest) {
        lastTupleId = super.updateTimings(src, dest);
        return lastTupleId;
    }

    @Override
    public void transmit() {
        lastTupleId = -1;
        super.transmit();
        collector.onSensorEmit(getId(), lastTupleId, CloudSim.clock());
    }
}
