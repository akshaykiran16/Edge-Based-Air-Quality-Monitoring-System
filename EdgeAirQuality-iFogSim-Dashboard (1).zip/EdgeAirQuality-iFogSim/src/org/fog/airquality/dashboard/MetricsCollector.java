package org.fog.airquality.dashboard;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import org.cloudbus.cloudsim.Vm;
import org.fog.airquality.AQICalculator;
import org.fog.airquality.AirQualityDataDemo;
import org.fog.airquality.EdgeDataFilter;
import org.fog.airquality.SensorReading;
import org.fog.application.AppModule;
import org.fog.entities.FogDevice;
import org.fog.entities.Tuple;
import org.fog.utils.NetworkUsageMonitor;

import org.fog.airquality.dashboard.Snapshot.ActivityEvent;
import org.fog.airquality.dashboard.Snapshot.AlertRecord;
import org.fog.airquality.dashboard.Snapshot.AlertType;
import org.fog.airquality.dashboard.Snapshot.EventKind;
import org.fog.airquality.dashboard.Snapshot.Severity;

/**
 * Observes the running iFogSim simulation and turns its events into dashboard metrics.
 *
 * It is called only from the simulation thread, by the monitored entities:
 *  - MonitoredSensor   : a sensor emitted an AQ_SENSOR tuple (a reading is attached here),
 *  - MonitoredFogDevice: a tuple arrived at a device / a module started executing a tuple,
 *  - MonitoredApplication: a module finished executing a tuple (filter, AQI and alert logic run here),
 *  - MonitoredActuator : the AQI indicator received its AQI_DISPLAY tuple (end of the control loop),
 *  - DashboardMonitor  : periodic sampling, which produces a {@link Snapshot} for the UI.
 */
public final class MetricsCollector {

    /** Sampling period of the dashboard in simulated milliseconds. */
    public static final double SAMPLE_INTERVAL = 50.0;

    // ---------------------------------------------------------------- alert thresholds
    public static final double TEMP_WARN = 30, TEMP_CRIT = 35;          // deg C
    public static final double PM25_WARN = 35.4, PM25_CRIT = 55.4;      // ug/m3 (EPA AQI 100 / 150 breakpoints)
    public static final double PM10_WARN = 154, PM10_CRIT = 254;        // ug/m3 (EPA AQI 100 / 150 breakpoints)
    public static final double CO2_WARN = 750, CO2_CRIT = 1000;         // ppm
    public static final int AQI_WARN = AirQualityDataDemo.ALERT_THRESHOLD, AQI_CRIT = 150;
    /** A value must fall below this fraction of the warning level before an alert clears. */
    static final double CLEAR_FACTOR = 0.9;

    enum Role {
        CLOUD("Cloud"), GATEWAY("Gateway"), EDGE("Edge / fog node"), SENSOR_NODE("Sensor node");
        final String label;
        Role(String l) { label = l; }
    }

    /** Statistics of one fog device. */
    static final class Dev {
        FogDevice device;
        String name, label;
        Role role;
        int area = -1;
        double busyPower, idlePower, mips;
        int ramMb;
        long arrivals, tasksReceived, tasksCompleted;
        double execSum;
        final Map<Integer, Double> running = new HashMap<>();
        final Deque<double[]> energyHistory = new ArrayDeque<>();
        double util;
        long completedAtLastCheck;
        int samplesWithoutProgress;
        Severity health = Severity.NORMAL;
        String status = "Starting";
    }

    /** State of one sensor node. */
    static final class Sens {
        int index, area, node, entityId;
        String id, zone;
        long emitted, analysed, invalid;
        final EdgeDataFilter filter = new EdgeDataFilter();
        final Deque<Boolean> recentInvalid = new ArrayDeque<>();
        int consecutiveInvalid;
        SensorReading lastValid;
        double co2 = Double.NaN;
        String outcome = "Waiting";
        AQICalculator.Result aqi;
        Severity severity = Severity.NORMAL;
    }

    /** A reading travelling through the simulated application inside one tuple chain. */
    static final class Live {
        Sens sensor;
        SensorReading raw, clean;
        double co2, emitTime;
        EdgeDataFilter.Outcome outcome;
        AQICalculator.Result aqi;
    }

    // ---------------------------------------------------------------- configuration
    final String mode;
    final int areas, nodesPerArea;
    final double sensingInterval, maxSimTime;
    final long tuplesPerSensor;
    private final LiveSensorFeed feed;
    private final Random fallback = new Random(11L);

    // ---------------------------------------------------------------- state
    private final List<Dev> devices = new ArrayList<>();
    private final Map<Integer, Dev> deviceById = new HashMap<>();
    private final List<Sens> sensors = new ArrayList<>();
    private final Map<Integer, Sens> sensorByEntity = new HashMap<>();
    private final Map<Integer, Live> live = new HashMap<>();
    private Live current;   // reading of the tuple whose results are being computed right now

    private long sensorPackets, derivedTuples, deliveredToFilter, filterDone, loops;
    private long forwarded, suppressed, invalidSamples, analysedSamples;
    private long cloudRequests, cloudTasks, alertsToCloud;
    private double cloudBytesIn, cloudStorageBytes, cloudExecSum;
    private double latencySum, windowLatencySum;
    private long latencyCount, windowLatencyCount;
    private double alertDelaySum, analysisSum;
    private long alertDelayCount, analysisCount;
    private double lastNetwork, lastSampleTime;
    private long alertsTotal;
    private final long[] alertCount = new long[AlertType.values().length];
    private final Map<String, Severity> alertState = new HashMap<>();
    private final List<AlertRecord> pendingAlerts = new ArrayList<>();
    private final List<ActivityEvent> pendingEvents = new ArrayList<>();
    private boolean placementReported;
    private String lastCityCategory = "";
    private long nextPacketMilestone = 5000;

    MetricsCollector(String mode, int areas, int nodesPerArea, double sensingInterval, double maxSimTime) {
        this.mode = mode;
        this.areas = areas;
        this.nodesPerArea = nodesPerArea;
        this.sensingInterval = sensingInterval;
        this.maxSimTime = maxSimTime;
        this.tuplesPerSensor = (long) Math.ceil(maxSimTime / sensingInterval);
        this.feed = new LiveSensorFeed(areas, nodesPerArea);
    }

    // ================================================================ registration

    void registerDevice(FogDevice d, double busyPower, double idlePower, int ramMb, double mips) {
        Dev s = new Dev();
        s.device = d;
        s.name = d.getName();
        s.busyPower = busyPower;
        s.idlePower = idlePower;
        s.ramMb = ramMb;
        s.mips = mips;
        if (s.name.equals("cloud")) { s.role = Role.CLOUD; s.label = "Cloud"; }
        else if (s.name.startsWith("isp")) { s.role = Role.GATEWAY; s.label = "Gateway"; }
        else if (s.name.startsWith("fog-gw-")) {
            s.role = Role.EDGE;
            s.area = Integer.parseInt(s.name.substring("fog-gw-".length()));
            s.label = "EdgeNode" + (s.area + 1);
        } else {
            s.role = Role.SENSOR_NODE;
            s.area = Integer.parseInt(s.name.split("-")[1]);
            s.label = s.name;
        }
        devices.add(s);
        deviceById.put(d.getId(), s);
    }

    void registerSensor(int entityId, String name, int area, int node) {
        Sens s = new Sens();
        s.index = area * nodesPerArea + node;
        s.area = area;
        s.node = node;
        s.entityId = entityId;
        s.id = name.toUpperCase(Locale.ROOT);
        s.zone = feed.zoneOf(s.index).name().charAt(0) + feed.zoneOf(s.index).name().substring(1).toLowerCase(Locale.ROOT);
        while (sensors.size() <= s.index) sensors.add(null);
        sensors.set(s.index, s);
        sensorByEntity.put(entityId, s);
    }

    // ================================================================ simulation events

    /** A sensor emitted its next AQ_SENSOR tuple; attach the next reading of that station. */
    void onSensorEmit(int sensorEntityId, int actualTupleId, double now) {
        Sens s = sensorByEntity.get(sensorEntityId);
        if (s == null) return;
        sensorPackets++;
        Live l = new Live();
        l.sensor = s;
        l.raw = feed.reading(s.index, s.emitted, tuplesPerSensor);
        l.co2 = feed.co2For(l.raw);
        l.emitTime = now;
        s.emitted++;
        if (actualTupleId >= 0) live.put(actualTupleId, l);
        if (sensorPackets >= nextPacketMilestone) {
            event(now, EventKind.SENSOR, String.format(Locale.US, "%,d sensor packets generated", nextPacketMilestone));
            nextPacketMilestone += 5000;
        }
    }

    void onTupleArrival(FogDevice device, Tuple tuple, double now) {
        Dev d = deviceById.get(device.getId());
        if (d == null) return;
        d.arrivals++;
        if (d.role == Role.CLOUD && tuple.getDirection() != Tuple.ACTUATOR) {
            cloudRequests++;
            cloudBytesIn += tuple.getCloudletFileSize();
            if ("PUBLIC_ALERT".equals(tuple.getTupleType())) {
                alertsToCloud++;
                if (alertsToCloud == 1 || alertsToCloud % 500 == 0)
                    event(now, EventKind.CLOUD, String.format(Locale.US, "Cloud stored PUBLIC_ALERT #%,d", alertsToCloud));
            }
        }
    }

    void onTaskStart(FogDevice device, Tuple tuple, String module, double now) {
        Dev d = deviceById.get(device.getId());
        if (d == null) return;
        d.tasksReceived++;
        d.running.put(tuple.getCloudletId(), now);
        if ("AQ_SENSOR".equals(tuple.getTupleType())) deliveredToFilter++;
    }

    /**
     * A module finished executing {@code input} on device {@code deviceId}. Runs the real edge
     * logic for the reading carried by the tuple, before iFogSim computes the resulting tuples.
     */
    void onTaskComplete(int deviceId, String module, Tuple input, double now) {
        Dev d = deviceById.get(deviceId);
        if (d != null) {
            Double start = d.running.remove(input.getCloudletId());
            if (start != null) {
                d.tasksCompleted++;
                d.execSum += now - start;
                if (d.role == Role.CLOUD) { cloudTasks++; cloudExecSum += now - start; }
                if ("aqi_analyzer".equals(module)) { analysisSum += now - start; analysisCount++; }
            }
            if (d.role == Role.CLOUD && "cloud_storage".equals(module)) cloudStorageBytes += input.getCloudletFileSize();
        }
        Live l = live.get(input.getActualTupleId());
        current = l;
        if (l == null) return;
        if ("data_filter".equals(module) && "AQ_SENSOR".equals(input.getTupleType())) runEdgeFilter(l, now, input.getActualTupleId());
        else if ("aqi_analyzer".equals(module) && "FILTERED_DATA".equals(input.getTupleType())) runAqiAnalyzer(l, now);
    }

    void afterResultTuples(int count) {
        derivedTuples += count;
        current = null;
    }

    /** EdgeDataFilter on the sensor node: validation, spike suppression and dead-band forwarding. */
    private void runEdgeFilter(Live l, double now, int key) {
        Sens s = l.sensor;
        EdgeDataFilter.Decision dec = s.filter.process(l.raw);
        l.outcome = dec.outcome;
        l.clean = dec.reading;
        filterDone++;
        boolean bad = dec.outcome == EdgeDataFilter.Outcome.DROPPED_INVALID;
        s.recentInvalid.addLast(bad);
        if (s.recentInvalid.size() > 10) s.recentInvalid.removeFirst();
        int badInWindow = 0;
        for (Boolean b : s.recentInvalid) if (b) badInWindow++;
        if (bad) {
            invalidSamples++;
            s.invalid++;
            s.consecutiveInvalid++;
            s.outcome = "Invalid - dropped";
        } else {
            s.consecutiveInvalid = 0;
            s.lastValid = dec.reading;
            s.co2 = l.co2;
            if (dec.outcome == EdgeDataFilter.Outcome.FORWARDED) { forwarded++; s.outcome = "Forwarded"; }
            else { suppressed++; s.outcome = "Suppressed (no change)"; }
        }
        Severity sev = s.consecutiveInvalid >= 3 ? Severity.CRITICAL
                : badInWindow >= 2 ? Severity.WARNING : Severity.NORMAL;
        String msg = s.consecutiveInvalid >= 3
                ? s.consecutiveInvalid + " consecutive invalid samples (sensor fault)"
                : badInWindow + " invalid samples in the last 10 (PM2.5=" + fmt(l.raw.pm25) + ")";
        raise(AlertType.SENSOR_FAILURE, s.id, sev, msg, now);
        if (dec.outcome != EdgeDataFilter.Outcome.FORWARDED) live.remove(key);
    }

    /** AQICalculator on the aqi_analyzer module (fog gateway or cloud, depending on the placement). */
    private void runAqiAnalyzer(Live l, double now) {
        if (l.clean == null) return;
        Sens s = l.sensor;
        l.aqi = AQICalculator.compute(l.clean);
        s.aqi = l.aqi;
        s.analysed++;
        analysedSamples++;
        SensorReading r = l.clean;
        Severity worst = Severity.NORMAL;
        worst = max(worst, raise(AlertType.HIGH_TEMPERATURE, s.id, level(r.temperature, TEMP_WARN, TEMP_CRIT, AlertType.HIGH_TEMPERATURE, s.id),
                "Temperature " + fmt(r.temperature) + " °C", now));
        worst = max(worst, raise(AlertType.HIGH_PM25, s.id, level(r.pm25, PM25_WARN, PM25_CRIT, AlertType.HIGH_PM25, s.id),
                "PM2.5 " + fmt(r.pm25) + " µg/m³", now));
        worst = max(worst, raise(AlertType.HIGH_PM10, s.id, level(r.pm10, PM10_WARN, PM10_CRIT, AlertType.HIGH_PM10, s.id),
                "PM10 " + fmt(r.pm10) + " µg/m³", now));
        worst = max(worst, raise(AlertType.HIGH_CO2, s.id, level(l.co2, CO2_WARN, CO2_CRIT, AlertType.HIGH_CO2, s.id),
                "CO2 " + Math.round(l.co2) + " ppm", now));
        worst = max(worst, raise(AlertType.UNHEALTHY_AQI, s.id, level(l.aqi.aqi, AQI_WARN, AQI_CRIT, AlertType.UNHEALTHY_AQI, s.id),
                "AQI " + l.aqi.aqi + " (" + l.aqi.category + ", " + l.aqi.dominantPollutant + ")", now));
        s.severity = worst;
        if (worst != Severity.NORMAL) {
            alertDelaySum += now - l.emitTime;
            alertDelayCount++;
        }
    }

    /** AQI_DISPLAY reached the AQI indicator of a sensor node: one sense-analyse-actuate loop done. */
    void onActuatorTuple(Tuple tuple, double now) {
        if (!"AQI_DISPLAY".equals(tuple.getTupleType())) return;
        Live l = live.get(tuple.getActualTupleId());
        if (l == null) return;
        double lat = now - l.emitTime;
        loops++;
        latencySum += lat;
        latencyCount++;
        windowLatencySum += lat;
        windowLatencyCount++;
    }

    /** Data-driven selectivity: the decision of the real edge logic for the current tuple. */
    boolean select(String module, String inputType, String outputType, double ratio) {
        Live l = current;
        if (l != null) {
            if ("FILTERED_DATA".equals(outputType)) return l.outcome == EdgeDataFilter.Outcome.FORWARDED;
            if ("PUBLIC_ALERT".equals(outputType)) return l.aqi != null && l.aqi.isAlert(AQI_WARN);
            if (ratio >= 1.0) return true;
        }
        return fallback.nextDouble() < ratio;
    }

    // ================================================================ alerts

    private Severity level(double value, double warn, double crit, AlertType t, String source) {
        Severity prev = alertState.get(t.name() + "|" + source);
        if (value > crit) return Severity.CRITICAL;
        if (value > warn) return Severity.WARNING;
        if (prev != null && prev != Severity.NORMAL && value > warn * CLEAR_FACTOR) return Severity.WARNING;
        return Severity.NORMAL;
    }

    /** Normal evaluations in a row needed before an active alert is lowered or cleared. */
    static final int CLEAR_AFTER = 8;
    private final Map<String, Integer> calmStreak = new HashMap<>();

    private Severity raise(AlertType t, String source, Severity sev, String msg, double now) {
        String key = t.name() + "|" + source;
        Severity prev = alertState.get(key);
        if (prev == null) prev = Severity.NORMAL;
        if (sev == prev) { calmStreak.remove(key); return sev; }
        if (sev.ordinal() < prev.ordinal()) {
            // de-bounce: lower an alert only after the value stayed lower for several samples
            Integer n = calmStreak.get(key);
            n = n == null ? 1 : n + 1;
            if (n < CLEAR_AFTER) { calmStreak.put(key, n); return prev; }
            calmStreak.remove(key);
            alertState.put(key, sev);
            if (sev == Severity.NORMAL) event(now, EventKind.CLEARED, t.label + " cleared on " + source);
            return sev;
        }
        calmStreak.remove(key);
        alertState.put(key, sev);
        alertsTotal++;
        alertCount[t.ordinal()]++;
        pendingAlerts.add(new AlertRecord(now, t, sev, source, msg));
        event(now, EventKind.ALERT, (sev == Severity.CRITICAL ? "CRITICAL " : "WARNING ") + t.label + " on " + source + ": " + msg);
        return sev;
    }

    private void event(double now, EventKind kind, String text) {
        pendingEvents.add(new ActivityEvent(now, kind, text));
        if (pendingEvents.size() > 400) pendingEvents.remove(0);
    }

    double lastSampleTime() {
        return lastSampleTime;
    }

    void info(double now, String text) {
        event(now, EventKind.INFO, text);
    }

    // ================================================================ sampling

    /** Builds the snapshot for the dashboard. Called every SAMPLE_INTERVAL simulated ms. */
    Snapshot sample(double now, boolean finished) {
        if (!placementReported && now > 0) reportPlacement(now);
        Snapshot sn = new Snapshot();
        sn.simTime = now;
        sn.maxSimTime = maxSimTime;
        sn.sensingInterval = sensingInterval;
        sn.dayMinute = (int) Math.min(1439, now / maxSimTime * 1440);
        sn.mode = mode;
        sn.areas = areas;
        sn.nodesPerArea = nodesPerArea;
        sn.finalSnapshot = finished;

        // ---------------- devices
        double eCloud = 0, eGw = 0, eEdge = 0, eNodes = 0;
        long tasksStarted = 0, tasksDone = 0;
        double execAll = 0;
        int fogNodes = 0, gateways = 0;
        boolean degraded = false;
        Snapshot.DeviceRow nodesRow = new Snapshot.DeviceRow();
        nodesRow.name = "node-*";
        nodesRow.label = "Sensor nodes";
        nodesRow.role = Role.SENSOR_NODE.label;
        nodesRow.count = 0;
        double nodeExec = 0;
        Set<String> nodeModules = new LinkedHashSet<>();
        for (Dev d : devices) {
            double e = d.device.getEnergyConsumption();
            updateUtilisation(d, now, e);
            updateHealth(d, now);
            tasksStarted += d.tasksReceived;
            tasksDone += d.tasksCompleted;
            execAll += d.execSum;
            double mem = memoryUtil(d);
            String mods = modulesOf(d);
            switch (d.role) {
                case CLOUD: eCloud += e; break;
                case GATEWAY: eGw += e; gateways++; break;
                case EDGE: eEdge += e; fogNodes++; break;
                default: eNodes += e;
            }
            if (d.health == Severity.CRITICAL) degraded = true;
            if (d.role == Role.SENSOR_NODE) {
                nodesRow.count++;
                nodesRow.arrivals += d.arrivals;
                nodesRow.tasksReceived += d.tasksReceived;
                nodesRow.tasksProcessed += d.tasksCompleted;
                nodesRow.energy += e;
                nodesRow.cpuUtil += d.util;
                nodesRow.memUtil += mem;
                nodesRow.mips = d.mips;
                nodeExec += d.execSum;
                if (!mods.isEmpty()) nodeModules.add(mods);
                if (d.health.ordinal() > nodesRow.health.ordinal()) nodesRow.health = d.health;
                continue;
            }
            Snapshot.DeviceRow row = new Snapshot.DeviceRow();
            row.name = d.name;
            row.label = d.label;
            row.role = d.role.label;
            row.status = d.status;
            row.health = d.health;
            row.arrivals = d.arrivals;
            row.tasksReceived = d.tasksReceived;
            row.tasksProcessed = d.tasksCompleted;
            row.avgProcessingMs = d.tasksCompleted > 0 ? d.execSum / d.tasksCompleted : Double.NaN;
            row.cpuUtil = d.util;
            row.memUtil = mem;
            row.energy = e;
            row.mips = d.mips;
            row.modules = mods.isEmpty() ? "routing only" : mods;
            sn.devices.add(row);
            if (d.role == Role.CLOUD) sn.cloudUtil = d.util;
        }
        if (nodesRow.count > 0) {
            nodesRow.cpuUtil /= nodesRow.count;
            nodesRow.memUtil /= nodesRow.count;
            nodesRow.avgProcessingMs = nodesRow.tasksProcessed > 0 ? nodeExec / nodesRow.tasksProcessed : Double.NaN;
            nodesRow.modules = nodeModules.isEmpty() ? "routing only" : String.join(", ", nodeModules);
            nodesRow.status = nodesRow.health == Severity.CRITICAL ? "Fault" : nodesRow.cpuUtil > 0.9 ? "Busy" : "Online";
            sn.devices.add(nodesRow);
        }
        sortDevices(sn.devices);

        sn.totalSensors = sensors.size();
        sn.totalFogNodes = fogNodes;
        sn.totalGateways = gateways;
        sn.energyCloud = eCloud;
        sn.energyGateway = eGw;
        sn.energyEdge = eEdge;
        sn.energyNodes = eNodes;
        sn.energyTotal = eCloud + eGw + eEdge + eNodes;
        sn.cloudStatus = finished ? "Offline" : sn.cloudUtil > 0.85 ? "Busy" : "Online";
        sn.systemStatus = finished ? "Offline" : degraded ? "Degraded" : "Online";

        // ---------------- counters
        sn.packetsGenerated = sensorPackets;
        sn.tuplesGenerated = sensorPackets + derivedTuples;
        sn.packetsProcessed = filterDone;
        sn.alertsTotal = alertsTotal;
        int active = 0;
        for (Severity s : alertState.values()) if (s != Severity.NORMAL) active++;
        sn.activeAlerts = active;
        sn.loopsCompleted = loops;
        sn.forwarded = forwarded;
        sn.suppressed = suppressed;
        sn.invalidSamples = invalidSamples;
        sn.analysedSamples = analysedSamples;

        // ---------------- cloud
        sn.cloudRequests = cloudRequests;
        sn.cloudTasks = cloudTasks;
        sn.cloudProcessingMs = cloudTasks > 0 ? cloudExecSum / cloudTasks : Double.NaN;
        sn.cloudBytesIn = cloudBytesIn;
        sn.cloudStorageBytes = cloudStorageBytes;

        // ---------------- performance
        double net = NetworkUsageMonitor.getNetworkUsage();
        double dt = now - lastSampleTime;
        sn.networkUsage = now > 0 ? net / now : 0;
        sn.networkRate = dt > 0 ? (net - lastNetwork) / dt : 0;
        lastNetwork = net;
        lastSampleTime = now;
        sn.avgLoopLatency = latencyCount > 0 ? latencySum / latencyCount : Double.NaN;
        sn.windowLoopLatency = windowLatencyCount > 0 ? windowLatencySum / windowLatencyCount : Double.NaN;
        windowLatencySum = 0;
        windowLatencyCount = 0;
        sn.avgProcessingMs = tasksDone > 0 ? execAll / tasksDone : Double.NaN;
        sn.analysisMs = analysisCount > 0 ? analysisSum / analysisCount : Double.NaN;
        sn.alertResponseDelay = alertDelayCount > 0 ? alertDelaySum / alertDelayCount : Double.NaN;
        sn.taskCompletionRate = tasksStarted > 0 ? 100.0 * tasksDone / tasksStarted : Double.NaN;
        sn.packetDeliveryRatio = sensorPackets > 0 ? 100.0 * deliveredToFilter / sensorPackets : Double.NaN;

        // ---------------- sensors and area averages
        double[][] acc = new double[areas][7];
        double[] cityAcc = new double[7];
        for (Sens s : sensors) {
            if (s == null) continue;
            Snapshot.SensorRow row = new Snapshot.SensorRow();
            row.id = s.id;
            row.area = "Area " + (s.area + 1);
            row.zone = s.zone;
            row.samples = s.emitted;
            row.analysed = s.analysed;
            row.invalid = s.invalid;
            row.filterOutcome = s.outcome;
            row.severity = s.severity;
            if (s.lastValid != null) {
                row.hasReading = true;
                row.temperature = s.lastValid.temperature;
                row.humidity = s.lastValid.humidity;
                row.pm25 = s.lastValid.pm25;
                row.pm10 = s.lastValid.pm10;
                row.co = s.lastValid.co;
                row.co2 = s.co2;
                double[] a = acc[s.area];
                a[0] += row.temperature; a[1] += row.humidity; a[2] += row.pm25; a[3] += row.pm10; a[4] += row.co2; a[6]++;
                cityAcc[0] += row.temperature; cityAcc[1] += row.humidity; cityAcc[2] += row.pm25; cityAcc[3] += row.pm10; cityAcc[4] += row.co2; cityAcc[6]++;
            }
            if (s.aqi != null) {
                row.aqi = s.aqi.aqi;
                row.category = s.aqi.category;
                row.dominant = s.aqi.dominantPollutant;
            }
            sn.sensors.add(row);
        }
        // AQI averages over analysed sensors
        double[] aqiSum = new double[areas];
        int[] aqiCnt = new int[areas];
        double cityAqi = 0;
        int cityAqiCnt = 0;
        for (Sens s : sensors) {
            if (s == null || s.aqi == null) continue;
            aqiSum[s.area] += s.aqi.aqi;
            aqiCnt[s.area]++;
            cityAqi += s.aqi.aqi;
            cityAqiCnt++;
        }
        for (int a = 0; a < areas; a++) {
            Snapshot.AreaValues v = new Snapshot.AreaValues();
            fill(v, acc[a]);
            v.aqi = aqiCnt[a] > 0 ? aqiSum[a] / aqiCnt[a] : Double.NaN;
            sn.areaValues.add(v);
        }
        fill(sn.city, cityAcc);
        sn.city.aqi = cityAqiCnt > 0 ? cityAqi / cityAqiCnt : Double.NaN;
        if (!Double.isNaN(sn.city.aqi)) {
            String cat = AQICalculator.categoryOf((int) Math.round(sn.city.aqi));
            if (!cat.equals(lastCityCategory)) {
                event(now, EventKind.INFO, "City average AQI is now " + Math.round(sn.city.aqi) + " (" + cat + ")");
                lastCityCategory = cat;
            }
        }

        // ---------------- alerts
        System.arraycopy(alertCount, 0, sn.alertCountByType, 0, alertCount.length);
        for (int i = 0; i < sn.alertSeverityByType.length; i++) sn.alertSeverityByType[i] = Severity.NORMAL;
        for (Map.Entry<String, Severity> e : alertState.entrySet()) {
            int t = AlertType.valueOf(e.getKey().substring(0, e.getKey().indexOf('|'))).ordinal();
            if (e.getValue().ordinal() > sn.alertSeverityByType[t].ordinal()) sn.alertSeverityByType[t] = e.getValue();
        }
        sn.newAlerts.addAll(pendingAlerts);
        pendingAlerts.clear();
        sn.newEvents.addAll(pendingEvents);
        pendingEvents.clear();

        // forget readings whose tuple chain is long finished
        Iterator<Map.Entry<Integer, Live>> it = live.entrySet().iterator();
        while (it.hasNext()) if (it.next().getValue().emitTime < now - 3000) it.remove();
        return sn;
    }

    private static void fill(Snapshot.AreaValues v, double[] a) {
        if (a[6] == 0) return;
        v.temperature = a[0] / a[6];
        v.humidity = a[1] / a[6];
        v.pm25 = a[2] / a[6];
        v.pm10 = a[3] / a[6];
        v.co2 = a[4] / a[6];
    }

    /** CPU utilisation over the last few samples, recovered from iFogSim's linear power model:
     *  P = P_idle + (P_busy - P_idle) * u, so u = (dE/dt - P_idle) / (P_busy - P_idle). */
    private void updateUtilisation(Dev d, double now, double energy) {
        d.energyHistory.addLast(new double[]{now, energy});
        while (d.energyHistory.size() > 5) d.energyHistory.removeFirst();
        double[] first = d.energyHistory.peekFirst();
        double dt = now - first[0];
        if (dt <= 0 || d.busyPower <= d.idlePower) return;
        double power = (energy - first[1]) / dt;
        d.util = Math.max(0, Math.min(1, (power - d.idlePower) / (d.busyPower - d.idlePower)));
    }

    /** Fog node health: overloaded when the CPU is saturated, failed when it stops finishing work. */
    private void updateHealth(Dev d, double now) {
        if (d.role == Role.SENSOR_NODE && d.tasksReceived == 0) { d.status = "Idle"; return; }
        boolean progress = d.tasksCompleted > d.completedAtLastCheck;
        d.completedAtLastCheck = d.tasksCompleted;
        if (!d.running.isEmpty() && !progress) d.samplesWithoutProgress++;
        else d.samplesWithoutProgress = 0;
        Severity sev;
        String status;
        String msg;
        if (d.samplesWithoutProgress >= 4) {
            sev = Severity.CRITICAL;
            status = "Not responding";
            msg = d.running.size() + " tasks queued, none finished for " + Math.round(d.samplesWithoutProgress * SAMPLE_INTERVAL) + " ms";
        } else if (d.util >= 0.95 && d.running.size() > 5) {
            sev = Severity.WARNING;
            status = "Overloaded";
            msg = "CPU " + Math.round(d.util * 100) + "%, " + d.running.size() + " tasks queued";
        } else {
            sev = Severity.NORMAL;
            status = d.tasksReceived == 0 ? (d.arrivals > 0 ? "Online · routing" : "Online") : d.util > 0.6 ? "Busy" : "Online";
            msg = "";
        }
        if (d.role != Role.SENSOR_NODE || modulesOf(d).contains("aqi_analyzer")) {
            Severity prev = d.health;
            sev = raise(AlertType.FOG_NODE_FAILURE, d.label, sev, msg, now);
            if (prev != sev && sev == Severity.NORMAL)
                event(now, EventKind.FOG, d.label + " back to normal");
        }
        d.health = sev;
        d.status = status;
    }

    private static double memoryUtil(Dev d) {
        try {
            double ram = d.device.getHost().getRamProvisioner().getRam();
            return ram > 0 ? d.device.getHost().getRamProvisioner().getUsedRam() / ram : 0;
        } catch (RuntimeException e) {
            return 0;
        }
    }

    private static String modulesOf(Dev d) {
        StringBuilder sb = new StringBuilder();
        for (Vm vm : d.device.getHost().getVmList()) {
            if (!(vm instanceof AppModule)) continue;
            String n = ((AppModule) vm).getName();
            if (sb.indexOf(n) >= 0) continue;
            if (sb.length() > 0) sb.append(", ");
            sb.append(n);
        }
        return sb.toString();
    }

    private void reportPlacement(double now) {
        placementReported = true;
        Map<String, List<String>> where = new java.util.LinkedHashMap<>();
        for (Dev d : devices) {
            for (Vm vm : d.device.getHost().getVmList()) {
                if (!(vm instanceof AppModule)) continue;
                String m = ((AppModule) vm).getName();
                List<String> l = where.get(m);
                if (l == null) { l = new ArrayList<>(); where.put(m, l); }
                String lbl = d.role == Role.SENSOR_NODE ? "sensor nodes" : d.label;
                if (!l.contains(lbl)) l.add(lbl);
            }
        }
        for (Map.Entry<String, List<String>> e : where.entrySet())
            event(now, EventKind.FOG, "Module " + e.getKey() + " placed on " + String.join(", ", e.getValue()));
    }

    private static void sortDevices(List<Snapshot.DeviceRow> rows) {
        rows.sort((a, b) -> {
            int ra = rank(a), rb = rank(b);
            return ra != rb ? Integer.compare(ra, rb) : a.label.compareTo(b.label);
        });
    }

    private static int rank(Snapshot.DeviceRow r) {
        if (r.role.equals(Role.EDGE.label)) return 0;
        if (r.role.equals(Role.GATEWAY.label)) return 1;
        if (r.role.equals(Role.CLOUD.label)) return 2;
        return 3;
    }

    private static Severity max(Severity a, Severity b) {
        return a.ordinal() >= b.ordinal() ? a : b;
    }

    static String fmt(double v) {
        return String.format(Locale.US, "%.1f", v);
    }
}
