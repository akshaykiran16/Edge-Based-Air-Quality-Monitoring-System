package org.fog.airquality.dashboard;

import java.lang.reflect.Field;
import java.util.Locale;

import javax.swing.SwingUtilities;

import org.fog.airquality.EdgeAirQualitySimulation;
import org.fog.utils.Config;
import org.fog.utils.NetworkUsageMonitor;
import org.fog.utils.TimeKeeper;

/**
 * Runs EdgeAirQualitySimulation on a background thread for the dashboard and provides
 * start / pause / resume / stop / speed control. Snapshots are delivered on the Swing thread.
 */
public final class SimulationEngine implements DashboardMonitor.Pacer {

    public enum State { READY, INITIALIZING, RUNNING, PAUSED, COMPLETED, STOPPED, ERROR }

    /** One simulation configuration chosen in the dashboard. */
    public static final class RunConfig {
        public final String mode;
        public final int areas, nodesPerArea;
        public final double interval;
        public RunConfig(String mode, int areas, int nodesPerArea, double interval) {
            this.mode = mode; this.areas = areas; this.nodesPerArea = nodesPerArea; this.interval = interval;
        }
        public int sensors() { return areas * nodesPerArea; }
        @Override public String toString() {
            return String.format(Locale.US, "%s, %d sensors (%d areas x %d), %.0f ms", mode, sensors(), areas, nodesPerArea, interval);
        }
    }

    public interface Listener {
        void onStarted(RunConfig config);
        void onSnapshot(Snapshot snapshot);
        void onState(State state, String message);
    }

    private final Listener listener;
    private volatile State state = State.READY;
    private volatile boolean paused, stopRequested;
    /** Simulated milliseconds per wall-clock second; 0 = as fast as possible. */
    private volatile double speed = 250;
    private Thread thread;

    private long baseWall;
    private double baseSim, baseSpeed = -1;
    private boolean wasPaused;

    public SimulationEngine(Listener listener) {
        this.listener = listener;
    }

    public State getState() { return state; }
    public void setSpeed(double simMsPerSecond) { speed = simMsPerSecond; }
    public boolean isBusy() { return thread != null && thread.isAlive(); }

    public synchronized boolean start(final RunConfig cfg) {
        if (isBusy()) return false;
        stopRequested = false;
        paused = false;
        baseSpeed = -1;
        thread = new Thread(new Runnable() {
            @Override public void run() { runInternal(cfg); }
        }, "ifogsim-simulation");
        thread.setDaemon(true);
        thread.start();
        return true;
    }

    public void pause() {
        if (state == State.RUNNING) { paused = true; setState(State.PAUSED, "Paused"); }
    }

    public void resume() {
        if (state == State.PAUSED) { paused = false; setState(State.RUNNING, "Running"); }
    }

    public void stop() {
        stopRequested = true;
        paused = false;
    }

    /** Waits (up to timeoutMs) for the simulation thread to end. */
    public void awaitIdle(long timeoutMs) {
        Thread t = thread;
        if (t == null) return;
        try { t.join(timeoutMs); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }

    private void runInternal(RunConfig cfg) {
        setState(State.INITIALIZING, "Building topology for " + cfg);
        try {
            resetIFogSimState();
            EdgeAirQualitySimulation.configure(cfg.mode, cfg.areas, cfg.nodesPerArea, cfg.interval);
            MetricsCollector collector = new MetricsCollector(cfg.mode, cfg.areas, cfg.nodesPerArea, cfg.interval, 10000);
            DashboardHooks hooks = new DashboardHooks(collector, this);
            System.out.println("Dashboard run: " + cfg + String.format(Locale.US, " | edge filter forward ratio=%.3f alert ratio=%.3f",
                    EdgeAirQualitySimulation.getForwardRatio(), EdgeAirQualitySimulation.getAlertRatio()));
            final RunConfig c = cfg;
            SwingUtilities.invokeLater(new Runnable() { @Override public void run() { listener.onStarted(c); } });
            setState(State.RUNNING, "Running");
            EdgeAirQualitySimulation.runSimulation(hooks);
            double end = hooks.getController() != null && hooks.getController().getEndTime() > 0
                    ? hooks.getController().getEndTime() : collector.lastSampleTime();
            Snapshot fin = collector.sample(end, true);
            publish(fin);
            if (stopRequested) setState(State.STOPPED, String.format(Locale.US, "Stopped at %.0f ms of simulated time", end));
            else setState(State.COMPLETED, String.format(Locale.US, "Completed %.0f ms of simulated time", end));
        } catch (Throwable t) {
            t.printStackTrace();
            setState(State.ERROR, t.getClass().getSimpleName() + (t.getMessage() != null ? ": " + t.getMessage() : ""));
        }
    }

    /** iFogSim keeps some results in static fields; clear them so a new run starts from zero. */
    static void resetIFogSimState() throws Exception {
        Config.MAX_SIMULATION_TIME = 10000;
        Field tk = TimeKeeper.class.getDeclaredField("instance");
        tk.setAccessible(true);
        tk.set(null, null);
        Field nu = NetworkUsageMonitor.class.getDeclaredField("networkUsage");
        nu.setAccessible(true);
        nu.setDouble(null, 0.0);
    }

    // ------------------------------------------------------------ Pacer (simulation thread)

    @Override
    public void onSample(Snapshot snapshot) {
        publish(snapshot);
        while (paused && !stopRequested) {
            wasPaused = true;
            sleep(40);
        }
        double sp = speed;
        long now = System.currentTimeMillis();
        if (sp <= 0 || sp != baseSpeed || wasPaused) {
            baseWall = now;
            baseSim = snapshot.simTime;
            baseSpeed = sp;
            wasPaused = false;
            return;
        }
        long target = baseWall + (long) ((snapshot.simTime - baseSim) / sp * 1000.0);
        long wait = target - now;
        if (wait < -500) { baseWall = now; baseSim = snapshot.simTime; }
        while (wait > 0 && !stopRequested && !paused && speed == sp) {
            sleep(Math.min(wait, 40));
            wait = target - System.currentTimeMillis();
        }
    }

    @Override
    public boolean stopRequested() {
        return stopRequested;
    }

    private void publish(final Snapshot s) {
        SwingUtilities.invokeLater(new Runnable() { @Override public void run() { listener.onSnapshot(s); } });
    }

    private void setState(final State st, final String msg) {
        state = st;
        SwingUtilities.invokeLater(new Runnable() { @Override public void run() { listener.onState(st, msg); } });
    }

    private static void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }
}
