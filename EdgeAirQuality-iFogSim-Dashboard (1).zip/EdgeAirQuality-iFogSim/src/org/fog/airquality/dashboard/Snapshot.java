package org.fog.airquality.dashboard;

import java.util.ArrayList;
import java.util.List;

/**
 * Immutable picture of the running simulation, taken by {@link MetricsCollector} on the
 * simulation thread and handed to the Swing dashboard. Every number in it comes from the
 * iFogSim entities or from the readings that flowed through the simulated modules.
 */
public final class Snapshot {

    // ------------------------------------------------------------------ shared types

    public enum Severity { NORMAL, WARNING, CRITICAL }

    public enum AlertType {
        HIGH_TEMPERATURE("High temperature"),
        HIGH_PM25("High PM2.5"),
        HIGH_PM10("High PM10"),
        HIGH_CO2("High CO2"),
        UNHEALTHY_AQI("Unhealthy AQI"),
        SENSOR_FAILURE("Sensor failure"),
        FOG_NODE_FAILURE("Fog node failure");

        public final String label;
        AlertType(String label) { this.label = label; }
    }

    /** One raised alert (a transition of a sensor / node into WARNING or CRITICAL). */
    public static final class AlertRecord {
        public final double simTime;
        public final AlertType type;
        public final Severity severity;
        public final String source;
        public final String message;
        public AlertRecord(double simTime, AlertType type, Severity severity, String source, String message) {
            this.simTime = simTime; this.type = type; this.severity = severity; this.source = source; this.message = message;
        }
    }

    public enum EventKind { INFO, SENSOR, FOG, CLOUD, ALERT, CLEARED, NETWORK }

    /** One line of the recent activity feed. */
    public static final class ActivityEvent {
        public final double simTime;
        public final EventKind kind;
        public final String text;
        public ActivityEvent(double simTime, EventKind kind, String text) {
            this.simTime = simTime; this.kind = kind; this.text = text;
        }
    }

    /** Latest values of one air quality sensor node. */
    public static final class SensorRow {
        public String id, area, zone, filterOutcome, category, dominant;
        public double temperature, humidity, pm25, pm10, co, co2;
        public int aqi = -1;          // -1 until the first sample was analysed by aqi_analyzer
        public long samples, analysed, invalid;
        public Severity severity = Severity.NORMAL;
        public boolean hasReading;
    }

    /** One fog device (or the aggregated row of all sensor nodes). */
    public static final class DeviceRow {
        public String name, label, role, status, modules;
        public int count = 1;
        public long arrivals, tasksReceived, tasksProcessed;
        public double avgProcessingMs = Double.NaN, cpuUtil, memUtil, energy, mips;
        public Severity health = Severity.NORMAL;
    }

    /** Per-area averages used by the live charts. */
    public static final class AreaValues {
        public double temperature = Double.NaN, humidity = Double.NaN, aqi = Double.NaN, pm25 = Double.NaN, pm10 = Double.NaN, co2 = Double.NaN;
    }

    // ------------------------------------------------------------------ fields

    public double simTime, maxSimTime, sensingInterval;
    public int dayMinute;
    public String mode;
    public int areas, nodesPerArea;

    // overview
    public int totalSensors, totalFogNodes, totalGateways;
    public String cloudStatus, systemStatus;
    public long packetsGenerated, tuplesGenerated, packetsProcessed, alertsTotal, activeAlerts;

    public final List<SensorRow> sensors = new ArrayList<>();
    public final List<DeviceRow> devices = new ArrayList<>();

    // cloud
    public long cloudRequests, cloudTasks;
    public double cloudProcessingMs = Double.NaN, cloudBytesIn, cloudStorageBytes, cloudUtil;

    // performance
    public double avgLoopLatency = Double.NaN, windowLoopLatency = Double.NaN;
    public double networkUsage, networkRate;
    public double energyTotal, energyCloud, energyGateway, energyEdge, energyNodes;
    public double avgProcessingMs = Double.NaN, analysisMs = Double.NaN;
    public double alertResponseDelay = Double.NaN;
    public double taskCompletionRate = Double.NaN, packetDeliveryRatio = Double.NaN;
    public long loopsCompleted, forwarded, suppressed, invalidSamples, analysedSamples;

    // city level averages + per area (index = area)
    public final AreaValues city = new AreaValues();
    public final List<AreaValues> areaValues = new ArrayList<>();

    // alerts
    public final long[] alertCountByType = new long[AlertType.values().length];
    public final Severity[] alertSeverityByType = new Severity[AlertType.values().length];
    public final List<AlertRecord> newAlerts = new ArrayList<>();
    public final List<ActivityEvent> newEvents = new ArrayList<>();

    public boolean finalSnapshot;
}
