package org.fog.airquality.dashboard;

import org.fog.application.selectivity.SelectivityModel;

/**
 * Tuple selectivity decided by the real edge logic instead of a random fraction:
 *  - data_filter emits FILTERED_DATA only if EdgeDataFilter forwarded the reading,
 *  - aqi_analyzer emits PUBLIC_ALERT only if the computed AQI is above the alert threshold.
 * The mean rate reported to iFogSim stays the calibrated ratio measured by AirQualityDataDemo.
 */
public class DataDrivenSelectivity implements SelectivityModel {

    private final MetricsCollector collector;
    private final String module, inputType, outputType;
    private final double ratio;

    public DataDrivenSelectivity(MetricsCollector collector, String module, String inputType, String outputType, double ratio) {
        this.collector = collector;
        this.module = module;
        this.inputType = inputType;
        this.outputType = outputType;
        this.ratio = ratio;
    }

    @Override
    public boolean canSelect() {
        return collector.select(module, inputType, outputType, ratio);
    }

    @Override
    public double getMeanRate() {
        return ratio;
    }

    @Override
    public double getMaxRate() {
        return 1.0;
    }
}
