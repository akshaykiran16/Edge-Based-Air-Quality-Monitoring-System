package org.fog.airquality.dashboard;

import java.util.List;

import org.cloudbus.cloudsim.Storage;
import org.fog.airquality.SimulationHooks;
import org.fog.application.Application;
import org.fog.application.selectivity.SelectivityModel;
import org.fog.entities.Actuator;
import org.fog.entities.FogBroker;
import org.fog.entities.FogDevice;
import org.fog.entities.FogDeviceCharacteristics;
import org.fog.entities.Sensor;
import org.fog.placement.Controller;
import org.fog.policy.AppModuleAllocationPolicy;
import org.fog.utils.distribution.Distribution;

/** Creates the monitored versions of the iFogSim entities for EdgeAirQualitySimulation. */
final class DashboardHooks implements SimulationHooks {

    private final MetricsCollector collector;
    private final DashboardMonitor.Pacer pacer;
    private DashboardController controller;

    DashboardHooks(MetricsCollector collector, DashboardMonitor.Pacer pacer) {
        this.collector = collector;
        this.pacer = pacer;
    }

    DashboardController getController() {
        return controller;
    }

    @Override
    public FogBroker createBroker(String name) throws Exception {
        return new FogBroker(name);
    }

    @Override
    public Application createApplication(String appId, int userId) {
        return new MonitoredApplication(appId, userId, collector);
    }

    @Override
    public FogDevice createFogDevice(String name, FogDeviceCharacteristics characteristics,
                                     AppModuleAllocationPolicy allocationPolicy, List<Storage> storageList,
                                     double schedulingInterval, long uplinkBandwidth, long downlinkBandwidth,
                                     double uplinkLatency, double ratePerMips, int level,
                                     double busyPower, double idlePower, int ramMb) throws Exception {
        MonitoredFogDevice d = new MonitoredFogDevice(name, characteristics, allocationPolicy, storageList,
                schedulingInterval, uplinkBandwidth, downlinkBandwidth, uplinkLatency, ratePerMips, collector);
        collector.registerDevice(d, busyPower, idlePower, ramMb, d.getHost().getTotalMips());
        return d;
    }

    @Override
    public Sensor createSensor(String name, String tupleType, int userId, String appId,
                               Distribution transmitDistribution, int area, int node) {
        MonitoredSensor s = new MonitoredSensor(name, tupleType, userId, appId, transmitDistribution, collector);
        collector.registerSensor(s.getId(), name, area, node);
        return s;
    }

    @Override
    public Actuator createActuator(String name, int userId, String appId, String actuatorType, int area, int node) {
        return new MonitoredActuator(name, userId, appId, actuatorType, collector);
    }

    @Override
    public SelectivityModel createSelectivity(String module, String inputTupleType, String outputTupleType,
                                              double calibratedRatio) {
        return new DataDrivenSelectivity(collector, module, inputTupleType, outputTupleType, calibratedRatio);
    }

    @Override
    public Controller createController(String name, List<FogDevice> fogDevices, List<Sensor> sensors,
                                       List<Actuator> actuators) throws Exception {
        controller = new DashboardController(name, fogDevices, sensors, actuators);
        return controller;
    }

    @Override
    public void beforeStart(Application application, Controller c) throws Exception {
        new DashboardMonitor("dashboard-monitor", collector, pacer);
        collector.info(0, "Simulation started: " + collector.mode + " placement, " + (collector.areas * collector.nodesPerArea)
                + " sensors, " + collector.sensingInterval + " ms sensing interval");
    }
}
