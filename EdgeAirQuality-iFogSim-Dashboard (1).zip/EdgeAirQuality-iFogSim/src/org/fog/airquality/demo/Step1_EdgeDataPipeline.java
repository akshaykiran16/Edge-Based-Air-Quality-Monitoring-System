package org.fog.airquality.demo;

/**
 * Eclipse demo shortcut: right-click this file > Run As > Java Application.
 * Runs the edge filter + AQI calculation on one simulated day for 20 stations (writes results/sample_readings.csv and results/station_summary.csv).
 */
public class Step1_EdgeDataPipeline {
    public static void main(String[] args) throws Exception {
        org.fog.airquality.AirQualityDataDemo.main(new String[]{"4", "5", "results"});
    }
}
