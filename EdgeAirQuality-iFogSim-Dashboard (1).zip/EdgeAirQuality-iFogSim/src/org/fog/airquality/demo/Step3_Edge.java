package org.fog.airquality.demo;

/**
 * Eclipse demo shortcut: right-click this file > Run As > Java Application.
 * Proposed edge placement: AQI analyzer on the fog gateways, 4 areas x 5 sensor nodes, 10 ms sensing interval.
 */
public class Step3_Edge {
    public static void main(String[] args) throws Exception {
        org.fog.airquality.EdgeAirQualitySimulation.main(new String[]{"edge", "4", "5", "10"});
    }
}
