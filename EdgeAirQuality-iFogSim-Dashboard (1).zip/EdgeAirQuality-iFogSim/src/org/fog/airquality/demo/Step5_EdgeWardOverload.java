package org.fog.airquality.demo;

/**
 * Eclipse demo shortcut: right-click this file > Run As > Java Application.
 * Edge-ward placement at a 5 ms sensing interval: shows the sensor node overloading (latency rises to about 970 ms).
 */
public class Step5_EdgeWardOverload {
    public static void main(String[] args) throws Exception {
        org.fog.airquality.EdgeAirQualitySimulation.main(new String[]{"edgewards", "4", "5", "5"});
    }
}
