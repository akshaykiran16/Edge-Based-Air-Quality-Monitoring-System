package org.fog.airquality.demo;

/**
 * Eclipse demo shortcut: right-click this file > Run As > Java Application.
 * iFogSim edge-ward heuristic placement, 4 areas x 5 sensor nodes, 10 ms sensing interval.
 */
public class Step4_EdgeWard {
    public static void main(String[] args) throws Exception {
        org.fog.airquality.EdgeAirQualitySimulation.main(new String[]{"edgewards", "4", "5", "10"});
    }
}
