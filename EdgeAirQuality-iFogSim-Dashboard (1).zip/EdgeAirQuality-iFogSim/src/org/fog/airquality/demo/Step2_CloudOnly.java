package org.fog.airquality.demo;

/**
 * Eclipse demo shortcut: right-click this file > Run As > Java Application.
 * Cloud-only placement: AQI analyzer in the cloud, 4 areas x 5 sensor nodes, 10 ms sensing interval.
 */
public class Step2_CloudOnly {
    public static void main(String[] args) throws Exception {
        org.fog.airquality.EdgeAirQualitySimulation.main(new String[]{"cloud", "4", "5", "10"});
    }
}
