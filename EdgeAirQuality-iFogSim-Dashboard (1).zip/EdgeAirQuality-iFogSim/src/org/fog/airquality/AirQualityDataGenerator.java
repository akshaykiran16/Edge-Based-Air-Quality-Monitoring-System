package org.fog.airquality;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Generates synthetic but realistic air quality readings for a set of monitoring stations.
 *
 * Model per station and pollutant:
 *   value(t) = base * zoneFactor * diurnal(t) + gaussian noise
 * with two traffic rush-hour peaks (08:00 and 19:00), an afternoon ozone peak,
 * occasional pollution events (e.g. waste burning or a traffic jam) that last
 * 20-60 minutes, and a small rate of faulty sensor samples (negative values,
 * stuck-at-zero, or spikes) that the edge filter must reject.
 */
public final class AirQualityDataGenerator {

    /** Station zone types change the baseline pollution level. */
    public enum Zone { RESIDENTIAL(0.8), COMMERCIAL(1.0), INDUSTRIAL(1.6), TRAFFIC(1.35);
        final double factor;
        Zone(double f) { factor = f; }
    }

    private final Random rnd;
    private final double faultRate;

    public AirQualityDataGenerator(long seed, double faultRate) {
        this.rnd = new Random(seed);
        this.faultRate = faultRate;
    }

    private static double rushHour(int minute) {
        double h = minute / 60.0;
        return 1.0 + 0.9 * Math.exp(-Math.pow(h - 8.5, 2) / 2.0)
                   + 0.8 * Math.exp(-Math.pow(h - 19.0, 2) / 2.5);
    }

    private static double sunCurve(int minute) {
        double h = minute / 60.0;
        return 0.4 + 1.1 * Math.exp(-Math.pow(h - 15.0, 2) / 8.0);
    }

    /** Produces one reading per minute for a full day for one station. */
    public List<SensorReading> generateDay(String stationId, Zone zone, int stepMinutes) {
        List<SensorReading> out = new ArrayList<>();
        int eventLeft = 0;
        double eventBoost = 1.0;
        for (int m = 0; m < 24 * 60; m += stepMinutes) {
            if (eventLeft <= 0 && rnd.nextDouble() < 0.004 * stepMinutes) {
                eventLeft = 20 + rnd.nextInt(41);
                eventBoost = 2.0 + rnd.nextDouble() * 3.0;
            }
            double ev = eventLeft > 0 ? eventBoost : 1.0;
            eventLeft -= stepMinutes;

            double r = rushHour(m), s = sunCurve(m), z = zone.factor;
            double pm25 = 22 * z * r * ev + rnd.nextGaussian() * 3;
            double pm10 = pm25 * (1.7 + rnd.nextDouble() * 0.4) + rnd.nextGaussian() * 4;
            double co   = 0.9 * z * r * Math.sqrt(ev) + rnd.nextGaussian() * 0.15;
            double no2  = 28 * z * r + rnd.nextGaussian() * 4;
            double o3   = 35 * s / Math.sqrt(r) + rnd.nextGaussian() * 4;
            double temp = 22 + 7 * Math.sin((m / 60.0 - 9) / 24.0 * 2 * Math.PI) + rnd.nextGaussian() * 0.4;
            double hum  = 60 - 15 * Math.sin((m / 60.0 - 9) / 24.0 * 2 * Math.PI) + rnd.nextGaussian();

            if (rnd.nextDouble() < faultRate) {
                switch (rnd.nextInt(3)) {
                    case 0: pm25 = -1 * Math.abs(pm25); break;      // negative value (ADC error)
                    case 1: pm25 = 0; pm10 = 0; co = 0; break;      // stuck at zero
                    default: pm25 = pm25 * 12; pm10 = pm10 * 10;    // impulse noise spike
                }
            }
            out.add(new SensorReading(stationId, m, pm25, pm10, co, no2, o3, temp, hum));
        }
        return out;
    }
}
