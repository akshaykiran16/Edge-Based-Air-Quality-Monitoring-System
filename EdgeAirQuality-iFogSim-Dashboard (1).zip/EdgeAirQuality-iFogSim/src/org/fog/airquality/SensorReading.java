package org.fog.airquality;

/** One multi-pollutant sample produced by an air quality sensor node. */
public final class SensorReading {
    public final String stationId;
    public final int minute;      // minute of the day the sample was taken
    public final double pm25;     // ug/m3
    public final double pm10;     // ug/m3
    public final double co;       // ppm
    public final double no2;      // ppb
    public final double o3;       // ppb
    public final double temperature; // deg C
    public final double humidity;    // %RH

    public SensorReading(String stationId, int minute, double pm25, double pm10, double co,
                         double no2, double o3, double temperature, double humidity) {
        this.stationId = stationId;
        this.minute = minute;
        this.pm25 = pm25;
        this.pm10 = pm10;
        this.co = co;
        this.no2 = no2;
        this.o3 = o3;
        this.temperature = temperature;
        this.humidity = humidity;
    }

    /** Copy with a different set of pollutant values (used by the edge filter). */
    public SensorReading with(double pm25, double pm10, double co, double no2, double o3) {
        return new SensorReading(stationId, minute, pm25, pm10, co, no2, o3, temperature, humidity);
    }

    public static String csvHeader() {
        return "station,minute,pm25,pm10,co,no2,o3,temperature,humidity";
    }

    public String toCsv() {
        return String.format(java.util.Locale.US, "%s,%d,%.2f,%.2f,%.3f,%.2f,%.2f,%.1f,%.1f",
                stationId, minute, pm25, pm10, co, no2, o3, temperature, humidity);
    }
}
