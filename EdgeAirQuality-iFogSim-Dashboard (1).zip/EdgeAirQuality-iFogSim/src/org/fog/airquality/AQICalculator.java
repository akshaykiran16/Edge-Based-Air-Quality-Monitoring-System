package org.fog.airquality;

/**
 * Air Quality Index calculator based on the US EPA piecewise-linear AQI method
 * (Technical Assistance Document for the Reporting of Daily Air Quality, 2024 revision
 * of the PM2.5 breakpoints).
 *
 * AQI_p = (I_hi - I_lo) / (BP_hi - BP_lo) * (C_p - BP_lo) + I_lo
 *
 * The overall AQI of a reading is the maximum sub-index over all pollutants,
 * and the pollutant that produced it is called the dominant pollutant.
 * This logic is what the "aqi_analyzer" module runs on the edge (fog) node.
 */
public final class AQICalculator {

    /** Index breakpoints shared by every pollutant table. */
    private static final int[][] INDEX = {
            {0, 50}, {51, 100}, {101, 150}, {151, 200}, {201, 300}, {301, 500}
    };

    /** PM2.5 24-hour, ug/m3 (EPA 2024 update). */
    private static final double[][] PM25 = {
            {0.0, 9.0}, {9.1, 35.4}, {35.5, 55.4}, {55.5, 125.4}, {125.5, 225.4}, {225.5, 325.4}
    };
    /** PM10 24-hour, ug/m3. */
    private static final double[][] PM10 = {
            {0, 54}, {55, 154}, {155, 254}, {255, 354}, {355, 424}, {425, 604}
    };
    /** CO 8-hour, ppm. */
    private static final double[][] CO = {
            {0.0, 4.4}, {4.5, 9.4}, {9.5, 12.4}, {12.5, 15.4}, {15.5, 30.4}, {30.5, 50.4}
    };
    /** NO2 1-hour, ppb. */
    private static final double[][] NO2 = {
            {0, 53}, {54, 100}, {101, 360}, {361, 649}, {650, 1249}, {1250, 2049}
    };
    /** O3 8-hour, ppb. EPA defines the 8-hour table only up to AQI 300; the last row is an
     *  approximation added so that extreme simulated spikes still map to an index. */
    private static final double[][] O3 = {
            {0, 54}, {55, 70}, {71, 85}, {86, 105}, {106, 200}, {201, 604}
    };

    public static final String[] CATEGORIES = {
            "Good", "Moderate", "Unhealthy for Sensitive Groups",
            "Unhealthy", "Very Unhealthy", "Hazardous"
    };

    private AQICalculator() { }

    /** Sub-index for one concentration against one breakpoint table. */
    static int subIndex(double c, double[][] table) {
        if (c < 0) c = 0;
        for (int i = 0; i < table.length; i++) {
            double lo = table[i][0], hi = table[i][1];
            // concentrations between two rows (e.g. 9.05) belong to the lower row
            double upper = (i + 1 < table.length) ? table[i + 1][0] : hi;
            if (c < upper || i == table.length - 1) {
                double cc = Math.min(c, hi);
                double aqi = (INDEX[i][1] - INDEX[i][0]) / (hi - lo) * (cc - lo) + INDEX[i][0];
                return (int) Math.round(Math.max(aqi, INDEX[i][0]));
            }
        }
        return 500;
    }

    /** Result of an AQI evaluation. */
    public static final class Result {
        public final int aqi;
        public final String dominantPollutant;
        public final String category;

        Result(int aqi, String dominantPollutant) {
            this.aqi = aqi;
            this.dominantPollutant = dominantPollutant;
            this.category = categoryOf(aqi);
        }

        public boolean isAlert(int threshold) {
            return aqi > threshold;
        }

        @Override
        public String toString() {
            return "AQI " + aqi + " (" + category + ", dominant " + dominantPollutant + ")";
        }
    }

    public static String categoryOf(int aqi) {
        if (aqi <= 50) return CATEGORIES[0];
        if (aqi <= 100) return CATEGORIES[1];
        if (aqi <= 150) return CATEGORIES[2];
        if (aqi <= 200) return CATEGORIES[3];
        if (aqi <= 300) return CATEGORIES[4];
        return CATEGORIES[5];
    }

    /** Computes the overall AQI of a full multi-pollutant reading. */
    public static Result compute(SensorReading r) {
        int best = -1;
        String dom = "";
        int[] vals = {
                subIndex(r.pm25, PM25), subIndex(r.pm10, PM10), subIndex(r.co, CO),
                subIndex(r.no2, NO2), subIndex(r.o3, O3)
        };
        String[] names = {"PM2.5", "PM10", "CO", "NO2", "O3"};
        for (int i = 0; i < vals.length; i++) {
            if (vals[i] > best) {
                best = vals[i];
                dom = names[i];
            }
        }
        return new Result(best, dom);
    }
}
