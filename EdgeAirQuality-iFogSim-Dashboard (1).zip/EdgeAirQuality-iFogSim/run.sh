#!/usr/bin/env bash
# Single run. Usage: ./run.sh [edge|cloud|edgewards] [areas] [nodesPerArea] [sensingIntervalMs]
cd "$(dirname "$0")"
CP="bin:$(find jars -name '*.jar' | tr '\n' ':')"
java -cp "$CP" org.fog.airquality.EdgeAirQualitySimulation "${1:-edge}" "${2:-4}" "${3:-5}" "${4:-10}"
