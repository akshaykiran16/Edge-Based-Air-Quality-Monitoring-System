"""Builds the report figures from results/*.csv.  Usage: python3 scripts/make_plots.py
Needs matplotlib (pip install matplotlib)."""
import csv
import os
from collections import defaultdict

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
RES = os.path.join(ROOT, "results")
FIG = os.path.join(RES, "figures")
os.makedirs(FIG, exist_ok=True)

MODES = ["cloud", "edge", "edgewards"]
LABEL = {"cloud": "Cloud-only", "edge": "Edge (fog gateway)", "edgewards": "Edge-ward (on node)"}
COLOR = {"cloud": "#2a78d6", "edge": "#eb6834", "edgewards": "#1baf7a"}
MARK = {"cloud": "o", "edge": "s", "edgewards": "^"}
INK, INK2, GRID = "#0b0b0b", "#52514e", "#e4e3df"

plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 10, "axes.edgecolor": INK2, "axes.labelcolor": INK,
    "xtick.color": INK2, "ytick.color": INK2, "axes.spines.top": False, "axes.spines.right": False,
    "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.8, "axes.axisbelow": True,
    "figure.facecolor": "white", "axes.facecolor": "white", "legend.frameon": False,
})


def load():
    rows = list(csv.DictReader(open(os.path.join(RES, "simulation_results.csv"))))
    agg = defaultdict(lambda: defaultdict(list))
    for r in rows:
        key = (r["mode"], int(r["areas"]), int(r["nodes_per_area"]), float(r["sensing_interval"]))
        for k, v in r.items():
            try:
                agg[key][k].append(float(v))
            except ValueError:
                pass
    mean = {k: {m: sum(v) / len(v) for m, v in d.items() if v} for k, d in agg.items()}
    return mean


def save(fig, name):
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, name), dpi=200)
    plt.close(fig)


def line_vs_nodes(mean, metric, ylabel, title, name, scale=1.0):
    fig, ax = plt.subplots(figsize=(6.4, 3.8))
    for m in MODES:
        pts = sorted((k[1] * k[2], v[metric] / scale) for k, v in mean.items() if k[0] == m and k[3] == 10.0)
        xs, ys = zip(*pts)
        ax.plot(xs, ys, color=COLOR[m], lw=2, marker=MARK[m], ms=7, mec="white", mew=1.5, label=LABEL[m])
        ax.annotate(f"{ys[-1]:,.1f}", (xs[-1], ys[-1]), xytext=(6, 0), textcoords="offset points",
                    va="center", color=INK2, fontsize=8.5)
    ax.set_xlabel("Number of sensor nodes")
    ax.set_ylabel(ylabel)
    ax.set_title(title, loc="left", color=INK, fontsize=11, fontweight="bold")
    ax.set_ylim(bottom=0)
    ax.legend(loc="upper left", bbox_to_anchor=(0, -0.18), ncol=3, fontsize=9)
    save(fig, name)


def bars_vs_interval(mean, metric, ylabel, title, name):
    ivs = sorted({k[3] for k in mean if k[1] == 4})
    fig, ax = plt.subplots(figsize=(6.4, 3.8))
    w = 0.26
    for i, m in enumerate(MODES):
        ys = [mean[(m, 4, 5, iv)][metric] for iv in ivs]
        xs = [j + (i - 1) * w for j in range(len(ivs))]
        bars = ax.bar(xs, ys, width=w - 0.03, color=COLOR[m], label=LABEL[m], edgecolor="white", linewidth=1)
        for x, y in zip(xs, ys):
            ax.text(x, y, f"{y:,.0f}", ha="center", va="bottom", fontsize=7.5, color=INK2)
    ax.set_xticks(range(len(ivs)))
    ax.set_xticklabels([f"{iv:g} ms" for iv in ivs])
    ax.set_xlabel("Sensing interval (time between two samples)")
    ax.set_ylabel(ylabel)
    ax.set_title(title, loc="left", color=INK, fontsize=11, fontweight="bold")
    ax.legend(loc="upper left", bbox_to_anchor=(0, -0.18), ncol=3, fontsize=9)
    save(fig, name)


def energy_breakdown(mean, name):
    parts = [("energy_cloud", "Cloud", "#2a78d6"), ("energy_isp", "ISP gateway", "#9ec5f4"),
             ("energy_fog", "Fog gateways", "#eb6834"), ("energy_nodes", "Sensor nodes", "#1baf7a")]
    fig, ax = plt.subplots(figsize=(6.4, 3.6))
    for i, m in enumerate(MODES):
        left = 0
        v = mean[(m, 4, 5, 10.0)]
        for key, lab, col in parts:
            val = v[key] / 1e6
            ax.barh(i, val, left=left, color=col, edgecolor="white", linewidth=2, height=0.6,
                    label=lab if i == 0 else None)
            left += val
        ax.text(left, i, f"  {left:.2f}", va="center", color=INK2, fontsize=8.5)
    ax.set_yticks(range(len(MODES)))
    ax.set_yticklabels([LABEL[m] for m in MODES])
    ax.invert_yaxis()
    ax.set_xlabel("Energy consumed (millions of iFogSim energy units)")
    ax.set_title("Energy by tier, 20 sensor nodes", loc="left", color=INK, fontsize=11, fontweight="bold")
    ax.grid(axis="y", visible=False)
    ax.legend(loc="upper left", bbox_to_anchor=(-0.3, -0.22), ncol=4, fontsize=8.5)
    save(fig, name)


def aqi_timeline(name):
    rows = [r for r in csv.DictReader(open(os.path.join(RES, "sample_readings.csv"))) if r["station"] == "node-0-0"]
    t = [int(r["minute"]) / 60 for r in rows]
    raw = [float(r["pm25"]) for r in rows]
    fwd = [(int(r["minute"]) / 60, int(r["aqi"])) for r in rows if r["aqi"]]
    fig, (a1, a2) = plt.subplots(2, 1, figsize=(7, 5.2), sharex=True)
    a1.plot(t, raw, color="#86b6ef", lw=1, label="Raw PM2.5 from sensor")
    bad = [(tt, v) for tt, v, r in zip(t, raw, rows) if r["filter_outcome"] == "DROPPED_INVALID"]
    if bad:
        a1.scatter(*zip(*bad), color="#d03b3b", s=14, zorder=3, label="Rejected by edge filter")
    a1.set_ylabel("PM2.5 (µg/m³)")
    a1.set_title("Station node-0-0: one simulated day", loc="left", color=INK, fontsize=11, fontweight="bold")
    a1.legend(loc="upper right", fontsize=8.5)
    xs, ys = zip(*fwd)
    bands = [(0, 50, "#e6f4e6", "Good"), (50, 100, "#fdf3d6", "Moderate"), (100, 150, "#fde4d6", "USG"),
             (150, 200, "#f7d4d4", "Unhealthy"), (200, 300, "#eadcf2", "Very unhealthy")]
    top = max(ys) * 1.1
    for lo, hi, col, lab in bands:
        if lo >= top:
            continue
        a2.axhspan(lo, hi, color=col, zorder=0)
        a2.text(24.1, (lo + min(hi, top)) / 2, lab, fontsize=7.5, va="center", color=INK2)
    a2.plot(xs, ys, color=INK, lw=1.2, label="AQI computed at the edge")
    a2.axhline(100, color="#d03b3b", lw=1, ls="--")
    a2.text(0.2, 103, "alert threshold (AQI 100)", fontsize=7.5, color="#d03b3b")
    a2.set_ylim(0, top)
    a2.set_ylabel("AQI")
    a2.set_xlabel("Hour of day")
    a2.set_xlim(0, 24)
    a2.grid(False)
    save(fig, name)


def category_bars(name):
    rows = list(csv.DictReader(open(os.path.join(RES, "sample_readings.csv"))))
    # use the pipeline log totals (all 20 stations) for the distribution
    log = open(os.path.join(RES, "pipeline_log.txt")).read().splitlines()
    cats = ["Good", "Moderate", "Unhealthy for Sensitive Groups", "Unhealthy", "Very Unhealthy", "Hazardous"]
    counts = []
    for c in cats:
        line = next(l for l in log if l.strip().rsplit(None, 1)[0].strip() == c)
        counts.append(int(line.split()[-1]))
    total = sum(counts)
    fig, ax = plt.subplots(figsize=(6.4, 3.4))
    ax.barh(range(len(cats)), [100 * c / total for c in counts], color="#2a78d6", height=0.6)
    for i, c in enumerate(counts):
        ax.text(100 * c / total, i, f"  {100 * c / total:.1f}% ({c:,})", va="center", fontsize=8.5, color=INK2)
    ax.set_yticks(range(len(cats)))
    ax.set_yticklabels(cats)
    ax.invert_yaxis()
    ax.set_xlim(0, 90)
    ax.set_xlabel("Share of analysed samples (%)")
    ax.set_title("AQI categories across 20 stations, one day", loc="left", color=INK, fontsize=11, fontweight="bold")
    ax.grid(axis="y", visible=False)
    save(fig, name)


def architecture(name):
    fig, ax = plt.subplots(figsize=(9, 6))
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 100)
    ax.axis("off")

    def box(x, y, w, h, title, sub, fc):
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.6,rounding_size=2", fc=fc, ec=INK2, lw=1))
        ax.text(x + w / 2, y + h * 0.64, title, ha="center", va="center", fontsize=9.5, fontweight="bold", color=INK)
        ax.text(x + w / 2, y + h * 0.28, sub, ha="center", va="center", fontsize=7.6, color=INK2)

    def arrow(x1, y1, x2, y2, text="", dx=1.5):
        ax.annotate("", (x2, y2), (x1, y1), arrowprops=dict(arrowstyle="<->", color=INK2, lw=1))
        if text:
            ax.text((x1 + x2) / 2 + dx, (y1 + y2) / 2, text, fontsize=7.5, color=INK2, va="center")

    box(30, 86, 40, 10, "Cloud data centre (level 0)", "cloud_storage: history, city analytics, threshold tuning", "#cde2fb")
    box(30, 66, 40, 9, "ISP / city gateway (level 1)", "routes traffic, no application module", "#f0efec")
    arrow(50, 75.6, 50, 85.4, "WAN · 100 ms")
    for i, x in enumerate([4, 37, 70]):
        box(x, 44, 26, 11, f"Fog gateway area {i}" if i < 2 else "Fog gateway area N", "Raspberry Pi class\naqi_analyzer (edge mode)", "#fde4d6")
        arrow(x + 13, 55.6, 50 if i == 1 else (40 if i == 0 else 60), 65.4, "4 ms" if i == 1 else "")
        for j, dx in enumerate([0, 13.5]):
            box(x + dx, 22, 12.5, 11, "Sensor node", "ESP32 class\ndata_filter", "#d9f2e8")
            arrow(x + dx + 6, 33.6, x + 13, 43.4, "2 ms\nMQTT" if (i == 0 and j == 0) else "", dx=-8)
            ax.text(x + dx + 6.25, 14, "PM2.5 · PM10\nCO · NO₂ · O₃", ha="center", fontsize=7, color=INK2)
            ax.text(x + dx + 6.25, 7, "AQI LED\nindicator", ha="center", fontsize=7, color=INK2)
            ax.annotate("", (x + dx + 6.25, 21.4), (x + dx + 6.25, 17.5), arrowprops=dict(arrowstyle="->", color=INK2, lw=0.8))
    ax.text(64, 40, "· · ·", fontsize=14, color=INK2)
    ax.text(0, 99, "Edge-based air quality monitoring: physical topology and module placement", fontsize=11,
            fontweight="bold", color=INK)
    save(fig, name)


def console_screenshot(name):
    text = open(os.path.join(RES, "console_log.txt")).read().split("===========================================")
    blocks = [b.strip() for b in text if "Mode" in b]
    pick = []
    for want in ["cloud", "edge", "edgewards"]:
        for b in blocks:
            if f"Mode                       : {want}\n" in b + "\n" and "20 (4 areas x 5)" in b:
                pick.append(b)
                break
    content = "\n\n".join("=========== AIR QUALITY SUMMARY ===========\n" + p.replace("=========== AIR QUALITY SUMMARY ===========", "").strip() for p in pick)
    content = "$ ./run.sh cloud 4 5 10   |   ./run.sh edge 4 5 10   |   ./run.sh edgewards 4 5 10\n\n" + content
    lines = content.splitlines()
    fig = plt.figure(figsize=(8, 0.155 * len(lines) + 0.3))
    fig.patch.set_facecolor("#1e1e1e")
    fig.text(0.02, 0.98, content, family="DejaVu Sans Mono", fontsize=8.5, color="#d4d4d4", va="top")
    fig.savefig(os.path.join(FIG, name), dpi=200, facecolor="#1e1e1e")
    plt.close(fig)


if __name__ == "__main__":
    mean = load()
    line_vs_nodes(mean, "loop_latency_ms", "Average loop latency (ms)",
                  "Sense → AQI → display latency", "fig_latency_vs_nodes.png")
    line_vs_nodes(mean, "network_usage", "Network usage (thousand bytes/ms)",
                  "Network usage", "fig_network_vs_nodes.png", scale=1000)
    line_vs_nodes(mean, "energy_total", "Total energy (millions of units)",
                  "Total energy consumption", "fig_energy_vs_nodes.png", scale=1e6)
    line_vs_nodes(mean, "cloud_cost", "Cloud execution cost (thousands)",
                  "Cost of execution in the cloud", "fig_cost_vs_nodes.png", scale=1000)
    bars_vs_interval(mean, "loop_latency_ms", "Average loop latency (ms)",
                     "Latency vs sensing frequency, 20 nodes", "fig_latency_vs_interval.png")
    energy_breakdown(mean, "fig_energy_breakdown.png")
    aqi_timeline("fig_aqi_timeline.png")
    category_bars("fig_aqi_categories.png")
    architecture("fig_architecture.png")
    console_screenshot("fig_console_output.png")
    # summary table for the report
    with open(os.path.join(RES, "summary_table.csv"), "w") as f:
        f.write("mode,total_nodes,sensing_interval,loop_latency_ms,network_usage,energy_total,cloud_cost\n")
        for k in sorted(mean, key=lambda k: (k[3], k[1] * k[2], MODES.index(k[0]))):
            v = mean[k]
            f.write(f"{k[0]},{k[1] * k[2]},{k[3]:g},{v['loop_latency_ms']:.2f},{v['network_usage']:.1f},"
                    f"{v['energy_total']:.0f},{v['cost_cloud'] if 'cost_cloud' in v else v['cloud_cost']:.0f}\n")
    print("Figures written to", FIG)
