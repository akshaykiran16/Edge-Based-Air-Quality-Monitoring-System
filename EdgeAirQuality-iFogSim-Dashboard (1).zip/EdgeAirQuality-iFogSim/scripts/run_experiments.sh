#!/usr/bin/env bash
# Runs every experiment scenario and writes results/simulation_results.csv
set -e
cd "$(dirname "$0")/.."
CP="bin:$(find jars -name '*.jar' | tr '\n' ':')"
OUT=results/simulation_results.csv
mkdir -p results; rm -f "$OUT"
REPS=${REPS:-3}   # each scenario is repeated; plots use the mean
run() { for r in $(seq $REPS); do java -cp "$CP" org.fog.airquality.EdgeAirQualitySimulation "$@" "$OUT" | grep -A10 "AIR QUALITY SUMMARY" >> results/console_log.txt; done; echo "done: $*"; }
: > results/console_log.txt
# Scenario A: scalability (number of city areas, 5 sensor nodes per area, 10 ms sensing interval)
for areas in 1 2 4 8 12; do for mode in cloud edge edgewards; do run $mode $areas 5 10; done; done
# Scenario B: sensing frequency (4 areas x 5 nodes)
for iv in 5 20 40; do for mode in cloud edge edgewards; do run $mode 4 5 $iv; done; done
# Edge data pipeline on one simulated day of data
java -cp "$CP" org.fog.airquality.AirQualityDataDemo 4 5 results | tee results/pipeline_log.txt
