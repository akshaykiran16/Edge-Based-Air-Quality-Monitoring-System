@echo off
REM Usage: run.bat [edge^|cloud^|edgewards] [areas] [nodesPerArea] [sensingIntervalMs]
cd /d %~dp0
set MODE=%1& if "%1"=="" set MODE=edge
set AREAS=%2& if "%2"=="" set AREAS=4
set NODES=%3& if "%3"=="" set NODES=5
set IV=%4& if "%4"=="" set IV=10
java -cp "bin;jars\*;jars\commons-math3-3.5\*" org.fog.airquality.EdgeAirQualitySimulation %MODE% %AREAS% %NODES% %IV%
