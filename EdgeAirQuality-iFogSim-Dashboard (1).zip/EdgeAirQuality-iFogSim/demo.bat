@echo off
REM One-click demo: builds if needed, then runs cloud-only, edge and edge-ward placements
REM for 20 sensor nodes (4 areas x 5 nodes) and the edge data pipeline.
cd /d "%~dp0"
if not exist bin\org\fog\airquality\EdgeAirQualitySimulation.class call build.bat
set CP=bin;jars\*;jars\commons-math3-3.5\*
echo.
echo ===== 1) EDGE DATA PIPELINE: filter + AQI on one simulated day =====
java -cp "%CP%" org.fog.airquality.AirQualityDataDemo 4 5 results
pause
echo.
echo ===== 2) CLOUD-ONLY placement =====
java -cp "%CP%" org.fog.airquality.EdgeAirQualitySimulation cloud 4 5 10 | findstr /C:"Mode" /C:"Sensor nodes" /C:"latency" /C:"Network" /C:"energy" /C:"Energy" /C:"cost" /C:"====="
pause
echo.
echo ===== 3) EDGE placement (AQI analyzer on fog gateway) =====
java -cp "%CP%" org.fog.airquality.EdgeAirQualitySimulation edge 4 5 10 | findstr /C:"Mode" /C:"Sensor nodes" /C:"latency" /C:"Network" /C:"energy" /C:"Energy" /C:"cost" /C:"====="
pause
echo.
echo ===== 4) EDGE-WARD placement (iFogSim heuristic) =====
java -cp "%CP%" org.fog.airquality.EdgeAirQualitySimulation edgewards 4 5 10 | findstr /C:"Mode" /C:"Sensor nodes" /C:"latency" /C:"Network" /C:"energy" /C:"Energy" /C:"cost" /C:"====="
echo.
echo Demo finished. Graphs are in results\figures
pause
